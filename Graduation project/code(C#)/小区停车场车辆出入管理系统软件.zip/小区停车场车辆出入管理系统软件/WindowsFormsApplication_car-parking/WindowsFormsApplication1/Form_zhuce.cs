﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form_zhuce : Form
    {
        public Form_zhuce()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 注册界面设置
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form_zhuce_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Add("管理员");
            comboBox1.Items.Add("超级管理员");
            this.Text = "注册界面";
        }
        /// <summary>
        /// 取消，进入登录界面
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Form1 frm1 = new Form1();
            frm1.Show();
        }
        /// <summary>
        /// 注册
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text != "") && (textBox2.Text != "") && (textBox3.Text != "") && (textBox4.Text != ""))
            {


                if (textBox4.Text != "123")
                {
                    MessageBox.Show("对不起，你没有权限访问注册");
                }
                else
                {
                    if (textBox2.Text == textBox3.Text)
                    {

                        zhuceyonghu();

                    }
                    else
                    {
                        MessageBox.Show("密码输入有问题，请重新输入");
                    }
                }
            }

            else
            {
                MessageBox.Show("注册中。。。不能为空！");
            }
        }
        /// <summary>
        /// 注册用户
        /// </summary>
        private void zhuceyonghu()
        {
            SqlConnection mycon;

            try
            {
                mycon = new SqlConnection(App_Code.ConnectionClass.GetConStr);
                SqlCommand mycmd = mycon.CreateCommand();
                SqlDataReader mydr;
                mycon.Open();
                mycmd.CommandText = "select * from Admin_Info where 管理员姓名 = @name";
                SqlParameter TName = new SqlParameter("@name", SqlDbType.NVarChar);
                mycmd.Parameters.Add(TName);
                TName.Value = textBox1.Text.Trim();
                mydr = mycmd.ExecuteReader();

                if (mydr.HasRows)
                {
                    MessageBox.Show("用户名存在，请重新输入");

                }
                else
                {
                    add();
                }
                mycon.Close();
            }
            catch
            {
                MessageBox.Show("连接问题！！！");
            }
        }
        /// <summary>
        /// 添加用户
        /// </summary>
        private void add()
        {
            SqlConnection con;
            try
            {
                con = new SqlConnection(App_Code.ConnectionClass.GetConStr);
                SqlCommand cmd = con.CreateCommand();              
                con.Open();
                cmd.CommandText = "insert into Admin_Info(管理员姓名,管理员密码,类别) values('" + textBox1.Text.Trim() + "','" + textBox2.Text.Trim() + "','" + comboBox1.Text.Trim() + "')";                
                cmd.ExecuteNonQuery();
                //
                login_zhuce();
                MessageBox.Show("注册成功");
            
                con.Close();
                this.Close();
                Form1 frm1 = new Form1();
                frm1.Show();
            }
            catch
            {
                MessageBox.Show("add出错");
            }
            
        }
        /// <summary>
        /// 注册日志
        /// </summary>
        private void login_zhuce()
        {
            SqlConnection connn;
            try
            {
                connn = new SqlConnection(App_Code.ConnectionClass.GetConStr);
                SqlCommand cmddd = connn.CreateCommand();
                connn.Open();
                cmddd.CommandText = "insert into System_Login(管理员姓名,时间,事件) values('注册用户','" + DateTime.Now.ToShortDateString() + "  " + DateTime.Now.ToLongTimeString() + "','注册')";
                cmddd.ExecuteNonQuery();
                //MessageBox.Show("注册成功！");

                connn.Close();
            }
            catch
            {
                MessageBox.Show("注册日志出错");
            } 
        }


    }
}
