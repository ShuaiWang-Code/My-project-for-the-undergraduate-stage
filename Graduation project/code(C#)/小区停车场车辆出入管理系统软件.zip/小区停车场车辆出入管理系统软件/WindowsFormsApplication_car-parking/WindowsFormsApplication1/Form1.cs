﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 退出应用程序
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            Form_first_form frm1 = new Form_first_form();
            frm1.Close();
        }
        /// <summary>
        /// 忘记密码
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("请致电系统维护员!----13053202889");
        }
        /// <summary>
        /// 注册用户
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form_zhuce frmzc = new Form_zhuce();
            frmzc.Show();
        }
        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            SqlConnection mycon;
            try
            {
                mycon = new SqlConnection(App_Code.ConnectionClass.GetConStr);
                SqlCommand mycmd = mycon.CreateCommand();
                SqlDataReader mydr;
                mycon.Open();
               
              
                    if (string.IsNullOrEmpty(textBox1.Text.Trim()))
                    {
                        MessageBox.Show("请输入用户名");

                    }
                    else if (string.IsNullOrEmpty(textBox2.Text.Trim()))
                    {
                        MessageBox.Show("请输入密码");

                    }
                    else
                    {
                        mycmd.CommandText = "select * from Admin_Info where 管理员姓名 = @name and 管理员密码 = @pwd";

                        SqlParameter TName = new SqlParameter("@name", SqlDbType.NVarChar);
                        SqlParameter TPwd = new SqlParameter("@pwd", SqlDbType.NVarChar);

                        mycmd.Parameters.Add(TName);
                        mycmd.Parameters.Add(TPwd);
                        TName.Value = textBox1.Text.Trim();
                        TPwd.Value = textBox2.Text.Trim();

                        mydr = mycmd.ExecuteReader();

                        if (mydr.HasRows)
                        {
                            mydr.Read();
                            //App_Code.ShareClass.ID = mydr["ID"].ToString();
                            App_Code.ShareClass.Name = mydr["管理员姓名"].ToString();
                            App_Code.ShareClass.Type = mydr["类别"].ToString();

                            login_denglu();
                            this.Hide();
                            Form_Interface frmif = new Form_Interface();
                            frmif.Show();

                        }
                        else
                        {
                            MessageBox.Show("用户名或密码错误！！！");
                            textBox1.Clear();
                            textBox2.Clear();
                        }
                    }
                
                
                mycon.Close();
            }
            catch
            {
                MessageBox.Show("连接问题！！！");
            }
        }
        /// <summary>
        /// 登录日志
        /// </summary>
        private void login_denglu()
        {
            SqlConnection connn;
            try
            {
                connn = new SqlConnection(App_Code.ConnectionClass.GetConStr);
                SqlCommand cmddd = connn.CreateCommand();
                connn.Open();
                cmddd.CommandText = "insert into System_Login(管理员姓名,时间,事件) values('"+App_Code.ShareClass.Name.Trim()+"','" + DateTime.Now.ToShortDateString() + "  " + DateTime.Now.ToLongTimeString() + "','登录')";
                cmddd.ExecuteNonQuery();
                MessageBox.Show("登录成功！");

                connn.Close();
            }
            catch
            {
                MessageBox.Show("登录出错");
            }   
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //this.skinEngine1.SkinFile = "Longhorn.ssk";
        }
    }
}
