#include "pwm.h"
#include "led.h"
#include "usart.h"
#include "delay.h"

//////////////////////////////////////////////////////////////////////////////////	 
//������ֻ��ѧϰʹ�ã�δ���������ɣ��������������κ���;
//ALIENTEK STM32F407������
//��ʱ��PWM ��������	   
//����ԭ��@ALIENTEK
//������̳:www.openedv.com
//��������:2014/5/4
//�汾��V1.0
//��Ȩ���У�����ؾ���
//Copyright(C) �������������ӿƼ����޹�˾ 2014-2024
//All rights reserved									  
////////////////////////////////////////////////////////////////////////////////// 	 


//TIM14 PWM���ֳ�ʼ�� 
//PWM�����ʼ��
//arr���Զ���װֵ
//psc��ʱ��Ԥ��Ƶ��
void pwm_Configuration(void)
{
    GPIO_InitTypeDef          gpio;
    TIM_TimeBaseInitTypeDef   tim;
    TIM_OCInitTypeDef         oc;
	
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC,ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB,ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);
	 
	
    gpio.GPIO_Pin = GPIO_Pin_8| GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11;
    gpio.GPIO_Mode = GPIO_Mode_AF;
	  gpio.GPIO_OType= GPIO_OType_PP;
    gpio.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_Init(GPIOA,&gpio);
	  gpio.GPIO_Mode = GPIO_Mode_AF;
	  gpio.GPIO_OType= GPIO_OType_PP;
    gpio.GPIO_Speed = GPIO_Speed_100MHz;
    gpio.GPIO_Pin = GPIO_Pin_6| GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;
	  GPIO_Init(GPIOC,&gpio);
	  
	
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource8, GPIO_AF_TIM1);
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource9, GPIO_AF_TIM1); 
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource10, GPIO_AF_TIM1);
    GPIO_PinAFConfig(GPIOA,GPIO_PinSource11,GPIO_AF_TIM1); 	
    GPIO_PinAFConfig(GPIOC,GPIO_PinSource6, GPIO_AF_TIM8);
    GPIO_PinAFConfig(GPIOC,GPIO_PinSource7, GPIO_AF_TIM8); 
  	GPIO_PinAFConfig(GPIOC,GPIO_PinSource8, GPIO_AF_TIM8);
		GPIO_PinAFConfig(GPIOC,GPIO_PinSource9, GPIO_AF_TIM8);
	
    tim.TIM_Prescaler = 28-1;
    tim.TIM_CounterMode = TIM_CounterMode_Up;
    tim.TIM_Period = 400;   //1khz
		tim.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInit(TIM1,&tim);
    tim.TIM_Prescaler = 1680-1;
	  tim.TIM_Period = 2000;   //50hZ
	  TIM_TimeBaseInit(TIM8,&tim);
		
	
    oc.TIM_OCMode = TIM_OCMode_PWM2;
    oc.TIM_OutputState = TIM_OutputState_Enable;
    oc.TIM_OutputNState = TIM_OutputState_Disable;
    oc.TIM_Pulse =0;
    oc.TIM_OCPolarity = TIM_OCPolarity_Low;
    oc.TIM_OCNPolarity = TIM_OCPolarity_High;
    oc.TIM_OCIdleState = TIM_OCIdleState_Reset;
    oc.TIM_OCNIdleState = TIM_OCIdleState_Set;
    TIM_OC1Init(TIM1,&oc);
    TIM_OC2Init(TIM1,&oc);
		TIM_OC3Init(TIM1,&oc);
		TIM_OC4Init(TIM1,&oc);
    TIM_OC1Init(TIM8,&oc);
    TIM_OC2Init(TIM8,&oc);
   	TIM_OC3Init(TIM8,&oc);
		TIM_OC4Init(TIM8,&oc);
	 
    TIM_OC1PreloadConfig(TIM1,TIM_OCPreload_Enable);
    TIM_OC2PreloadConfig(TIM1,TIM_OCPreload_Enable);
		TIM_OC3PreloadConfig(TIM1,TIM_OCPreload_Enable);
    TIM_OC4PreloadConfig(TIM1,TIM_OCPreload_Enable);
           
    TIM_ARRPreloadConfig(TIM1,ENABLE);
    
    TIM_CtrlPWMOutputs(TIM1,ENABLE);
    
    TIM_Cmd(TIM1,ENABLE);
    
    TIM_OC1PreloadConfig(TIM8,TIM_OCPreload_Enable);
    TIM_OC2PreloadConfig(TIM8,TIM_OCPreload_Enable);
    TIM_OC3PreloadConfig(TIM8,TIM_OCPreload_Enable);
    TIM_OC4PreloadConfig(TIM8,TIM_OCPreload_Enable);
		
    TIM_ARRPreloadConfig(TIM8,ENABLE);
    
    TIM_CtrlPWMOutputs(TIM8,ENABLE);
    
    TIM_Cmd(TIM8,ENABLE);
	
}

void Init_PWM(void)
{
    //pwm1=315;
	  //pwm2=135;
	  //pwm3=245;
	  pwm4=115;
	
}

void model1(void)
{
   int i,j;
	
	 for(j=135;j<=295;j+=1)
	  {
	   pwm2=j;
		 delay_ms(50);
	  }
	  delay_ms(500);
	 
   for(i=315;i>=120;i-=1)
	  {
	   pwm1=i;
		 delay_ms(50);
	  }
	  delay_ms(500);
		
}

void model2(void)
{    int j;
     
	for(j=115;j<=170;j+=1)
	  {
	   pwm4=j;
		 delay_ms(50);
	  }
	  delay_ms(500);
}



void model3(void)
{   int i; 
	  for(i=245;i>=100;i-=5)
	{
		pwm3=i;
		delay_ms(500);
	}
	  
for(i=100;i<=245;i+=5)
	{
		pwm3=i;
		delay_ms(500);
	}
}


void model4(void)
{  
//	  int j;
//	 
//	for(j=150;j<=220;j+=1)
//	  {
//	   pwm4=j;
//		 delay_ms(50);
//	  }
	  delay_ms(500);
          pwm4=90;
}

void model5(void)
{
      int i,j;
	
	    delay_ms(500);
	    for(i=120;i<=315;i+=1)
	    {
	     pwm1=i; 
       delay_ms(50);
	    }
	    delay_ms(500);
			
	    for(j=295;j>=135;j-=1)
	    {
	     pwm2=j;
			 delay_ms(50);
	    }
}



