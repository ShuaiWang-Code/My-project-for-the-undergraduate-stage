#include "reg52.h"
#define uchar unsigned char
#define uint  unsigned int
sbit s7=P3^0;
sbit s6=P3^1;
sbit s5=P3^2;
sbit s4=P3^3;

void delay(uint z);

void main()
{
		while(1)
		{
			if(s7==0)
			{
				delay(10);
				if(s7==0)
				{
					P2=(P2&0x1f)|0x80;
					P0=0xff;
					P2=(P2&0x1f);
				}
			}
			
			if(s6==0)
			{
				delay(10);
				if(s6==0)
				{
					P2=(P2&0x1f)|0x80;
					P0=0;
					P2=(P2&0x1f);
				}
			}
			
			if(s5==0)
			{
				delay(10);
				if(s5==0)
				{
					P2=(P2&0x1f)|0xa0;
					P0=0;
					P2=(P2&0x1f);
				}
			}
			
			if(s4==0)
			{
				delay(10);
				if(s4==0)
				{
					P2=(P2&0x1f)|0xa0;
					P0=0x40;
					P2=(P2&0x1f);
				}
			}
		}
}

void delay(uint z)
{
	uint i,j;
	for(i=z;i>0;i--)
		for(j=0;j<114;j++);
}