#include "reg52.h"
#define uchar unsigned char
#define uint  unsigned int

void main()
{	
	uint i=0;
	while(1)
	{
		P2=(P2&0x1f)|0x80;
		P0=0xff;
		P2=(P2&0x1f);
		for(i=0;i<50000;i++);
		P2=(P2&0x1f)|0x80;
		P0=0;
		P2=(P2&0x1f);
		for(i=0;i<50000;i++);
	}
}