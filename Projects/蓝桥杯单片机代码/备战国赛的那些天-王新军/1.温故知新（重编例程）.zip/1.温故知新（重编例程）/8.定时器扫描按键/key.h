#ifndef __KEY_H__
#define __KEY_H__


#define uchar unsigned char
#define uint  unsigned int


uchar key_press=0;
uchar key_re=0;

uchar read_key()
{
	uchar key_value;
	uchar key_temp;
	
	P3=0x0f;P4&=0xeb;
	key_temp=P3&0x0f;
	if(key_temp!=0x0f)
		key_press++;
	else
		key_press=0;
	if(key_press==3)
	{
		key_press=0;
		key_re=1;
		switch(key_temp)
		{
			case 0x0e:key_value=1;break;//s7
			case 0x0d:key_value=2;break;//s6
			case 0x0b:key_value=3;break;//s5
			case 0x07:key_value=4;break;//s4
		}
	}
	
	P3=0x0f;P4&=0xeb;
	key_temp=P3&0x0f;
	if((key_re==1)&&(key_temp==0x0f))
	{
		key_re=0;
		return key_value;
	}
	else
		return 0xff;
}





#endif
