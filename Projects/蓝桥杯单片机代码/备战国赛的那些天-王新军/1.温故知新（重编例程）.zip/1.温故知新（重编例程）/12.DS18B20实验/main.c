#include "reg52.h"
#include "onewire.h"
#define uchar unsigned char
#define uint  unsigned int

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar dspbuf[8]={10,10,10,10,10,10,10,10};
uchar dspcom=0;
uchar temperature;

void display();

void main()
{
	TMOD=0x01;
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	EA=1;
	ET0=1;
	TR0=1;
	while(1)
	{
			temperature=read_ds18b20_data();
			dspbuf[6]=temperature/10;
			dspbuf[7]=temperature%10;
	}
}

void isr_timer0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();
}

void display()
{
	P0=0xff;
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xc0;
	P2=(P2&0x1f);
	
	P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	if(++dspcom==8)
		dspcom=0;
}