#include "reg52.h"
#include "ds1302.h"
#define uint unsigned int
#define uchar unsigned char

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf};
uchar dspbuf[8]={1,2,10,4,5,10,7,8};
uchar dspcom=0;
uchar hour,min,sec;

void display();

void main()
{
	P2=(P2&0x1f)|0xa0;
	P0=0;
	P2=(P2&0x1f);
	TMOD=0x01;
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	EA=1;
	ET0=1;
	TR0=1;
	ds1302_init();
	while(1)
	{
		hour=Ds1302_Single_Byte_Read(ds1302_hr_addr);
		min=Ds1302_Single_Byte_Read(ds1302_min_addr);
		sec=Ds1302_Single_Byte_Read(ds1302_sec_addr);
		dspbuf[0]=hour/16;
		dspbuf[1]=hour%16;
		dspbuf[3]=min/16;
		dspbuf[4]=min%16;
		dspbuf[6]=sec/16;
		dspbuf[7]=sec%16;
	}
}

void isr_timer0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();
}

void display()
{
	P0=0xff;
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xc0;
	P2=(P2&0x1f);
	
	P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	
	
	if(++dspcom==8)
		dspcom=0;
}