#include "reg52.h"

void main()
{
	EA=1;
	EX0=1;
	EX1=1;
	IT1=1;
	IT0=1;
	
}