#include "reg52.h"
#define uchar unsigned char
#define uint  unsigned int
sbit s7=P3^0;//��һ
sbit s6=P3^1;//��һ
sbit s5=P3^2;//
sbit s4=P3^3;//

void delay(uint z);

void main()
{
	uchar a=0xfe;
	while(1)
	{
		if(s6==0)
		{
			delay(10);
			if(s6==0)
			{
				a--;
				
				while(!s6);
			}
		}
		P2=(P2&0x1f)|0x80;
		P0=a;
		P2=(P2&0x1f);
		
	}
}

void delay(uint z)
{
	uint i,j;
	for(i=z;i>0;i++)
		for(j=0;j<114;j++);
}