#include "reg52.h"
#include "ultrosonic.h"
#define uchar unsigned char
#define uint  unsigned int

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar dspbuf[8]={10,10,10,10,10,10,10,10};
uchar dspcom=0;
uchar intr=0;
bit s_flag=0;
uint distance=0;
uint t=0;

void display();

void main()
{
	TMOD|=0x11;
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	TH1=0;
	TL1=0;
	EA=1;
	ET0=1;
	TR0=1;
//	ET1=1;
	TR1=0;
	P2=(P2&0x1f)|0xa0;
	P0=0;
	P2=(P2&0x1f);
	while(1)
	{
			if(s_flag==1)
			{
				s_flag=0;
				send_wave();
				TR1=1;
				while((RX==1)&&(TF1==0));
				TR1=0;
				if(TF1==1)
				{
					TF1=0;//��������
					distance=999;//�޷���
				}
				else
				{
					t=TH1*256+TL1;
					distance=(uint)(t*0.017);//������룬��λ����			
				}
				TH1=0;
				TL1=0;
			}
			dspbuf[5]=distance/100;
			dspbuf[6]=distance%100/10;
			dspbuf[7]=distance%10;
	}
}

void isr_timer0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();
	if(++intr==100)
	{
		intr=0;
		s_flag=1;
	}
}

void display()
{
	P0=0xff;
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xc0;
	P2=(P2&0x1f);
	
	
	P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);

	if(++dspcom==8)
		dspcom=0;
}