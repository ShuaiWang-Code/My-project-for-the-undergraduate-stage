#ifndef __ULTROSONIC_H__
#define __ULTROSONIC_H__

#include "reg52.h"
#include "intrins.h"
#define uchar unsigned char
#define uint  unsigned int


#define somenop {_nop_();_nop_();_nop_();_nop_();_nop_();\
                 _nop_();_nop_();_nop_();_nop_(); _nop_();}
sbit TX=P1^0;
sbit RX=P1^1;

void send_wave()
{
	uchar i=8;
	do
	{
		TX=1;
		somenop;
		TX=0;
		somenop;
	}
	while(i--);
}




























#endif