#include "reg52.h"
#define uchar unsigned char
#define uint  unsigned int

void main()
{
	uint i,j;
	uchar a=0x01;
	P2=(P2&0x1f)|0xa0;
	P0=0;
	P2=(P2&0x1f);
	
	while(1)
	{
		for(i=0;i<8;i++)
		{
			P2=(P2&0x1f)|0x80;
			P0=~(a<<i);
			P2=(P2&0x1f);
			for(j=0;j<35000;j++);
		}
	}
}