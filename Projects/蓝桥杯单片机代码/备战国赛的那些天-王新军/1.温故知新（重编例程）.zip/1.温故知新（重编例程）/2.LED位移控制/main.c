#include "reg52.h"
#define uint  unsigned int 
#define uchar unsigned char

void main()
{
	uint i,j;
	char a=0xfe;
	P2=(P2&0x1f)|0x80;
	
	while(1)
	{
		for(i=0;i<8;i++)
		{
				P0=a<<i;
			for(j=0;j<40000;j++);
		}
		
	}
}

