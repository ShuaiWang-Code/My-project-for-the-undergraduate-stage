#include "reg52.h"
#include "iic.h"
#define uchar unsigned char 
#define uint  unsigned int
sbit s7=P3^0;
sbit s6=P3^1;

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbf};
uchar dspbuf[8]={10,10,10,10,5,6,7,8};
uchar dspcom=0;

void display();
void delay_ms(uint z);

void main()
{
	uchar dac_value=0;
	uint vout=1111;
	TMOD=0x01;
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	EA=1;
	ET0=1;
	TR0=1;
	P2=(P2&0x1f)|0xa0;
	P0=0;
	P2=(P2&0x1f);
	while(1)
	{
		if(s7==0)
		{
			delay_ms(10);
			if(s7==0)
			{
				dac_value++;
				while(!s7);
			}
		}
		if(s6==0)
		{
			delay_ms(10);
			if(s6==0)
			{
				dac_value--;
				while(!s6);
			}
		}
		dac_pcf8591(dac_value);
		vout=4700/256*dac_value; 
		dspbuf[4]=vout/1000;
		dspbuf[5]=vout/100%10;
		dspbuf[6]=vout%100/10;
		dspbuf[7]=vout%10;
	}
}

void isr_timer0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();
}

void display()
{
	
	P0=0xff;
	P2=(P2&0x1f)|0xe0;//����
	P2=(P2&0x1f);
	
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xc0;
	P2=(P2&0x1f);
	if(dspcom==4) P0=tab[dspbuf[dspcom]]&0x7f;
	if(dspcom!=4) P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	
	
	if(++dspcom==8)
		dspcom=0;
}

void delay_ms(uint z)
{
	uint x,y;
	for(x=z;x>0;x--)
		for(y=0;y<114;y++);
}