#include <stc15f2k60s2.h>
#include "ds1302.h"
#include "IIC.h"
#include <intrins.h>
#include "absacc.h"
#define uchar unsigned char
#define uint unsigned int
sbit k0=P3^0;sbit k1=P3^1;sbit k2=P3^2;sbit k3=P3^3;
sbit k4=P3^4;sbit k5=P3^5;sbit k6=P4^2;sbit k7=P4^4;
sbit tx=P1^0;
sbit rx=P1^1;
uchar code wm[8]={0x80,0x40,0x20,0x10,0x08,0x04,0x02,0x01};
uchar code dm[12]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf,0xff};
uchar disbuf[8]={11,11,11,11,11,11,11,11},disbuf1[8]={10,10,11,11,11,11,11,11};
uchar sec=0,min=59,hour=6,datdis,cjdat=99,jz=16,flagm=0;\
uchar m0=11,m1=11,m2=11,m3=11,m4=11,m5=11,m6=10,m7=10,mm1,mm2,mm3,mm4,mm5,mm6;
uchar flag_set=0,in_mm=0,flag_cw=0,flag_time1=0,km1=0,km1_flag=0,km2=0,km2_flag=0;
uchar mmcw=0,mmcw_flag=0;
void delay(uint i)
{
 	while(i--);
}
void jpsm()
{
  P3=P3&0XF0;
  if((k4==0)|(k5==0)|(k6==0)|(k7==0))
  {
   delay(65000);
   if((k4==0)|(k5==0)|(k6==0)|(k7==0))
   {
	k0=0;k1=1;k2=1;k3=1;
	if(k4==0)jz=3;
	if(k5==0)jz=2;
	if(k6==0)jz=1;
	if(k7==0)jz=0;
	k0=1;k1=0;k2=1;k3=1;
	if(k4==0)jz=7;
	if(k5==0)jz=6;
	if(k6==0)jz=5;
	if(k7==0)jz=4;
	k0=1;k1=1;k2=0;k3=1;
	if(k4==0)jz=11;
	if(k5==0)jz=10;
	if(k6==0)jz=9;
	if(k7==0)jz=8;
	k0=1;k1=1;k2=1;k3=0;
	if(k4==0)jz=15;
	if(k5==0)jz=14;
	if(k6==0)jz=13;
	if(k7==0)jz=12;
   	
   }
  }
}
void ds1302_init()
{
	Ds1302_Single_Byte_Write(0x80,(0/10)<<4|(0%10));
	Ds1302_Single_Byte_Write(0x82,(59/10)<<4|(59%10));
	Ds1302_Single_Byte_Write(0x84,(7/10)<<4|(7%10));
	Ds1302_Single_Byte_Write(0x8e,0x80);
}
void read1302()
{
	datdis=Ds1302_Single_Byte_Read(0x81);
	datdis=((datdis&0x70)>>4)*10+(datdis&0x0f);
	if(datdis<60)
	sec=datdis;

	datdis=Ds1302_Single_Byte_Read(0x83);
	datdis=((datdis&0x70)>>4)*10+(datdis&0x0f);
	if(datdis<60)
	min=datdis;

	datdis=Ds1302_Single_Byte_Read(0x85);
	datdis=((datdis&0x70)>>4)*10+(datdis&0x0f);
	if(datdis<24)
	hour=datdis;
		
}

void datset()
{
	disbuf[0]=sec%10;
	disbuf[1]=sec/10;
	disbuf[2]=10;
	disbuf[3]=min%10;
	disbuf[4]=min/10;
	disbuf[5]=10;
	disbuf[6]=hour%10;
	disbuf[7]=hour/10;
}

void display()
{
	uchar i;
	datset();
	for(i=0;i<8;i++)
	{
	 P2=((P2&0X1F)|0XC0);
	 P0=wm[i];
	 P2=((P2&0X1F)|0XE0);
	 P0=dm[disbuf[i]];
	 delay(1500);
	}
	
}
void datset1()
{
	disbuf1[0]=m0;
	disbuf1[1]=m1;
	disbuf1[2]=m2;
	disbuf1[3]=m3;
	disbuf1[4]=m4;
	disbuf1[5]=m5;
	disbuf1[6]=m6;
	disbuf1[7]=m7;
} 
void display1()
{
	uchar i;
	datset1();
	for(i=0;i<8;i++)
	{
	 P2=((P2&0X1F)|0XC0);
	 P0=wm[i];
	 P2=((P2&0X1F)|0XE0);
	 P0=dm[disbuf1[i]];
	 delay(1500);
	}
} 
void someno()
{
                _nop_();_nop_();_nop_();_nop_();_nop_();\	
				_nop_();_nop_();_nop_();_nop_();_nop_();
} 
void send()
{
	uchar i=8;
	do
	{
	tx=1;
	someno();
	_nop_();
	tx=0;
	someno();
	}
	while(i--);
	
}
void cj()
{
	uint tt;
	send();
	TR0=1;
	while((rx==1)&&(TF0==0));
	TR0=0;
	if(TF0==1)
	{
	 TF0=0;
	 cjdat=99;
	}
	else
	{
	tt=TH0;
	tt<<=8;
	tt=tt|TL0;
	cjdat=(uint)(tt*0.017);
	}
   TH0=0;
   TL0=0;

}
void main_init()
{
	P2=(P2&0X1F)|0X80;
	P0=0XFF;
	P2=(P2&0X1F)|0XA0;
	P0&=0XAF;
}
void mmsr()
{
	jpsm();
	if(km2==1)
	{
	 if(km2_flag<5)
	 {
	  P2=(P2&0X1F)|0XA0;
	  P0|=0X10;
	  P0&=0XbF;
	 }
	 else
	 {
	 km2_flag=0;
     km2=0;
     TR1=0;
	 P2=(P2&0X1F)|0XA0;
     P0|=0X00;
	 P0&=0XaF;
	 }
	}
	if(mmcw==1)
	{
	if(mmcw_flag<3)
	{
	  P2=(P2&0X1F)|0XA0;
	  P0|=0X40;
	  P0&=0XeF;
	}
	else
	{
	 mmcw_flag=0;
	 TR1=0;
	 mmcw=0;
	 P2=(P2&0X1F)|0XA0;
     P0|=0X00;
	 P0&=0XaF;
	}
	}
	if(jz!=16)
	 {
	 	if(jz<10)
		{
	 		flagm++;
			if(flagm<7)
			{
	 		switch(flagm)
	 		{
	 		case 1:m5=jz;jz=16;break;
	 		case 2:m4=jz;jz=16;break;
	 		case 3:m3=jz;jz=16;break;
	 		case 4:m2=jz;jz=16;break;
	 		case 5:m1=jz;jz=16;break;
	 		case 6:m0=jz;jz=16;break;
			}
			}
		}
		if((jz==14)&&(flagm>=6))
		{
		jz=16;
		flagm=0;
		if(in_mm==1)
		{
		 in_mm=0;
		 write_iic_recbyte(0x00,m0);	
	     write_iic_recbyte(0x01,m1);
		 write_iic_recbyte(0x02,m2);
		 write_iic_recbyte(0x03,m3);
		 write_iic_recbyte(0x04,m4);
		 write_iic_recbyte(0x05,m5);
		 mm1=m0;mm2=m1;mm3=m2;mm4=m3;mm5=m4;mm6=m5;
		 m0=11;m1=11;m2=11;m3=11;m4=11;m5=11;m6=10;m7=10;
		}
		else
			{
				if((m0==mm1)&&(m1==mm2)&&(m2==mm3)&&(m3==mm4)&&(m4==mm5)&&(m5==mm6))
				{
				if(flag_set==1)
				{
			 	m0=11;m1=11;m2=11;m3=11;m4=11;m5=11;m6=11;m7=10;in_mm=1;flag_set=0;
				}
					else
					{
		   			km2=1;
					TR1=1;
					}
				}
		 		else
		 		{
					flag_cw++;
					if(flag_cw>=3)
					{
						flag_set=0;
						flag_cw=0;
						mmcw=1;
						TR1=1;
		  				m0=11;m1=11;m2=11;m3=11;m4=11;m5=11;m6=10;m7=10;
					}
					else
					{
						if(flag_set==1)
						{
						 m0=11;m1=11;m2=11;m3=11;m4=11;m5=11;m6=10;m7=11;
						}
						else
						{
						m0=11;m1=11;m2=11;m3=11;m4=11;m5=11;m6=10;m7=10;
						}
					}
		 		}
		 		flagm=0;
			}
		}
		if(jz==10)
		{
		 m0=11;m1=11;m2=11;m3=11;m4=11;m5=11;m6=10;m7=11;
		 flag_set=1;
		 jz=16;
		 flagm=0;
		}
		if(jz==11)
		{
		 jz=16;
		write_iic_recbyte(0x00,1);	
		write_iic_recbyte(0x01,2);
		write_iic_recbyte(0x02,3);
		write_iic_recbyte(0x03,4);
		write_iic_recbyte(0x04,5);
		write_iic_recbyte(0x05,6);
		mm1=read_iic_recbyte(0x00);
		mm2=read_iic_recbyte(0x01);
		mm3=read_iic_recbyte(0x02);
		mm4=read_iic_recbyte(0x03);
		mm5=read_iic_recbyte(0x04);
    	mm6=read_iic_recbyte(0x05);
		m0=11;m1=11;m2=11;m3=11;m4=11;m5=11;m6=10;m7=10;
		}
		if((jz==15)&&((flag_set==1)||(in_mm==1)))
		{
		jz=16;
		flagm=0;
		flag_set=0;
		in_mm=1;
		m0=11;m1=11;m2=11;m3=11;m4=11;m5=11;m6=10;m7=10;
		}
	}

}
void main()
{
	TMOD=0X11;
	TH0=0;
    TL0=0;
	TH1=(65535-50000)/256;
	TL1=(65535-50000)%256;
	EA=1;
	ET1=1;
	main_init();
	ds1302_init();
	IE2|=0X04;			   //������ʱ��2�ж�
	AUXR|=0X10;			   //������ʱ��2���У���ʼ����
	T2H=(65535-20000)/256; //���ó�ֵ
	T2L=(65535-20000)%256; //
    /*write_iic_recbyte(0x00,1);	���ó�ʼ����
	write_iic_recbyte(0x01,2);
	write_iic_recbyte(0x02,3);
	write_iic_recbyte(0x03,4);
	write_iic_recbyte(0x04,5);
	write_iic_recbyte(0x05,6);*/	
	mm1=read_iic_recbyte(0x00);
	mm2=read_iic_recbyte(0x01);
	mm3=read_iic_recbyte(0x02);
	mm4=read_iic_recbyte(0x03);
	mm5=read_iic_recbyte(0x04);
    mm6=read_iic_recbyte(0x05);
	while(1)
	{
		read1302();
		if((hour<7)||(hour>21))
		{
		 mmsr();
		 display1();

		} 
		if((hour>6)&&(hour<22))
		{
		 //display();
		 cj();
		 if(km1==1)
		 {
		  if(km1_flag<5)
		  {
		   P2=(P2&0X1F)|0XA0;
		   P0|=0X10;
		   P0&=0XbF;
		  }
		  else
		  {
		   km1_flag=0;
		   km1=0;
		   TR1=0;
		   P2=(P2&0X1F)|0XA0;
		   P0|=0X00;
		   P0&=0XaF;
		  }
		 }
		 if(cjdat<30)
		 {
		   km1=1;
		   TR1=1;
		 }
		 
		}
	}
}
void timer1()interrupt 3
{
 	TH1=(65535-50000)/256;
	TL1=(65535-50000)%256;
	flag_time1++;
	if(flag_time1>=19)
	{
	  flag_time1=0;
	  if(km1==1)
	  {
	  km1_flag++;
	  }
	  if(km2==1)
	  {
	  km2_flag++;
	  }
	  if(mmcw==1)
	  {
	  mmcw_flag++;
	  }
	}
}
void time2()interrupt 12
{
	if((hour>6)&&(hour<22))
	{
	display();
	}
}