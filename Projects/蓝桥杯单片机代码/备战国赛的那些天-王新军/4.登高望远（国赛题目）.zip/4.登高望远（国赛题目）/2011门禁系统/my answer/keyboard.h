#ifndef  __keyboard_H__
#define  __keyboard__
#define uchar unsigned char
#define uint unsigned int

uchar key_press=0;
bit key_re=0;
bit key_finish=0;
extern uchar key_bit;
extern uchar dspbuf[8];
extern uchar face;
extern uchar mode;
uchar read_keyboard()
{
	uchar key_temp;
	uchar key_value0;
	uchar col;
	
	P3=0xf0;P4|=0x14;
	key_temp=(P3&0x3f)|((P4&0x04)<<4)|((P4&0x10)<<3);
	if(key_temp!=0xf0)
		key_press++;
	else 
		key_press=0;
	if(key_press==5)
	{
		key_press=0;
		key_re=1;
		switch(key_temp)
		{
			case 0x70:col=1;break;
			case 0xb0:col=2;break;
			case 0xd0:col=3;break;
			case 0xe0:col=4;break;
		}
		P3=0x0f;P4&=0xeb;
		key_temp=P3&0x0f;
		switch(key_temp)
		{
			case 0x0e:key_value0=col-1;break;
			case 0x0d:key_value0=col+3;break;
			case 0x0b:key_value0=col+7;break;
			case 0x07:key_value0=col+11;break;
		}
	}
	
	P3=0x0f;P4&=0xeb;
	key_temp=P3&0x0f;
	if((key_re==1)&&(key_temp==0x0f))
	{
		key_re=0;
		return key_value0;
	}
	return 0xff;
}

void proc_keyboard(uchar temp)
{
	switch(temp)
	{
		case 0:dspbuf[key_bit++]=0;break;
		case 1:dspbuf[key_bit++]=1;break;
		case 2:dspbuf[key_bit++]=2;break;
		case 3:dspbuf[key_bit++]=3;break;
		case 4:dspbuf[key_bit++]=4;break;
		case 5:dspbuf[key_bit++]=5;break;
		case 6:dspbuf[key_bit++]=6;break;
		case 7:dspbuf[key_bit++]=7;break;
		case 8:dspbuf[key_bit++]=8;break;
		case 9:dspbuf[key_bit++]=9;break;
		case 10:face=3;break;//����
		case 11:face=8;break;//��λ
//		case 12:break;
//		case 13:break;
		case 14://ȷ��
						if((face==1)&&(key_finish==1)){face=2;}
						if((face==4)&&(key_finish==1)){face=5;}
						if((face==6)&&(key_finish==1)){face=7;}
						key_bit=2;
						break;
		case 15:face=9;break;//�˳�
	}
		if(key_bit>8)
			key_bit=8;
		if(key_bit==7)
			key_finish=1;
		if(key_bit<7)
			key_finish=0;
}



#endif