#include "STC15F2K60S2.h"
#include "ds1302.h"
#include "iic.h"
#include "keyboard.h"
#define uchar unsigned char
#define uint unsigned int
sbit TX=P1^0;
sbit RX=P1^1;

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf,0xff};
uchar dspbuf[8]={11,11,11,11,11,11,11,11};
uchar dspcom=0;
uchar hour,min,sec;
uchar key_bit=2;
uchar temp;
uchar mima_init[6]={6,5,4,3,2,1};
uchar mima[6];
uchar mode;//1���Զ���    2��������
uchar face=0;//����ģʽ2������ܽ������ʾ
uchar i;
bit mima_flag=0;
uchar error=0;
uchar key_intr=0;
bit key_flag=0;
uchar time_count=0;
uchar time_intr=0;
bit time_start=0;
bit b_r=0;//�������ͼ̵���
uchar sonic_intr=0;
bit sonic_flag=0;
uchar distance=0;
uint t=0;

void display();
void delay(uint z);
void sendwave();
void sonic();

void main()
{
	TMOD|=0x11;
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	TH1=0;
	TL1=0;
	EA=1;
	ET0=1;
	TR0=1;
	TR1=0;
	ds1302_init(0x06,0x59,0x00);//��ĿҪ���ʼʱ��Ϊ06��59��00
	P0=0;
	P2=(P2&0x1f)|0xa0;
	P2=(P2&0x1f);
	/////////////////��ʼ��ϵͳ������////////////////////////
//	for(i=0;i<6;i++)
//	{
//			write_eeprom(i,mima_init[i]);
//			delay(10);
//	}

	////////////////////////////////////////
	
	while(1)
	{
		hour=Ds1302_Single_Byte_Read(ds1302_hr_addr);
		hour=hour/16*10+hour%16;
		min=Ds1302_Single_Byte_Read(ds1302_min_addr);
		min=min/16*10+min%16;
		sec=Ds1302_Single_Byte_Read(ds1302_sec_addr);
		sec=sec/16*10+sec%16;
		if((hour>=7)&&(hour<=22))
			mode=1;
		else
			mode=2;
		if(key_flag==1)
		{
				key_flag=0;
				temp=read_keyboard();
				proc_keyboard(temp);
		}
		
		if(mode==1)
		{
				dspbuf[0]=hour/10;
				dspbuf[1]=hour%10;
				dspbuf[3]=min/10;
				dspbuf[4]=min%10;
				dspbuf[6]=sec/10;
				dspbuf[7]=sec%10;
				dspbuf[2]=dspbuf[5]=10;
				
				//���������
				sonic();
				if(distance<30)
				{
						time_start=1;//5���ʱ
						time_count=0;
						b_r=1;
						P0=0x10;
						P2=(P2&0x1f)|0xa0;
						P2=(P2&0x1f);
				}
			
		}
		
		if(mode==2)
		{
				if(face==0)
				{
						for(i=0;i<6;i++)
						{
								mima[i]=read_eeprom(i);
								delay(10);
						}
							
						for(i=2;i<8;i++)
							dspbuf[i]=11;
						dspbuf[0]=dspbuf[1]=10;
						face=1;
						error=0;
				}
				
//				if(face==1)//�������뼰��ʾ
				
				if(face==2)
				{
						key_bit=2;
						for(i=0;i<6;i++)
						{
								if(dspbuf[i+2]!=mima[i])
										mima_flag=1;			
						}
						
						if(mima_flag==0)//�̵�����
						{
								error=0;
								P0=0x10;
								P2=(P2&0x1f)|0xa0;
								P2=(P2&0x1f);
								time_count=0;
								time_start=1;	//5���ʱ
								b_r=1;
						}
						if(mima_flag==1)
						{
								mima_flag=0;
								P0=0;
								P2=(P2&0x1f)|0xa0;
								P2=(P2&0x1f);
								error++;
								if(error>=3)
								{
										P0=0x40;
										P2=(P2&0x1f)|0xa0;
										P2=(P2&0x1f);
										time_start=1;//3���ʱ
										time_count=0;
										b_r=0;
										error=0;
								}			
						}
						
						for(i=2;i<8;i++)
							dspbuf[i]=11;
						dspbuf[0]=dspbuf[1]=10;
					
						face=1;
				}
				
				if(face==3)
				{
						key_bit=2;
						for(i=0;i<8;i++)					
								dspbuf[i]=11;
						dspbuf[1]=10;
						face=4;
				}
				
//				if(face==4)//�������벢��ʾ

				if(face==5)
				{
						for(i=0;i<6;i++)
						{
								if(dspbuf[i+2]!=mima[i])
										mima_flag=1;			
						}
						
						if(mima_flag==0)//����������ȷ
						{
								error=0;
								P0=0;
								P2=(P2&0x1f)|0xa0;
								P2=(P2&0x1f);
								for(i=0;i<8;i++)
									dspbuf[i]=11;
								dspbuf[0]=10;
								key_bit=2;
								face=6;
						}
						if(mima_flag==1)//�����������
						{
								mima_flag=0;
								error++;
								if(error>=3)
								{
										P0=0x40;
										P2=(P2&0x1f)|0xa0;
										P2=(P2&0x1f);
										face=0;
										time_start=1;//3���ʱ
										time_count=0;
										b_r=0;
								}	
								if(face!=0)
										face=3;
						}				
				}
				
//				if(face==6)//���������벢��ʾ
				
				if(face==7)
				{
						for(i=0;i<6;i++)
						{
								write_eeprom(i,dspbuf[i+2]);
								delay(10);
								mima[i]=dspbuf[i+2];
						}
						face=0;
						key_bit=2;
				}
				
				
				if(face==8)
				{
						for(i=0;i<6;i++)
						{
							mima[i]=mima_init[i];
							write_eeprom(i,mima[i]);
							delay(10);
						}
						face=0;
				}
				
				if(face==9)
				{
						key_bit=2;
						for(i=2;i<8;i++)
							dspbuf[i]=11;
						dspbuf[0]=dspbuf[1]=10;
						face=0;
				}				
							
		}
		
				if((time_count==15)&&(b_r==0))//3��
				{
						time_count=0;
						time_start=0;
						P0=0;
						P2=(P2&0x1f)|0xa0;
						P2=(P2&0x1f);
				}
				if((time_count==25)&&(b_r==1))//5��
				{
						time_count=0;
						time_start=0;
						P0=0;
						P2=(P2&0x1f)|0xa0;
						P2=(P2&0x1f);
				}
		
	}
}

void isr_timer0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();
	if(++key_intr==10)
	{
			key_intr=0;
			key_flag=1;
	}
	if(time_start==1)
	{
			if(++time_intr==100)
			{
					time_intr=0;
					time_count++;
			}
	}
	if(++sonic_intr==50)
	{
			sonic_intr=0;
			sonic_flag=1;
	}
}

void display()
{
	P0=0xff;
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xc0;
	P2=(P2&0x1f);
	P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	if(++dspcom==8)
		dspcom=0;
}

void delay(uint z)
{
	uint x,y;
	for(x=z;x>0;x--)
		for(y=0;y<114;y++);
}

void sendwave()
{
		uchar i=8;
		do
		{
			TX=1;
			_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();
			TX=0;
			_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();			
		}
		while(i--);
}

void sonic()
{
		if(sonic_flag==1)
		{
				sonic_flag=0;
				sendwave();
				TR1=1;
				while((RX==1)&&(TF1==0));
				TR1=0;
				if(TF1==1)
				{
						TF1=0;
						distance=99;
				}
				else
				{
						t=TH1*256+TL1;
						distance=(uint)(t*0.017);
				}
				TH1=TL1=0;
		}
}
