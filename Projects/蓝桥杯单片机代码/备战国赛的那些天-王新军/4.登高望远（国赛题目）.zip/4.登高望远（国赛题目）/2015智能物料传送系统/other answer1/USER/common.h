#ifndef _COMMON_H_
#define	_COMMON_H_
#include "include.h"

#define LED 4
#define DU  7
#define WE  6
#define OT  5
#define BUZZ 0x40

sbit L1 = P0^0;
sbit L2 = P0^1;
sbit L3 = P0^2;

#define uint unsigned int
#define uchar unsigned char

#endif