#ifndef _INCLUDE_H_
#define	_INCLUDE_H_

#include <reg52.h>
#include <intrins.h>
#include "common.h"
#include "HC138.h"
#include "Display.h"
#include "iic.h"
#include "onewire.h"
#include "ds1302.h"
#include "AT24C02.h"
#include "Delay.h"
#include "Wave.h"
#include "PCF8591.h"
#include "KEY.h"

#endif
