#include "Wave.h"

uint Distance_Get(void)
{
	uint Distance;

	Wave_Send();
	TR1 = 1;
	while (RX && (!TF1));
	TR1 = 0;
	if (TF1)
	{
		TF1 = 0;
		Distance = 9999;
	}
	else
	{
		Distance = TH1;
		Distance = (Distance << 8) | TL1;
		Distance *= 0.17;//��λmm
	}
	TH1 = TL1 = 0;

	return Distance;
}

void Wave_Send(void)
{
	uchar i;

	for(i = 0; i < 8; i++)
	{
		TX = 1;
		Delay_12us();
		TX = 0;
		Delay_12us();
	}	
}

void Timer1_Init(void)
{
	TMOD |= 0x10;
	TH1 = TL1 = 0;
	ET1 = 0;
	TR1 = 0;
}
