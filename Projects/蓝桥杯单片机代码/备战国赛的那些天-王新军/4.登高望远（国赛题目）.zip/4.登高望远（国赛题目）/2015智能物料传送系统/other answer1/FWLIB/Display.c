#include "Display.h"


uchar Tab[11] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8, 0x80, 0x90, 0xff};
uchar DisplayBuff[8] = {0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff};

void Display(void)
{
	static i = 0;

	P0 = 0xff;
	Enable_138(DU);

	P0 = 0x01 << i;
	Enable_138(WE);

	P0 = DisplayBuff[i++];
	Enable_138(DU);

	if (i >= 8)
	{
		i = 0;
	}
}

void Close_Display(void)
{
	uchar i;

	for (i = 0; i < 8; i++)
	{
		DisplayBuff[i] = 0xff;
	}
}
       