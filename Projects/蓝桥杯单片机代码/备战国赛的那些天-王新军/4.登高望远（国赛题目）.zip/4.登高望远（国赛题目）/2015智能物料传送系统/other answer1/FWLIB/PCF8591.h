#ifndef _PCF8591_H_
#define	_PCF8591_H_
#include "include.h"
#include "common.h"

void PCF8591_Init(uchar ch);
uint PCF8591_ADCGet(void);

#endif
