#ifndef _DELAY_H_
#define	_DELAY_H_
#include "include.h"
#include "common.h"

void Delay_ms(uint z);
void Delay_12us(void);

#endif