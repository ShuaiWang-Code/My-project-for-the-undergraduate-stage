#include "PCF8591.h"

void PCF8591_Init(uchar ch)
{
	IIC_Start();
	IIC_SendByte(0x90);
	IIC_WaitAck();
	IIC_SendByte(ch);
	IIC_WaitAck();
	IIC_Stop();
	Delay_ms(10);
}

uint PCF8591_ADCGet(void)
{
	uint Data;

	IIC_Start();
	IIC_SendByte(0x91);
	IIC_WaitAck();
	Data = IIC_RecByte();
	IIC_Ack(0);
	IIC_Stop();

	return Data;	
}
