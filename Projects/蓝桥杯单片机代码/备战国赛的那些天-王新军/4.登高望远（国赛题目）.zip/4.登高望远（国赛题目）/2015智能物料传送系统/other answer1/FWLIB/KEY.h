#ifndef _KEY_H_
#define	_KEY_H_
#include "include.h"
#include "common.h"

uchar KEY_Scan(void);

#endif