#ifndef _AT24C02_H_
#define	_AT24C02_H_
#include "include.h"
#include "common.h"

void AT24C02_WriteData(uchar Addr, uchar Data);
uchar AT24C02_ReadData(uchar Addr);

#endif
