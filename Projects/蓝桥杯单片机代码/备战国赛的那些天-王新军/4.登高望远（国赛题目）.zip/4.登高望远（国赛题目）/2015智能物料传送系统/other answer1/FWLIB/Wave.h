#ifndef  __WAVE_H__
#define  __WAVE_H__
#include "include.h"
#include "common.h"

sbit TX = P1^0;
sbit RX = P1^1;

void Timer1_Init(void);
void Wave_Send(void);
uint Distance_Get(void);

#endif
