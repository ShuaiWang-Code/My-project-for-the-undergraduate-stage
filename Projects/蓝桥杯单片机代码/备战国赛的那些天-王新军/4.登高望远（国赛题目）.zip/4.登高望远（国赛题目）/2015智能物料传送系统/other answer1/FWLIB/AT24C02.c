#include "AT24C02.h"

void AT24C02_WriteData(uchar Addr, uchar Data)
{
	IIC_Start();
	IIC_SendByte(SlaveAddrW);
	IIC_WaitAck();
	IIC_SendByte(Addr);
	IIC_WaitAck();
	IIC_SendByte(Data);
	IIC_WaitAck();
	IIC_Stop();
	Delay_ms(10);
}

uchar AT24C02_ReadData(uchar Addr)
{
	uchar Data;

	IIC_Start();
	IIC_SendByte(SlaveAddrW);
	IIC_WaitAck();
	IIC_SendByte(Addr);
	IIC_WaitAck();

	IIC_Start();
	IIC_SendByte(SlaveAddrR);
	IIC_WaitAck();
	Data = IIC_RecByte();
//	IIC_SendByte(0);
	IIC_Stop();

	return Data;
}
