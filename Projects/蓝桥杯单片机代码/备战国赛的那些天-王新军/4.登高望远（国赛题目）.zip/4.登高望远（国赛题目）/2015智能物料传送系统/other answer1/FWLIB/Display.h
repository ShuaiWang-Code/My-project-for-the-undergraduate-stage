#ifndef _DISPLAY_H_
#define	_DISPLAY_H_
#include "include.h"
#include "common.h"

extern uchar Tab[];
extern uchar DisplayBuff[];

void Display(void);
void Close_Display(void);

#endif