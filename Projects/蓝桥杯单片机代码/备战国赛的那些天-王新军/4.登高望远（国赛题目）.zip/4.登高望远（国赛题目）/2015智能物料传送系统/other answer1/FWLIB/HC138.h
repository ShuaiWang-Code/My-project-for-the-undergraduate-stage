#ifndef _HC138_H_
#define	_HC138_H_
#include "include.h"
#include "common.h"

void Enable_138(uchar ch);

#endif