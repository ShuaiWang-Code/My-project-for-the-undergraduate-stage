#include "KEY.h"

uchar KEY_Scan(void)
{
	uchar KEY = 0;

	P3 = 0xff;
	if (P3 != 0xff)
	{
		Delay_ms(10);
		if (P3 != 0xff)
		{
			switch (P3)
			{
				case 0xfe: KEY = 7; break;
				case 0xfd: KEY = 6; break;
				case 0xfb: KEY = 5; break;
				case 0xf7: KEY = 4; break;
			}
			while (P3 != 0xff);
			Delay_ms(10);
			while (P3 != 0xff);
		}
	}

	return KEY;
}
