#include "HC138.h"

void Enable_138(uchar ch)
{
	P2 = (P2&0x1f)|(ch<<5);
	_nop_();
	_nop_();
	P2 &= 0x1f;	
}