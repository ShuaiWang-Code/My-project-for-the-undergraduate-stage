void readkey();
extern char keyvalue;