//void Delay10us();
//void sendwave();
unsigned int start_ultrasonic();
