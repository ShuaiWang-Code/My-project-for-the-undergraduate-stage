#include <stc15f2k60s2.h>
#include <intrins.h>

char keyvalue;

void Delay20ms();

char readkey(void)
{
  P3=0XFF;
  if(P3==0xff)
  keyvalue=0;    //�ް��������򷵻�0
  if(P3!=0xff)
  {
   Delay20ms();
   if(P3!=0XFF)
   {
	 unsigned char key;
     key=P3;
   	 switch(key)
	 {	
	 case 0xf7: keyvalue=4; break;
	 case 0xfb: keyvalue=5; break;
	 case 0xfd: keyvalue=6; break;
	 case 0xfe: keyvalue=7; break;
	 default: break;
	 }
   }
   while(P3!=0xff);
  }
  return keyvalue;
}

void Delay20ms()		//@11.0592MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 1;
	j = 216;
	k = 35;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}
