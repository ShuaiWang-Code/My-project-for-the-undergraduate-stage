#include "stc15f2k60s2.h"
#include "intrins.h"
#include "key.h"
#include "i2c.h"
#include "ultrasonic.h"

#define uchar unsigned char
#define uint unsigned int
  
void leddisplay();
void timer_init();
void dspbuf_mode();
void led4();
void diskey1();
void diskey2();

uchar pressure;     //ѹ��

bit flag=0;     //0.5���־λ
bit flag1=0;    //������������־λ
bit flag2=0;    //���ﴫ�䵹��ʱ��׼λ
bit flag3=0;     //����ֹͣ������׼λ
int flag_key6=0;    //����6�Ĺ��ܱ�־λ
extern unsigned int distance;  //�������������
int dspbufmode=0;   //��ʾģʽ
int thing;        //��������
uchar time1=3;        //1����ﴫ��ʱ��
uchar time2=4;        //2����ﴫ��ʱ��
uchar dspcom=0;
uchar dspbuf[8]={0xc0,0xc0,0xc0,0xB0,0xB0,0xc0,0xc0,0xc0};  //��ʾ������
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,
                            0xff,0xbf,0xc6}; //0~9 10�� ����ʾ��-

void main()
{
    P2&=0X1F;
    P2|=0Xa0;
    P0=0x00;      //�ط�����
    P2&=0X1F;
  
  timer_init();
  init_pcf8591();
  time1=read_eeprom(0x00);
  time2=read_eeprom(0x05);
  write_eeprom(0x00,time1);
  write_eeprom(0x05,time2);
  while(1)
  { 
    led4();
    
    dspbuf_mode();
    pressure=adc_pcf8591();
    if(pressure<51)     //����
    {
      P0=0xfe;      //L1��
      P2&=0X1F;
      P2|=0X80;
      P2&=0X1F;
    }
    if(pressure>=51 && pressure<204)   //�ǿ��طǹ���
    {
      P0=0xfd;      //L2��
      P2&=0X1F;
      P2|=0X80;
      P2&=0X1F;
      
      if(flag1==1)
      {
        flag1=0;
        start_ultrasonic();
        if(distance<30)
          thing=1;
        if(distance>=30)
          thing=2;
        if(dspbufmode!=2&&dspbufmode!=3&&dspbufmode!=4)
        {
          dspbufmode=1;
         //diskey2();
        }
        readkey();    //����ɨ��
        diskey1();
        diskey2();
      }
    }
    if(pressure>=204)    //����
    {
      if(flag==1)
      P0=0xfb;
      if(flag==0)
      P0=0xff;
      P2&=0X1F;
      P2|=0X80;//L3��˸
      P2&=0X1F;
    }
  }
}                            

void timer_init()
{
  TMOD=0X01;
  TH0=(65536-2000)/256;
  TL0=(65536-2000)%256;
  ET0=1;
  TR0=1;
  EA=1;
}

void time0(void) interrupt 1
{
  uint ints,ints1,ints2;
  TH0=(65535-2000)/256;     //��ֵ��װ
  TL0=(65535-2000)%256;
  
  leddisplay();
  ints++;
  if(ints>=250)   //0.5���־
  {
    ints=0;
    flag=~flag;
  }
  
  ints1++;
  if(ints1>=100)    //200ms����һ�γ�����
  {
    ints1=0;
    flag1=1;
  }
  
  if(flag2==1)
  {
  ints2++;
  if(ints2>=500)   //���ʱ�����ﴫ�䵹��ʱ
  {
    ints2=0;
    if(thing==1)
      time1--;
    if(thing==2)
      time2--;
    if(time1==0||time2==0)
    {
//      time1=8;
//      time2=7;
      EA=0;
      time1=read_eeprom(0x00);
      time2=read_eeprom(0x05);
      EA=1;
      P0=0x00;   //��ɴ��䣬�̵����Ͽ�
      P2&=0X1F;
      P2|=0Xa0;
      P2&=0X1F;
      dspbufmode=1;
      flag2=0;
    }
  }
 }
}

void leddisplay()	   //LED��ʾ����
{
  P2&=0X1F;
  P2|=0XE0;
  P0=0XFF;
  P2&=0X1F;     //����
  
  P2&=0X1F;
  P2|=0Xc0;
  P0=1<<dspcom;
  P2&=0X1F;
  
  P2&=0X1F;
  P2|=0XE0;
  P0=dspbuf[dspcom];
  P2&=0X1F;
  
  if(++dspcom == 8)
        dspcom = 0;
}

void dspbuf_mode()
{
  switch(dspbufmode)
  {
    case 1:dspbuf[0]=tab[1];
           dspbuf[1]=tab[10];
           dspbuf[2]=tab[10];
           dspbuf[3]=tab[distance/10];
           dspbuf[4]=tab[distance%10];
           dspbuf[5]=tab[10];
           dspbuf[6]=tab[10];
           dspbuf[7]=tab[thing];
           break;
    case 2:dspbuf[0]=tab[2];
           dspbuf[1]=tab[10];
           dspbuf[2]=tab[10];
           dspbuf[3]=tab[10];
           dspbuf[4]=tab[10];
           dspbuf[5]=tab[10];
           dspbuf[6]=tab[time1/10];
           dspbuf[7]=tab[time1%10];
           break;
    case 3:dspbuf[0]=tab[2];
           dspbuf[1]=tab[10];
           dspbuf[2]=tab[10];
           dspbuf[3]=tab[10];
           dspbuf[4]=tab[10];
           dspbuf[5]=tab[10];
           dspbuf[6]=tab[time2/10];
           dspbuf[7]=tab[time2%10];
           break;
    case 4:dspbuf[0]=tab[3];
           dspbuf[1]=tab[10];
           dspbuf[2]=tab[10];
           if(flag_key6==1)
           {
             if(flag==1)
             {
              dspbuf[3]=tab[time1/10];
              dspbuf[4]=tab[time1%10];
             }
             else
             {
              dspbuf[3]=tab[10];
              dspbuf[4]=tab[10];
             }
             dspbuf[5]=tab[10];
             dspbuf[6]=tab[time2/10];
             dspbuf[7]=tab[time2%10];
           }  
           
           if(flag_key6==2)
           {
             if(flag==1)
             {
              dspbuf[6]=tab[time2/10];
              dspbuf[7]=tab[time2%10];
             }
             else
             {
              dspbuf[6]=tab[10];
              dspbuf[7]=tab[10];
             }
             dspbuf[5]=tab[10];
             dspbuf[3]=tab[time1/10];
             dspbuf[4]=tab[time1%10];
           }  
           break;
    default: break;       
  }
}

void diskey1()
{
  switch(keyvalue)
  {
    case 4:P0=0x10;    //�պϼ̵���
           P2&=0X1F;
           P2|=0Xa0;
           P2&=0X1F;
           flag2=1;
           if(thing==1)
             dspbufmode=2;
           if(thing==2)
             dspbufmode=3;
           break;
    case 5:if(dspbufmode==2||dspbufmode==3)
          {
           flag3=~flag3;
           if(flag3==1)
           {  
            P0=0x00;   //����ֹͣ
            P2&=0X1F;
            P2|=0Xa0;
            P2&=0X1F;
            flag2=0;   //����ֹͣ����
           }
           if(flag3==0)
           {
            P0=0x10;   //����ָ�
            P2&=0X1F;
            P2|=0Xa0;
            P2&=0X1F;
            flag2=1;   //���ﴫ�䵹��ʱ��ʼ
           }
         }
           break;
     default: break;    
  }
}

void diskey2()
{
  switch(keyvalue)
  {
    case 6:flag_key6++;
           if(flag_key6==3)
             flag_key6=0;
           switch(flag_key6)
           {
             case 0:dspbufmode=1;
                    break;
             case 1:dspbufmode=4;
                    break;
             case 2:dspbufmode=4;
                    break;
             default: break;
           }
           break;
    case 7:switch(flag_key6)
           {
             case 1:time1++;
                    if(time1>=11)
                      time1=0;
                    write_eeprom(0x00,time1);
                    break;
             case 2:time2++;
                    if(time2>=11)
                      time2=0;
                    write_eeprom(0x05,time2);
                    break;
             default: break;
           }
           break;
    default: break;
  }
}

void led4()    //L4��˸����
{
 if(flag3)
 {  
  if(flag==1)  //L4��˸
   P0=0xf7;
  if(flag==0)
   P0=0xff;
  P2&=0X1F;
  P2|=0X80;
  P2&=0X1F;
 }
 else
 {
  P03=1;       //L4�ر�
  P2&=0X1F;
  P2|=0X80;
  P2&=0X1F;
 }
}