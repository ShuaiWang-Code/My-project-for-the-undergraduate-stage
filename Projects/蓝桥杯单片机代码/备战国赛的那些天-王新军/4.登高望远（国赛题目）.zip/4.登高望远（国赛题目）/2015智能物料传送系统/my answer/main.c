#include "reg52.h"
#include "iic.h"
#include "intrins.h"
#include "ultrasonic.h"

#define uchar unsigned char
#define uint  unsigned int
sbit s4=P3^3;
sbit s5=P3^2;
sbit s6=P3^1;
sbit s7=P3^0;
#define L1_ON  0xfe
#define L1_OFF 0xff
#define L2_ON  0xfd
#define L2_OFF 0xff
#define L3_ON  0xfb
#define L3_OFF 0xff
#define L4_ON  0xf7
#define L4_OFF 0xff

#define BUZZ_ON   0x40
#define BUZZ_OFF  0x00
#define RELAY_ON  0x10
#define RELAY_OFF 0x00
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar dspbuf[8]={10,10,10,10,10,10,10,10};
uchar dspcom=0;

uchar set=0;
uchar adc_value=0;
bit adc_flag=0;
uchar adc_intr=0;
uchar L3_intr=0;
bit L3_flag=0;
uchar distance=0;
bit s_flag=0;
uchar s_intr=0;
uint t=0;
uint temp;
bit s_L1=0;
char time_count1=0;//һ��
char time_count2=0;//����
bit b_r1=0;//b_r�����־λ��Ϊ�������������ͼ̵������Լ���led֮��ĸ��ŵ�
bit b_r2=0;
bit b_r3=0;
bit b_r4=0;
bit b_r5=0;
bit b_r6=0;
uchar kind=0;
uchar time_intr=0;
uchar time_count=0;
bit start=0;
uchar stop=0;


void display();
void sonic();
void delay(uchar z);
void read_key();

void main()
{
	uchar i=0;
	TMOD|=0x11;
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	TH1=0;
	TL1=0;
	EA=1;
	ET0=1;
	TR0=1;	
	P0=0;
	P2=(P2&0x1f)|0xa0;
	P2=(P2&0x1f);
	time_count1=read_eeprom(0x01);
	delay(10);
	time_count2=read_eeprom(0x02);
	delay(10);
	while(1)
	{			
		if(adc_flag==1)
		{
			adc_flag=0;
			adc_value=adc_pcf8591(0x03);
			adc_value=adc_value*47/255;
			read_key();
		}	
		
		if(adc_value<10)
		{
			s_L1=0;
			if(b_r1==0)
			{
					P0=BUZZ_OFF|RELAY_OFF;
					P2=(P2&0x1f)|0xa0;
					P2=(P2&0x1f);
					b_r1=1;
					b_r2=0;
					b_r3=0;
			}
			
			P0=(L1_ON&L2_OFF&L3_OFF&L4_OFF);
			P2=(P2&0x1f)|0x80;
			P2=(P2&0x1f);	
			if(set==0)
			{
					for(i=0;i<8;i++)
						dspbuf[i]=10;	
			}
			if(set==1)
			{
					dspbuf[0]=3;
					dspbuf[1]=dspbuf[2]=dspbuf[5]=10;
					dspbuf[3]=time_count1/10;
					dspbuf[4]=time_count1%10;
					dspbuf[6]=time_count2/10;
					dspbuf[7]=time_count2%10;
					write_eeprom(0x01,time_count1);
					delay(10);
			}
			if(set==2)
			{			
					dspbuf[0]=3;
					dspbuf[1]=dspbuf[2]=dspbuf[5]=10;
					dspbuf[3]=time_count1/10;
					dspbuf[4]=time_count1%10;
					dspbuf[6]=time_count2/10;
					dspbuf[7]=time_count2%10;
					write_eeprom(0x02,time_count2);
			}
		}
		
		if((adc_value>=10)&&(adc_value<40))
		{
			set=0;
			if(b_r2==0)
			{
					P0=BUZZ_OFF|RELAY_OFF;
					P2=(P2&0x1f)|0xa0;
					P2=(P2&0x1f);
					b_r1=0;
					b_r2=1;
					b_r3=0;
			}
			
			if(s_L1==0)
			{
					P0=(L1_OFF&L2_ON&L3_OFF&L4_OFF);
					P2=(P2&0x1f)|0x80;
					P2=(P2&0x1f);
					s_L1=1;
			}
			if(s_L1==1)
			{	
					if(start==0)
					{
							sonic();
					}
					if(start==1)
					{
							if(kind==1)
							{
									if(time_count==2)
									{
											time_count=0;
											time_count1--;
											if(time_count1<0)
											{
													start=0;
													time_count1=read_eeprom(0x01);
													delay(10);
											}
									}	
									dspbuf[0]=2;
									for(i=1;i<6;i++)
											dspbuf[i]=10;
									dspbuf[6]=time_count1/10;
									dspbuf[7]=time_count1%10;
							}
							
							if(kind==2)
							{
									if(time_count==2)
									{
											time_count=0;
											time_count2--;
											if(time_count2<0)
											{
													start=0;
													time_count2=read_eeprom(0x02);
											}										
									}
									
									dspbuf[0]=2;
											for(i=1;i<6;i++)
									dspbuf[i]=10;
									dspbuf[6]=time_count2/10;
									dspbuf[7]=time_count2%10;	
							}
							
							if(stop==0)
							{
								if(b_r4==0)
								{
									P0=RELAY_ON;
									P2=(P2&0x1f)|0xa0;
									P2=(P2&0x1f);
									P0=L2_ON&L4_OFF;
									P2=(P2&0x1f)|0x80;
									P2=(P2&0x1f);
									b_r4=1;
									b_r5=0;
									b_r6=0;
								}
							}
							if(stop==1)
							{
									if(L3_flag==0)
									{
											if(b_r5==0)
											{
													P0=RELAY_OFF;
													P2=(P2&0x1f)|0xa0;
													P2=(P2&0x1f);
													P0=L2_ON&L4_ON;
													P2=(P2&0x1f)|0x80;
													P2=(P2&0x1f);
													b_r4=0;
													b_r5=1;
													b_r6=0;
											}
									}
									else
									{
											if(b_r6==0)
											{
													P0=RELAY_OFF;
													P2=(P2&0x1f)|0xa0;
													P2=(P2&0x1f);
													P0=L2_ON&L4_OFF;
													P2=(P2&0x1f)|0x80;
													P2=(P2&0x1f);
													b_r4=0;
													b_r5=0;
													b_r6=1;
											}
									}
							}
							
					}
			}
				
		}
		
		if(adc_value>=40)
		{
			s_L1=0;
			if(b_r3==0)
			{
					P0=BUZZ_ON|RELAY_OFF;
					P2=(P2&0x1f)|0xa0;
					P2=(P2&0x1f);
					b_r1=0;
					b_r2=0;
					b_r3=1;
			}
			
			
		
			if(L3_flag==0)
			{
				P0=(L1_OFF&L2_OFF&L3_ON&L4_OFF);
				P2=(P2&0x1f)|0x80;
				P2=(P2&0x1f);
			}
			else
			{
				P0=(L1_OFF&L2_OFF&L3_OFF&L4_OFF);
				P2=(P2&0x1f)|0x80;
				P2=(P2&0x1f);
			}	
				for(i=0;i<8;i++)
						dspbuf[i]=10;
		}
		
	}
}

void isr_timer0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();
	if(++adc_intr==50)
	{
		adc_flag=1;
		adc_intr=0;
	}
	if(++L3_intr==250)
	{
		L3_intr=0;
		L3_flag=~L3_flag;
	}	
	if(++s_intr==100)
	{
		s_intr=0;
		s_flag=1;
	}
	if((start==1)&&(stop==0))
	{
			if(++time_intr==250)
			{
				time_intr=0;
				time_count++;
			}
	}
	
}


void display()
{
	P0=0xff;
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xc0;
	P2=(P2&0x1f);
	
	if(set==1)
	{
			if(dspcom==3||dspcom==4)
			{
					if(L3_flag==0)
						P0=tab[dspbuf[dspcom]];
					else
						P0=0xff;
			}
			else
					P0=tab[dspbuf[dspcom]];
	}
	if(set==2)
	{
			if(dspcom==6||dspcom==7)
			{
					if(L3_flag==0)
						P0=tab[dspbuf[dspcom]];
					else
						P0=0xff;
			}
			else
					P0=tab[dspbuf[dspcom]];
	}
	if((set!=1)&&(set!=2))
			P0=tab[dspbuf[dspcom]];

	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	if(++dspcom==8)
		dspcom=0;
}

void sonic()
{
	if(s_flag==1)
	{
		s_flag=0;
		send_wave();
		TR1=1;
		while((RX==1)&&(TF1==0));
		TR1=0;
		if(TF1==1)
		{
			TF1=0;
			distance=99;
		}
		else
		{
			t=TH1*256+TL1;
			distance=(uchar)(t*0.017);
		}
		TH1=0;
		TL1=0;
	}
	
			dspbuf[0]=1;
			dspbuf[1]=dspbuf[2]=dspbuf[5]=dspbuf[6]=10;
			dspbuf[3]=distance/10;
			dspbuf[4]=distance%10;
			if(distance<=30)
			{
				dspbuf[7]=1;
				kind=1;
			}
			else 
			{
				dspbuf[7]=2;
				kind=2;
			}
}

void delay(uchar z)
{
		uchar x,y;
		for(x=z;x>0;x--)
			for(y=0;y<114;y++);
}

void read_key()
{
		if(s4==0)
		{
				delay(10);
				if(s4==0)
				{
						while(!s4);
						start=1;
				}
		}
		
		if(start==1)
		{
				if(s5==0)
				{
						delay(10);
						if(s5==0)
						{
								while(!s5);
								stop++;
								if(stop==2)
										stop=0;
						}
				}
		}
		
		
		if(s6==0)
		{
				delay(10);
				if(s6==0)
				{
						while(!s6);
						if(adc_value<10)
						{
								set++;
								if(set==3)
									set=0;
						}
				}
		}
		
		if(s7==0)//S7���£�����		
		{
				delay(10);
				if(s7==0)
				{
						while(!s7);
						if(adc_value<10)
						{
								if(set==1)
								{
										time_count1++;
										if(time_count1>10)
												time_count1=0;
								}
								if(set==2)
								{
										time_count2++;
										if(time_count2>10)
												time_count2=0;
								}
						}
				}
		}
}

