#ifndef _ultrasonic_H
#define _ultrasonic_H

#include "reg52.h"
#include "intrins.h"
#define uchar unsigned char
#define uint  unsigned int

sbit TX=P1^0;
sbit RX=P1^1;

void send_wave()
{
	uchar i=8;
	do
	{
		TX=1;
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
    _nop_();
		_nop_();
		_nop_();
		_nop_(); 
		_nop_();
		TX=0;
		_nop_();
		_nop_();
		_nop_();
		_nop_();
		_nop_();
    _nop_();
		_nop_();
		_nop_();
		_nop_(); 
		_nop_();
	}
	while(i--);
}


#endif
