#include "reg52.h"
#include "ds1302.h"
#include "intrins.h"
#include "iic.h"
#include "absacc.h"
#define uchar unsigned char
#define uint  unsigned int

sbit s7=P3^0;
sbit s6=P3^1;
sbit s5=P3^2;
sbit s4=P3^3;
sbit TX=P1^0;
sbit RX=P1^1;

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf,0xff,0x00};
uchar dspbuf[8]={1,2,3,4,5,6,7,8};
uchar dspcom=0;
uint init_intr=0;
uint flag=0;
uchar i=0;
uchar hour,min,sec;
bit T_S=0;
bit s_flag=0;
uchar s_intr=0;
uint t=0;
uint distance=0;
int distance1=30;//��������
uchar adjust0=0;
uchar adjust1=0;
char shi,fen,miao;
bit L1_flag=0;
uchar L1_intr=0;

void display();
void delay(uchar z);
void sonic();
void key();
void sendwave();

void main()
{
		TMOD=0x11;
		TH0=(65536-2000)/256;
		TL0=(65536-2000)%256;
		TH1=0;
		TL1=0;
		EA=1;
		ET0=1;
		TR0=1;
		XBYTE[0x8000]=0xfe;
		XBYTE[0xa000]=0x40;
		
		for(i=0;i<8;i++)
		{
				dspbuf[i]=12;
		}
		
		ds1302_init(0x11,0x50,0x59);
//		write_eeprom(0,distance1);
		distance1=read_eeprom(0);
		
		while(1)
		{
				key();
				
				if(flag==1)
				{
							XBYTE[0x8000]=0xff;
							XBYTE[0xa000]=0;
							
							flag=2;
				}
			
				if(flag==2)
				{
						if(T_S==0)
						{	
								if(adjust0==0)
								{
										hour=Ds1302_Single_Byte_Read(0x84);
										min =Ds1302_Single_Byte_Read(0x82);
										sec =Ds1302_Single_Byte_Read(0x80);
										dspbuf[0]=hour/16;
										dspbuf[1]=hour%16;
										dspbuf[3]=min/16;;
										dspbuf[4]=min%16;
										dspbuf[6]=sec/16;
										dspbuf[7]=sec%16;
										dspbuf[2]=dspbuf[5]=10;
								}								
								else
								{
										dspbuf[2]=dspbuf[5]=10;
										dspbuf[0]=shi/10;
										dspbuf[1]=shi%10;
										dspbuf[3]=fen/10;
										dspbuf[4]=fen%10;
								}
								
						}
						
						if(T_S==1)
						{
								if(adjust1==0)
								{
										for(i=0;i<5;i++)
										{
												dspbuf[i]=11;
										}
										
										if(distance==999)
										{
												dspbuf[5]=dspbuf[6]=dspbuf[7]=10;
										}
										else
										{
												dspbuf[5]=distance/100;
												dspbuf[6]=distance/10%10;
												dspbuf[7]=distance%10;
										}
										
								}
								else
								{
										for(i=0;i<5;i++)
										{
												dspbuf[i]=11;
										}
										dspbuf[5]=distance1/100;
										dspbuf[6]=distance1/10%10;
										dspbuf[7]=distance1%10;
								}
						}				
				}
				
				sonic();
				if(distance<distance1)//����
				{
						XBYTE[0xa000]=0x40;
				}
				else
				{
						XBYTE[0xa000]=0;
				}
				
				if(distance<1.2*distance1)
				{
						if(L1_flag==0)
						{
								XBYTE[0x8000]=0xfe;
						}
						if(L1_flag==1)
						{
								XBYTE[0x8000]=0xff;
						}
						
				}
				else
				{
						XBYTE[0x8000]=0xff;
				}
				
		}
}

void isr_timer0() interrupt 1
{
		TH0=(65536-2000)/256;
		TL0=(65536-2000)%256;
		display();
		
		if(flag==0)
		{
				if(++init_intr==500)
				{
						flag=1;
				}
		}
		
		if(++L1_intr==250)
		{
				L1_flag=~L1_flag;
				L1_intr=0;
		}
		
		if(++s_intr==100)
		{
				s_intr=0;
				s_flag=1;
		}
}

void display()
{
		XBYTE[0xe000]=0xff;
		XBYTE[0xc000]=1<<dspcom;
		
		if((adjust0==1)||(adjust0==2))
		{
					if(adjust0==1)
					{
							if((dspcom==0)||(dspcom==1))
							{
									if(L1_flag==1)
										{
												XBYTE[0xe000]=0xff;
										}
										else
										{
												XBYTE[0xe000]=tab[dspbuf[dspcom]];
										}
							}
							else
							{
										XBYTE[0xe000]=tab[dspbuf[dspcom]];
							}
					}
					
					if(adjust0==2)
					{
							if((dspcom==3)||(dspcom==4))
							{
									if(L1_flag==1)
										{
												XBYTE[0xe000]=0xff;
										}
										else
										{
												XBYTE[0xe000]=tab[dspbuf[dspcom]];
										}
							}
							else
							{
										XBYTE[0xe000]=tab[dspbuf[dspcom]];
							}
					}
		}
		
		else
		{
				XBYTE[0xe000]=tab[dspbuf[dspcom]];
		}
	
		if((adjust0!=1)&&(adjust0!=2))
		{
				XBYTE[0xe000]=tab[dspbuf[dspcom]];
		}
		
		if(++dspcom==8)
				dspcom=0;		
}

void key()
{
		if(s7==0)
		{
				delay(10);
				if(s7==0)
				{
						while(!s7);
						T_S=~T_S;
				}
		}
		
		if(T_S==0)
		{
				if(s6==0)
				{
						delay(10);
						if(s6==0)
						{
								while(!s6);
								adjust0++;
								if(adjust0==1)
								{
										shi=hour/16*10+hour%16;
										fen=min /16*10+ min%16;
										miao=sec/16*10+ sec%16;
								}
								if(adjust0>2)
								{
										adjust0=0;
										ds1302_init(shi/10*16+shi%10,fen/10*16+fen%10,miao/10*16+miao%10);
								}
						}
				}
				
				if(adjust0==1)
				{
						if(s5==0)
						{
								delay(10);
								if(s5==0)
								{
										while(!s5);
										shi++;
										if(shi>24)
										{
												shi=0;
										}
								}
						}
						
						if(s4==0)
						{
								delay(10);
								if(s4==0)
								{
										while(!s4);
										shi--;
										if(shi<0)
										{
												shi=24;
										}
								}
						}
						
				}
				
				if(adjust0==2)
				{
						if(s5==0)
						{
								delay(10);
								if(s5==0)
								{
										while(!s5);
										fen++;
										if(fen>59)
										{
												fen=0;
										}
								}
						}
						
						if(s4==0)
						{
								delay(10);
								if(s4==0)
								{
										while(!s4);
										fen--;
										if(fen<0)
										{
												fen=59;
										}
								}
						}
						
				}
		}
		
		if(T_S==1)
		{
				if(s6==0)
				{
						delay(10);
						if(s6==0)
						{
								while(!s6);
								adjust1++;
								if(adjust1>1)
								{
										adjust1=0;
										write_eeprom(0,distance1);
								}
						}
				}
				
				if(adjust1==1)
				{
						if(s5==0)
						{
								delay(10);
								if(s5==0)
								{
										while(!s5);
										distance1++;
										if(distance1>100)
										{
												distance1=0;
										}
								}
						}
						
						if(s4==0)
						{
								delay(10);
								if(s4==0)
								{
										while(!s4);
										distance1--;
										if(distance1<0)
										{
												distance1=100;
										}
								}
						}					
				}
		}	
}

void delay(uchar z)
{
		uchar x,y;;
		for(x=z;x>0;x--)
				for(y=0;y<114;y++);
}

void sonic()
{
		if(s_flag==1)
		{
				s_flag=0;
				sendwave();
				TR1=1;
				while((RX==1)&&(TF1==0));
				TR1=0;
				if(TF1==1)
				{
						TF1=0;
						distance=999;
				}
				else
				{
						t=TH1*256+TL1;
						distance=(uint)(t*0.017);
				}
				TH1=0;
				TL1=0;				
		}
}

void sendwave()
{
		uchar j=8;
		do
		{
				TX=1;
				_nop_();_nop_();_nop_();_nop_();_nop_();
				_nop_();_nop_();_nop_();_nop_();_nop_();
				TX=0;
				_nop_();_nop_();_nop_();_nop_();_nop_();
				_nop_();_nop_();_nop_();_nop_();_nop_();
		}
		while(j--);
}