#include "STC15F2K60S2.h"
#include "onewire.h"
#include "ds1302.h"
#include "iic.h"
#include "stdio.h"
#define uchar unsigned char
#define uint  unsigned int
sbit s4=P3^3;
sbit s5=P3^2;

#define FOSC 11059200L 
#define BAUD 115200
//                                                                         C    H    -
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xc6,0x89,0xbf};
uchar dspbuf[8]={10,10,10,10,10,10,10,10};
uchar dspcom=0;
uchar mode=0;
uchar state=0;
int wendu[2];
uchar wendu0=0;
bit adc_flag=0;
uint adc_intr=0;
uchar shidu0=0;
int shidu[2];
uchar guang=0;
int guang_flag=0;
uchar i=0,j=0,k=0;
uchar ad_channel=0;
char string2[6]={'A','A','A','S','S','S'};
char string1[20];
bit string_flag=0;
int time[6];
int time1[6];//��¼�ӽ�ʱ��
uchar time0;
bit time_flag=0;
uint time_intr=0;
bit uart_flag=0;
int trans_intr=0;
bit trans_flag=0;
uint time_count=0;
int t=0;
bit t_flag=0;
uchar record_flag=1;
int arry[10];//��ŵ�ǰ�����Ϣ
int arry1[10];//��ȡǰһ��ֵ
char str[40];

void display();
void delay(uchar z);
void senddata(uchar dat);
void sendstring(char *s);
void key();
void send1();//�¶ȣ�ʪ�ȣ�ʱ�䣬�������忿��
void send2();//�¶ȣ�ʪ�ȣ��ӽ�ʱ�䣬ͣ��ʱ��
void main()
{
	TMOD|=0x11;
	SCON=0x50;
	AUXR = 0x14;  //T21Ϊģʽ, ��������ʱ��2
  AUXR |= 0x01;//ѡ��ʱ��2Ϊ����1�Ĳ�����
	T2L = (65536 - (FOSC/4/BAUD));
	T2H = (65536 - (FOSC/4/BAUD))>>8;	
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	TH1=(65536-50000)/256;
	TL1=(65536-50000)/256;
	EA=1;
	ES=1;
	ET0=1;
	ET1=1;
	TR0=1;
	P0=0;
	P2=(P2&0x1f)|0xa0;
	P2=(P2&0x1f);
	P0=0xff;
	P2=(P2&0x1f)|0x80;
	P2=(P2&0x1f);
	init_ds1302(0x23,0x59,0x55);
	guang=adc_pcf8591(1);//Ԥ��������ʼ���������ȶ�
	while(1)
	{
		key();
		
		wendu0=read_ds18b20_data();
		wendu[0]=wendu0/10;
		wendu[1]=wendu0%10;
		

	if(adc_flag==1)
		{
			adc_flag=0;
			switch(ad_channel)
			{
				case 0:guang=adc_pcf8591(1);break;//����
				

//	  		  case 1:shidu0=adc_pcf8591(3);break;//��λ��

			}
		}
		if(++ad_channel>2)
			ad_channel=0;
	

		shidu0=shidu0*99/255;
		shidu[0]=shidu0/10;
		shidu[1]=shidu0%10;

		time0=Ds1302_Single_Byte_Read(ds1302_hr_addr);
		time[0]=time0/16;
		time[1]=time0%16;
		time0=Ds1302_Single_Byte_Read(ds1302_min_addr);
		time[2]=time0/16;
		time[3]=time0%16;
		time0=Ds1302_Single_Byte_Read(ds1302_sec_addr);
		time[4]=time0/16;
		time[5]=time0%16;
		
		
		if(guang<100)//��L3
		{
			guang_flag=1;		
			if(t_flag==0)
			{
				t_flag=1;
				time_count=0;
				TH1=(65536-50000)/256;
	      TL1=(65536-50000)/256;
				
				for(k=0;k<6;k++)
					time1[k]=time[k];
				arry[1]=shidu0;
				arry[0]=wendu0;
				for(k=0;k<6;k++)
					arry[k+2]=time1[k];
			}
			
			TR1=1;
			record_flag=0;
		}
		if(guang>=100)//Ϩ��L3
		{
			guang_flag=0;
			TR1=0;
			t_flag=0;
			if(record_flag==0)//д���¶ȣ�ʪ�ȣ��ӽ�ʱ�䣬ͣ��ʱ��
			{
				record_flag=1;
				arry[8]=t/100;
				arry[9]=t%100;
//				if(j<5)
//				{
//					for(k=0;k<10;k++)
//					{
//						write_eeprom(j*10+k,arry[k]);
//						delay(10);
//					}
//					j++;
//				}
//				if(j>=5)
//				{
						for(j=1;j<=4;j++)	
						{
							for(k=0;k<10;k++)
							{
								arry1[k]=read_eeprom(j*10+k);
								delay(10);
							}
							for(k=0;k<10;k++)
							{
								write_eeprom((j-1)*10+k,arry1[k]);
								delay(10);
							}
						}
					for(k=0;k<10;k++)
					{
						write_eeprom(4*10+k,arry[k]);
						delay(10);
					}
//					j=5;
//				}	
			}
		}
		
		t=time_count*5/100;
		if(mode==0)//�Զ�����ģʽ
		{
			if(guang_flag==0)
			{
				P0=0xfe;
				P2=(P2&0x1f)|0x80;
				P2=(P2&0x1f);
			}
			if(guang_flag==1)
			{
				P0=0xfa;
				P2=(P2&0x1f)|0x80;
				P2=(P2&0x1f);
			}
			
			if(uart_flag==1)
			{
				uart_flag=0;
				for(i=0;i<6;i++)
				{
					if(string1[i]==string2[i])
					{
						string_flag=1;
					}
					else
					{
						string_flag=0;
						break;
					}
				}		
				i=0;			
			}
			if(string_flag==1)
			{
				if(trans_flag==1)
				{
					trans_flag=0;
					send1();
				}			
			}
		}
		if(mode==1)//�Զ���¼ģʽ
		{
			if(guang_flag==0)
			{
				P0=0xfd;
				P2=(P2&0x1f)|0x80;
				P2=(P2&0x1f);
			}
			if(guang_flag==1)
			{
				P0=0xf9;
				P2=(P2&0x1f)|0x80;
				P2=(P2&0x1f);
			}
			
			if(uart_flag==1)
			{
				uart_flag=0;
				for(i=0;i<6;i++)
				{
					if(string1[i]==string2[i])
					{
						string_flag=1;
					}
					else
					{
						string_flag=0;
						break;
					}
				}				
				i=0;			
			}
			if(string_flag==1)
			{
				if(trans_flag==1)
				{
					trans_flag=0;
					send2();
				}			
			}
			
		}

	if(state==0)//�������ʾ��ǰ�¶ȡ�ʪ��
		{
			dspbuf[0]=wendu[0];
			dspbuf[1]=wendu[1];
			dspbuf[2]=11;
			dspbuf[3]=dspbuf[4]=10;
			dspbuf[5]=shidu[0];
			dspbuf[6]=shidu[1];
			dspbuf[7]=12;	
		}

		if(state==1)//�������ʾ��ǰʱ��
		{		
			dspbuf[0]=time[0];
			dspbuf[1]=time[1];
			dspbuf[3]=time[2];
			dspbuf[4]=time[3];
			dspbuf[6]=time[4];
			dspbuf[7]=time[5];
			if(time_flag==0)
				dspbuf[2]=dspbuf[5]=13;
			else
				dspbuf[2]=dspbuf[5]=10;
		}
	
		if(state==2)//�������ʾͣ��ʱ��
		{
			dspbuf[0]=dspbuf[1]=dspbuf[2]=10;
			dspbuf[3]=13;
			dspbuf[4]=t/1000;
			dspbuf[5]=t/100%10;
			dspbuf[6]=t/10%10;
			dspbuf[7]=t%10;
		}
	}
}

void isr_timer0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65537-2000)%256;
	display();
	
	if(++adc_intr==20)
		{
			adc_intr=0;
			adc_flag=1;
		}
	
	if(++time_intr==250)
	{
		time_intr=0;
		time_flag=~time_flag;
	}
	
	if(++trans_intr==500)
	{
		trans_intr=0;
		trans_flag=1;
	}
}

void isr_timer1() interrupt 3//���ڼ�ʱ
{
	TH1=(65536-50000)/256;
	TL1=(65536-50000)/256;
	time_count++;
}


void sendstring(char *s)
{
	while(*s)
	{
		senddata(*s++);
	}
}

void senddata(uchar dat)
{
	SBUF=dat;
	while(!TI);
}

void uart() interrupt 4 using 3//���ڴ���
{
	if(RI==1)
	{
		RI=0;
		string1[i++]=SBUF;
		if(i==6)
			uart_flag=1;
	}
	if(TI==1)
	{
		TI=0;
	}
}

void display()
{
	P0=0xff;
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xc0;
	P2=(P2&0x1f);
	P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	if(++dspcom==8)
		dspcom=0;
}

void delay(uchar z)
{
	uchar x,y;
	for(x=z;x>0;x--)
		for(y=0;y<114;y++);
}

void key()
{
	if(s4==0)
		{
			delay(10);
			if(s4==0)
			{
				while(!s4);
				mode++;
				if(mode==2)
					mode=0;
			}
		}
		if(s5==0)
		{
			delay(10);
			if(s5==0)
			{
				while(!s5);
				state++;
				if(state==3)
					state=0;
			}
		}
}

void send1()//���ڷ����¶ȣ�ʪ�ȣ�ʱ�䣬�������忿��
{

	sprintf(str,"%c%d%d%c%d%d%c%c",'{',wendu[0],wendu[1],'-',shidu[0],shidu[1],'%','}');//�¶ȣ�ʪ��
	sendstring(str);
	sprintf(str,"{%d%d-%d%d-%d%d}{%d}\r\n",time[0],time[1],time[2],time[3],time[4],time[5],guang_flag);//ʱ�䣬�������忿��
	sendstring(str);
}

void send2()//���ڷ����¶ȣ�ʪ�ȣ��ӽ�ʱ�䣬ͣ��ʱ��
{
	//��EEPROM�е��¶ȣ�ʪ�ȣ��ӽ�ʱ�䣬ͣ��ʱ��
	for(j=0;j<5;j++)
	{
//		for(k=0;k<10;k++)
//		{
//			arry1[k]=read_eeprom(j*10+k);
//			delay(10);
//		}
		sprintf(str,"%c%d%d%c%d%d%c%c",'{',arry1[0]/10,arry1[0]%10,'-',arry1[1]/10,arry1[1]%10,'%','}');//�¶ȣ�ʪ��
		sendstring(str);
		sprintf(str,"%c%d%d-%d%d-%d%d%c",'{',arry1[2],arry1[3],arry1[4],arry1[5],arry1[6],arry1[7],'}');//
		sendstring(str);
		sprintf(str,"%c%d%c\r\n",'{',arry1[8]*100+arry1[9],'}');//ͣ��ʱ��
		sendstring(str);
	}
	sendstring("\r\n");
		
//  sprintf(str,"%c%d%d%c%d%d%c%c",'{',wendu[0],wendu[1],'-',shidu[0],shidu[1],'%','}');//�¶ȣ�ʪ��
//	sendstring(str);
//	sprintf(str,"{%d%d-%d%d-%d%d}{%d}\r\n",time1[0],time1[1],time1[2],time1[3],time1[4],time1[5],t);//ʱ�䣬�������忿��
//	sendstring(str);
}