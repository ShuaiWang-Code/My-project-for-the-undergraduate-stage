#include "STC15F2K60S2.h"
#define uchar unsigned char 
#define uint  unsigned char 

#define FOSC 11059200L
#define BAUD 115200
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar dspbuf[8]={10,10,10,10,10,10,0,0};
uchar dspcom=0;
uchar intr=0;
bit flag=0;

void senddata(uchar dat);
void sendstring(char*s);
void display();


void main()
{
	TMOD|=0x21;
	SCON=0x50;
	AUXR=0x40;
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	TH1=256-FOSC/BAUD/32;
	TL1=256-FOSC/BAUD/32;
	EA=1;
	ES=1;
	ET0=1;
	TR1=1;
	TR0=1;
	sendstring("ok");
	while(1);
}

void isr_timer0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();
	if(++intr==250)
	{
		flag=1;
		intr=0;
	}
}

void display()
{
	
	P0=0xff;
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xc0;
	P2=(P2&0x1f);
	
	P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	
	
	if(++dspcom==8)
		dspcom=0;
}

void sendstring(char*s)
{
		while(*s)
		{
				senddata(*s++);
		}
}

void senddata(uchar dat)
{
		SBUF=dat;
		while(!TI);
}

void uart() interrupt 4 using 3
{
		if(RI)
		{
				RI=0;
//				da=SBUF;
		}
		if(TI)
		{
				TI=0;
		}
}