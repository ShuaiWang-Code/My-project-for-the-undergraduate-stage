#include "STC15F2K60S2.h"
#include "intrins.h"

typedef unsigned char BYTE;
typedef unsigned int WORD;

#define FOSC 11059200L          //????
#define BAUD 115200             //?????

#define NONE_PARITY     0       //???
#define ODD_PARITY      1       //???
#define EVEN_PARITY     2       //???
#define MARK_PARITY     3       //????
#define SPACE_PARITY    4       //????

#define PARITYBIT EVEN_PARITY   //?????


#define S1_S0 0x40              //P_SW1.6
#define S1_S1 0x80              //P_SW1.7


bit busy;

void SendData(BYTE dat);
void SendString(char *s);

code BYTE mycode[]=
"\
#define uchar unsigned char\r\n \
#define uint  unsigned int\r\n \
\r\n \
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};\r\n \
uchar dspbuf[8]={10,10,10,10,10,10,10,10};\r\n \
uchar dspcom=0;\r\n \
uchar intr=0;\r\n \
bit s_flag=0;\r\n \
uint distance=0;\r\n \
uint t=0;\r\n \
\r\n \
void display();\r\n \
\r\n \
void main()\r\n \
{\r\n \
	TMOD|=0x11;\r\n \
	TH0=(65536-2000)/256;\r\n \
	TL0=(65536-2000)%256;\r\n \
	TH1=0;\r\n \
	TL1=0;\r\n \
	EA=1;\r\n \
	ET0=1;\r\n \
	TR0=1;\r\n \
//	ET1=1;\r\n \
	TR1=0;\r\n \
	P2=(P2&0x1f)|0xa0;\r\n \
	P0=0;\r\n \
	P2=(P2&0x1f);\r\n \
	while(1)\r\n \
	{\r\n \
			if(s_flag==1)\r\n \
			{\r\n \
				s_flag=0;\r\n \
				send_wave();\r\n \
				TR1=1;\r\n \
				while((RX==1)&&(TF1==0));\r\n \
				TR1=0;\r\n \
				if(TF1==1)\r\n \
				{\r\n \
					TF1=0;\r\n \
					distance=999;\r\n \
				}\r\n \
				else\r\n \
				{\r\n \
					t=TH1*256+TL1;\r\n \
					distance=(uint)(t*0.017);\r\n \			
				}\r\n \
				TH1=0;\r\n \
				TL1=0;\r\n \
			}\r\n \
			dspbuf[5]=distance/100;\r\n \
			dspbuf[6]=distance%100/10;\r\n \
			dspbuf[7]=distance%10;\r\n \
	}\r\n \
}\r\n \
\r\n \
void isr_timer0() interrupt 1\r\n \
{\r\n \
	TH0=(65536-2000)/256;\r\n \
	TL0=(65536-2000)%256;\r\n \
	display();\r\n \
	if(++intr==100)\r\n \
	{\r\n \
		intr=0;\r\n \
		s_flag=1;\r\n \
	}\r\n \
}\r\n \
\r\n \
void display()\r\n \
{\r\n \
	P0=0xff;\r\n \
	P2=(P2&0x1f)|0xe0;\r\n \
	P2=(P2&0x1f);\r\n \
	\r\n \
	P0=1<<dspcom;\r\n \
	P2=(P2&0x1f)|0xc0;\r\n \
	P2=(P2&0x1f);\r\n \
	\r\n \
	\r\n \
	P0=tab[dspbuf[dspcom]];\r\n \
	P2=(P2&0x1f)|0xe0;\r\n \
	P2=(P2&0x1f);\r\n \
\r\n \
	if(++dspcom==8)\r\n \
		dspcom=0;\r\n \
}\r\n \
#define somenop {_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_(); _nop_();}\r\n  \
sbit TX=P1^0;\r\n  \
sbit RX=P1^1;\r\n  \
\r\n  \
void send_wave()\r\n  \
{\r\n  \
	uchar i=8;\r\n  \
	do\r\n  \
	{\r\n  \
		TX=1;\r\n  \
		somenop;\r\n  \
		TX=0;\r\n  \
		somenop;\r\n  \
	}\r\n  \
	while(i--);\r\n  \
}\r\n  \
uchar key_press=0;\r\n  \
bit key_re=0;\r\n  \
\r\n  \
uchar read_keyboard()\r\n  \
{\r\n  \
	uchar key_value;\r\n  \
	uchar key_temp;\r\n  \
	uchar col;\r\n  \
	\r\n  \
	P3=0xf0;P4|=0x14;\r\n  \
	key_temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);\r\n  \
	if(key_temp!=0xf0)\r\n  \
		key_press++;\r\n  \
	else\r\n  \
		key_press=0;\r\n  \
	if(key_press==3)\r\n  \
	{\r\n  \
		key_re=1;\r\n  \
		key_press=0;\r\n  \
		switch(key_temp)\r\n  \
		{\r\n  \
			case 0x70:col=1;break;\r\n  \
			case 0xb0:col=2;break;\r\n  \
			case 0xd0:col=3;break;\r\n  \
			case 0xe0:col=4;break;\r\n  \
		}\r\n  \
		P3=0x0f;P4&=0xeb;\r\n  \
		key_temp=(P3&0x0f);\r\n  \
		switch(key_temp)\r\n  \
		{\r\n  \
			case 0x0e:key_value=col-1;break;\r\n  \
			case 0x0d:key_value=col+3;break;\r\n  \
			case 0x0b:key_value=col+7;break;\r\n  \
			case 0x07:key_value=col+11;break;\r\n  \
		}	\r\n  \
	}\r\n  \
	P3=0x0f;P4&=0xeb;\r\n  \
	key_temp=(P3&0x0f);\r\n  \
	if((key_re==1)&&(key_temp==0x0f))\r\n  \
	{\r\n  \
		key_re=0;\r\n  \
		return key_value;\r\n  \
	}\r\n  \
	else \r\n  \
		return 0xff;\r\n  \
}\r\n  \
\r\n  \
void ds1302_init()\r\n  \
{\r\n  \
	Ds1302_Single_Byte_Write(ds1302_control_addr, 0x00);\r\n  \
	Ds1302_Single_Byte_Write(ds1302_hr_addr, 0x23);\r\n  \
	Ds1302_Single_Byte_Write(ds1302_min_addr, 0x55);\r\n  \
	Ds1302_Single_Byte_Write(ds1302_sec_addr, 0x50);\r\n  \
	Ds1302_Single_Byte_Write(ds1302_control_addr, 0x80);\r\n  \
}\r\n  \
\r\n  \
unsigned char read_ds18b20_data()\r\n  \
{\r\n  \
	unsigned char low,high,da;\r\n  \
	Init_DS18B20();\r\n  \
	Write_DS18B20(0xcc);\r\n  \
	Write_DS18B20(0x44);\r\n  \
	Init_DS18B20();\r\n  \
	Write_DS18B20(0xcc);\r\n  \
	Write_DS18B20(0xbe);\r\n  \
	\r\n  \
	low=Read_DS18B20();\r\n  \
	high=Read_DS18B20();\r\n  \
	da=(low>>4)|(high<<4);\r\n  \
	return da;\r\n  \
}\r\n  \
\r\n  \
#define OW_SKIP_ROM 0xcc\r\n  \
#define DS18B20_CONVERT 0x44\r\n  \
#define DS18B20_READ 0xbe\r\n  \
\r\n  \
\r\n  \
void dac_pcf8591(unsigned char dat)\r\n  \
{\r\n  \
	IIC_Start();\r\n  \
	IIC_SendByte(0x90);\r\n  \
	IIC_WaitAck();\r\n  \
	IIC_SendByte(0x40);\r\n  \
	IIC_WaitAck();\r\n  \
	IIC_SendByte(dat);\r\n  \
	IIC_WaitAck();\r\n  \
	IIC_Stop();  \r\n  \
}\r\n  \
\r\n  \
#define SlaveAddrW 0xA0\r\n  \
#define SlaveAddrR 0xA1\r\n  \
\r\n  \
\r\n  \
unsigned char adc_pcf8591(unsigned char chn)\r\n  \
{\r\n  \
	unsigned char da;\r\n  \
	IIC_Start();\r\n  \
	\r\n  \
	IIC_SendByte(0x90);\r\n  \
	IIC_WaitAck();\r\n  \
	\r\n  \
	IIC_SendByte(0x40|chn);\r\n  \
	IIC_WaitAck();\r\n  \
	\r\n  \
	IIC_Start();\r\n  \
	\r\n  \
	IIC_SendByte(0x91);\r\n  \
	IIC_WaitAck();\r\n  \
	\r\n  \
	da=IIC_RecByte();\r\n  \
	IIC_Ack(0);\r\n  \
	\r\n  \
	IIC_Stop();\r\n  \
	return da;\r\n  \
}\r\n  \
\r\n  \
void write_eeprom(unsigned char add,unsigned char val)\r\n  \
{\r\n  \
		IIC_Start();\r\n  \
		\r\n  \
		IIC_SendByte(0xa0);\r\n  \
		IIC_WaitAck();\r\n  \
		\r\n  \
		IIC_SendByte(add);\r\n  \
		IIC_WaitAck();\r\n  \
		\r\n  \
		IIC_SendByte(val);\r\n  \
		IIC_WaitAck();\r\n  \
		\r\n  \
		IIC_Stop();\r\n  \
}\r\n  \
\r\n  \
unsigned char read_eeprom(unsigned char add)\r\n  \
{\r\n  \
		unsigned char da;\r\n  \
		\r\n  \
		IIC_Start();\r\n  \
		\r\n  \
		IIC_SendByte(0xa0);\r\n  \
		IIC_WaitAck();\r\n  \
		\r\n  \
		IIC_SendByte(add);\r\n  \
		IIC_WaitAck();\r\n  \
		\r\n  \
		IIC_Start();\r\n  \
		\r\n  \
		IIC_SendByte(0xa1);\r\n  \
		IIC_WaitAck();\r\n  \
		\r\n  \
		da=IIC_RecByte();\r\n  \
		IIC_Ack(0);\r\n  \
		\r\n  \
		IIC_Stop();\r\n  \
		\r\n  \
		return da;\r\n  \
}\r\n  \
\r\n  \
iic.h\r\n  \
#define DELAY_TIME 5    \r\n \
sbit scl = P2^0;    \r\n \
sbit sda = P2^1;    \r\n \
void i2c_delay(unsigned char i) \r\n \
{   \r\n \
    do  \r\n \
    {   \r\n \
        _nop_();    \r\n \
    }   \r\n \
    while(i--);         \r\n \
}   \r\n \
void i2c_start(void)    \r\n \
{   \r\n \
    sda = 1;    \r\n \
    scl = 1;    \r\n \
    i2c_delay(DELAY_TIME);  \r\n \
    sda = 0;    \r\n \
    i2c_delay(DELAY_TIME);  \r\n \
    scl = 0;        \r\n \
}   \r\n \
void i2c_stop(void) \r\n \
{   \r\n \
    sda = 0;    \r\n \
    scl = 1;    \r\n \
    i2c_delay(DELAY_TIME);  \r\n \
    sda = 1;    \r\n \
    i2c_delay(DELAY_TIME);          \r\n \
}   \r\n \
void i2c_sendbyte(unsigned char byt)    \r\n \
{   \r\n \
    unsigned char i;    \r\n \
	EA = 0;    \r\n \
    for(i=0; i<8; i++){ \r\n \
        scl = 0;    \r\n \
        i2c_delay(DELAY_TIME);  \r\n \
        if(byt & 0x80){ \r\n \
            sda = 1;    \r\n \
        }   \r\n \
        else{   \r\n \
            sda = 0;    \r\n \
        }   \r\n \
        i2c_delay(DELAY_TIME);  \r\n \
        scl = 1;    \r\n \
        byt <<= 1;  \r\n \
        i2c_delay(DELAY_TIME);  \r\n \
    }   \r\n \
	EA = 1;    \r\n \
    scl = 0;    \r\n \
}   \r\n \
unsigned char i2c_waitack(void) \r\n \
{   \r\n \
	unsigned char ackbit;  \r\n \
	   \r\n \
    scl = 1;    \r\n \
    i2c_delay(DELAY_TIME);  \r\n \
    ackbit = sda;   \r\n \
    scl = 0;    \r\n \
    i2c_delay(DELAY_TIME);  \r\n \
	   \r\n \
	return ackbit; \r\n \
}   \r\n \
unsigned char i2c_receivebyte(void) \r\n \
{   \r\n \
	unsigned char da;  \r\n \
	unsigned char i;   \r\n \
	EA = 0;	   \r\n \
	for(i=0;i<8;i++){      \r\n \
		scl = 1;  \r\n \
		i2c_delay(DELAY_TIME);    \r\n \
		da <<= 1; \r\n \
		if(sda)   \r\n \
			da |= 0x01;  \r\n \
		scl = 0;  \r\n \
		i2c_delay(DELAY_TIME);    \r\n \
	}  \r\n \
	EA = 1;    \r\n \
    \r\n \
	return da;     \r\n \
}   \r\n \
void i2c_sendack(unsigned char ackbit)  \r\n \
{   \r\n \
    scl = 0;    \r\n \
    sda = ackbit;   \r\n \
    i2c_delay(DELAY_TIME);  \r\n \
    scl = 1;    \r\n \
    i2c_delay(DELAY_TIME);  \r\n \
    scl = 0;    \r\n \
	sda = 1;   \r\n \
    i2c_delay(DELAY_TIME);  \r\n \
}   \r\n \
void operate_delay(unsigned char t) \r\n \
{   \r\n \
	unsigned char i;   \r\n \
	   \r\n \
	while(t--){    \r\n \
		for(i=0; i<112; i++); \r\n \
	}  \r\n \
}   \r\n \
void write_eeprom(unsigned char add,unsigned char val)  \r\n \
{   EA=0;   \r\n \
    i2c_start();    \r\n \
    i2c_sendbyte(0xa0); \r\n \
    i2c_waitack();  \r\n \
    i2c_sendbyte(add);  \r\n \
    i2c_waitack();  \r\n \
    i2c_sendbyte(val);  \r\n \
    i2c_waitack();  \r\n \
    i2c_stop(); \r\n \
  EA=1; \r\n \
}   \r\n \
unsigned char read_eeprom(unsigned char add)    \r\n \
{   \r\n \
	unsigned char da;  \r\n \
  EA=0; \r\n \
	i2c_start();   \r\n \
	i2c_sendbyte(0xa0);    \r\n \
	i2c_waitack(); \r\n \
	i2c_sendbyte(add); \r\n \
	i2c_waitack(); \r\n \
	i2c_start();   \r\n \
	i2c_sendbyte(0xa1);    \r\n \
	i2c_waitack(); \r\n \
	da = i2c_receivebyte();    \r\n \
	i2c_sendack(0);    \r\n \
	i2c_stop();    \r\n \
	EA=1;  \r\n \
	return da; \r\n \
}   \r\n \
void guang_init_pcf8591(void)   \r\n \
{   \r\n \
	i2c_start();   \r\n \
	i2c_sendbyte(0x90);    \r\n \
	i2c_waitack(); \r\n \
	i2c_sendbyte(0x01);    \r\n \
	i2c_waitack(); \r\n \
	i2c_stop();    \r\n \
	operate_delay(10); \r\n \
}   \r\n \
    \r\n \
void Rb2_init_pcf8591(void) \r\n \
{   \r\n \
	i2c_start();   \r\n \
	i2c_sendbyte(0x90);    \r\n \
	i2c_waitack(); \r\n \
	i2c_sendbyte(0x03);    \r\n \
	i2c_waitack(); \r\n \
	i2c_stop();    \r\n \
	operate_delay(10); \r\n \
}   \r\n \
unsigned char adc_pcf8591(void) \r\n \
{   \r\n \
	unsigned char temp;    \r\n \
    \r\n \
	i2c_start();   \r\n \
	i2c_sendbyte(0x91);    \r\n \
	i2c_waitack(); \r\n \
	temp = i2c_receivebyte();  \r\n \
	i2c_sendack(1);    \r\n \
	i2c_stop();    \r\n \
	   \r\n \
	return temp;   \r\n \
}   \r\n \
    \r\n \
		void Delay_OneWire(unsigned int t)  \r\n \
{   \r\n \
    unsigned char n;    \r\n \
        \r\n \
        while(t--)  \r\n \
        for(n=0;n<12;n++);  \r\n \
}   \r\n \
float Get_18b20()   \r\n \
{   \r\n \
    unsigned int high,low,da;   \r\n \
    float tem;  \r\n \
    \r\n \
    Init_DS18B20(); \r\n \
    Write_DS18B20(0xcc);    \r\n \
    Write_DS18B20(0x44);    \r\n \
    \r\n \
    Init_DS18B20(); \r\n \
    Write_DS18B20(0xcc);    \r\n \
    Write_DS18B20(0xbe);    \r\n \
    \r\n \
    low=Read_DS18B20(); \r\n \
    high=Read_DS18B20();    \r\n \
    \r\n \
    da=high&0x0f;   \r\n \
    da<<=8; \r\n \
    da|=low;    \r\n \
    \r\n \
    tem=da*0.0625;  \r\n \
    return tem; \r\n \
}   \r\n \
\r\n \
\r\n \
void uart() interrupt 4 using 3\r\n \
{\r\n \
	if(RI==1)\r\n \
	{\r\n \
		RI=0;\r\n \
		string1[i++]=SBUF;\r\n \
		if(i==6)\r\n \
			uart_flag=1;\r\n \
	}\r\n \
	if(TI==1)\r\r\n \
	{\r\n \
		TI=0;\r\n \
	}\r\n \
}\r\n \
\r\n \
\r\n \
#define ds1302_sec_addr			0x80   (miao)\r\n \
 0x82,0x84,0x86,0x88,0x8A(day),0x8C(year)\r\n \
";

void main()
{
    P0M0 = 0x00;
    P0M1 = 0x00;
    P1M0 = 0x00;
    P1M1 = 0x00;
    P2M0 = 0x00;
    P2M1 = 0x00;
    P3M0 = 0x00;
    P3M1 = 0x00;
    P4M0 = 0x00;
    P4M1 = 0x00;
    P5M0 = 0x00;
    P5M1 = 0x00;
    P6M0 = 0x00;
    P6M1 = 0x00;
    P7M0 = 0x00;
    P7M1 = 0x00;

    ACC = P_SW1;
    ACC &= ~(S1_S0 | S1_S1);    //S1_S0=0 S1_S1=0
    P_SW1 = ACC;                //(P3.0/RxD, P3.1/TxD)
    

#if (PARITYBIT == NONE_PARITY)
    SCON = 0x50;                //8??????
#elif (PARITYBIT == ODD_PARITY) || (PARITYBIT == EVEN_PARITY) || (PARITYBIT == MARK_PARITY)
    SCON = 0xda;                //9??????,??????1
#elif (PARITYBIT == SPACE_PARITY)
    SCON = 0xd2;                //9??????,??????0
#endif

    T2L = (65536 - (FOSC/4/BAUD));   //????????
    T2H = (65536 - (FOSC/4/BAUD))>>8;
    AUXR = 0x14;                //T2?1T??, ??????2
    AUXR |= 0x01;               //?????2???1???????
    ES = 1;                     //????1??
    EA = 1;

    SendString(mycode);
    while(1);
}

/*----------------------------
UART ??????
-----------------------------*/
void Uart() interrupt 4 using 1
{
    if (RI)
    {
        RI = 0;                 //??RI?
        P0 = SBUF;              //P0??????
        P22 = RB8;              //P2.2?????
    }
    if (TI)
    {
        TI = 0;                 //??TI?
        busy = 0;               //????
    }
}

/*----------------------------
??????
----------------------------*/
void SendData(BYTE dat)
{
    while (busy);               //???????????
    ACC = dat;                  //?????P (PSW.0)
    if (P)                      //??P??????
    {
#if (PARITYBIT == ODD_PARITY)
        TB8 = 0;                //??????0
#elif (PARITYBIT == EVEN_PARITY)
        TB8 = 1;                //??????1
#endif
    }
    else
    {
#if (PARITYBIT == ODD_PARITY)
        TB8 = 1;                //??????1
#elif (PARITYBIT == EVEN_PARITY)
        TB8 = 0;                //??????0
#endif
    }
    busy = 1;
    SBUF = ACC;                 //????UART?????
}

/*----------------------------
?????
----------------------------*/
void SendString(char *s)
{
    while (*s)                  //?????????
    {
        SendData(*s++);         //??????
    }
}


