#include "reg52.h"
#include "absacc.h"
#define uchar unsigned char 
#define uint  unsigned int

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,};
uchar dspbuf[8]={1,2,3,4,5,6,7,8};
uchar dspcom=0;

void display();

void main()
{
		TMOD=0x01;
		TH0=(65536-2000)/256;
		TL0=(65536-2000)%256;
		EA=1;
		ET0=1;
		TR0=1;
		while(1);
}

void isr_timer0() interrupt 1
{
		TH0=(65536-2000)/256;
		TL0=(65536-2000)%256;
		display();
}

void display()
{
		XBYTE[0xe000]=0xff;
		XBYTE[0xc000]=1<<dspcom;
		XBYTE[0xe000]=tab[dspbuf[dspcom]];
		if(++dspcom==8)
			dspcom=0;
}