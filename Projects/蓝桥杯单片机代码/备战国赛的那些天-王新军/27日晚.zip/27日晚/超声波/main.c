#include "reg52.h"
#include "absacc.h"
#include "intrins.h"
#define uchar unsigned char
#define uint  unsigned int
#define somenop {_nop_();_nop_();_nop_();_nop_();_nop_();\
								_nop_();_nop_();_nop_();_nop_();_nop_();}
sbit TX=P1^0;
sbit RX=P1^1;

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};
uchar dspbuf[8]={1,2,3,4,5,6,7,8};
uchar dspcom=0;
uchar intr=0;
bit flag=0;
uint t=0;
uint distance=0;

void display();
void sendwave();

void main()
{
		TMOD=0x11;
		TH0=(65536-2000)/256;
		TL0=(65536-2000)%256;
		TH1=0;
		TL1=0;
		EA=1;
		ET0=1;
		TR0=1;
		while(1)
		{
				if(flag==1)
				{
						flag=0;
						sendwave();
						TR1=1;
						while((RX==1)&&(TF1==0));
						TR1=0;
						if(TF1==1)
						{
								TF1=0;
								distance=99;
						}
						else 
						{
								t=TH1*256+TL1;
								distance=t*0.017;
						}
						TH1=TL1=0;
				}
				
				dspbuf[6]=distance/10;
				dspbuf[7]=distance%10;
		}
}

void isr_timer0() interrupt 1
{
		TH0=(65536-2000)/256;
		TL0=(65536-2000)%256;
		display();
		if(++intr==30)
		{
				intr=0;
				flag=1;
		}
}

void display()
{
		XBYTE[0xe000]=0xff;
		XBYTE[0xc000]=1<<dspcom;
		XBYTE[0xe000]=tab[dspbuf[dspcom]];
		if(++dspcom==8)
				dspcom=0;
}

void sendwave()
{
		uchar i=8;
		do
		{
				TX=1;
				somenop;
				TX=0;
				somenop;
		}while(i--);
}