#ifndef __keyboard_H__
#define __keyboard_H__

#include "STC15F2K60S2.h"
#define uchar unsigned char 
#define uint  unsigned int 

uchar key_press=0;
bit key_re=0;

uchar read_keyboard()
{
		uchar key_temp;
		uchar col;
		uchar key_value;
		
		P3=0xf0;P4|=0x14;
		key_temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		if(key_temp!=0xf0)
		{
				key_press++;
		}
		else
		{
				key_press=0;
		}
		
		if(key_press==3)
		{
				key_press=0;
				key_re=1;
				
				switch(key_temp)
				{
						case 0x70:col=1;break;
						case 0xb0:col=2;break;
						case 0xd0:col=3;break;
						case 0xe0:col=4;break;
				}
				
				P3=0x0f;P4&=0xeb;
				key_temp=(P3&0x0f);
				switch(key_temp)
				{
						case 0x07:key_value=col+11;break;
						case 0x0b:key_value=col+7;break;
						case 0x0d:key_value=col+3;break;
						case 0x0e:key_value=col-1;break;
				}
		}
		
		P3=0x0f;P4&=0xeb;
		key_temp=(P3&0x0f);
		if((key_re==1)&&(key_temp==0x0f))
		{
				key_re=0;
				return key_value;
		}
		else 
				return 0xff;
}


#endif