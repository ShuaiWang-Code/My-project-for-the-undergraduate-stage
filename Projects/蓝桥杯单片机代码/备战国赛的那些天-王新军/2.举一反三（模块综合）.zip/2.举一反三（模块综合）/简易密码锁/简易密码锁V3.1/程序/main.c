#include "reg52.h"
#include "key.h"
#include "onewire.h"
#include "ds1302.h"

#define uchar unsigned char
#define uint unsigned int
						   
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbf};
uchar dspbuf[8]={11,11,11,11,11,11,11,11};
uchar dspcom=0;
code uchar mima[8]={1,2,3,4,5,6,7,8}; //��ʼ����
uchar intr=0,temp=0;
bit key_flag=0;
bit mima_flag=0;
uchar mima_error=0;
uchar hour,min,sec,temperature;
bit buzz=0;
uchar Frequency=0;
void display();
void DelayMs( uint Ms );




void main()
{
	uchar i=0;
	TMOD=0x11;
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	EA=1;
	ET1=1;
	ET0=1;
	TR0=1;
	P2=(P2&0x1f)|0xa0; //�رշ�����
	P0=0;
	P2=P2&0x1f;
	ds1302_init(0x08,0x08,0x08);
	while(1)
	{
		if(key_flag==1)
		{
			key_flag=0;
			temp=read_keyboard();
			key_proc(temp);					
		}
			if(ETRP==0) //����ܲ���ʾ
			{  	
				key_bit=0;
				for(i=0;i<8;i++)
					dspbuf[i]=10;
				mima_flag=0;
				ETRP=1;
				P2=(P2&0x1f)|0xa0;
				P0=0;
				P2=(P2&0x1f);
				P2=(P2&0x1f)|0x80;
				P0=0xff;
				P2=(P2&0x1f);
			}
			if(ETRP==1)	  //��������
			{		
				if(key_bit>8)
				{
					key_bit=8;
				}
				if(key_bit<0)
				{
					key_bit=0;
				}
			}
			if(ETRP==3) //�ж�
			{
				for(i=0;i<8;i++)
				{
					if(dspbuf[i]!=mima[i])				
						mima_flag=1;
					
				}
							
			}
			if((mima_flag==1)&&(ETRP==3))	  //�������
			{
				P2=(P2&0x1f)|0x80;
				P0=0xfe;
				P2=(P2&0x1f);
				P2=(P2&0x1f)|0xa0;
				P0=0;
				P2=(P2&0x1f);
				ETRP=4;
				mima_error++;
	
						
			}
			if(LOCK==0)
			{	
				if((mima_flag==0)&&(ETRP==3))	 //������ȷ
				{
					P2=(P2&0x1f)|0x80;
					P0=0xff;
					P2=(P2&0x1f);
					P2=(P2&0x1f)|0xa0;
					P0=0x10;
					P2=(P2&0x1f);
					ETRP=4;
					mima_error=0;  //������ȷ�������
					TR1=0;
					Frequency=0;
					P2=(P2&0x1f)|0xa0; //�رշ�����
					P0&=0xbf;
					P2=P2&0x1f;		
				}
			}
			if(LOCK==1)
			{
			 	P2=(P2&0x1f)|0xa0;//�رռ̵���
				P0=0;
				P2=(P2&0x1f);
				LOCK=0;	
			}
	
			if(ETRP==4)	 //��ʾʱ�䣬�¶�
			{
				hour=Ds1302_Single_Byte_Read(ds1302_hr_addr);
				min=Ds1302_Single_Byte_Read(ds1302_min_addr);
	//			sec=Ds1302_Single_Byte_Read(ds1302_sec_addr);
				dspbuf[0]=hour/16;
				dspbuf[1]=hour%16;
				dspbuf[2]=11;
				dspbuf[3]=min/16;
				dspbuf[4]=min%16;
				dspbuf[5]=10;
				temperature=read_ds18b20_data();
				dspbuf[6]=temperature/10;
				dspbuf[7]=temperature%10;
	
			}
			if(mima_error>=3) //����
			{
				TR1=1;
				DelayMs(1);
				Frequency++;	
			}
	
	}		
}

void isr_timer0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();
	if(++intr==15)
	{
		intr=0;
		key_flag=1;
	}	
			
}

void display()
{
	P2=(P2&0x1f)|0xe0;
	P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f);
	P2=(P2&0x1f)|0xc0;
	P0=1<<dspcom;
	P2=(P2&0x1f);
	if(++dspcom==8)
		dspcom=0;

}



void Timer1(void) interrupt 3
{
    TH0 = 0xFE;                                     /* ��ֵ,��ŵ�Ƶ�� */
    TL0 = Frequency;
    buzz = ~buzz;			/* �˿ڵ�ƽȡ�� */
	if(buzz==1)	//�򿪷�����
	{
		P2=(P2&0x1f)|0xa0;
		P0=0x40;
		P2=P2&0x1f;		
	}
	else 			  //�رշ�����
	{
		P2=(P2&0x1f)|0xa0;
		P0=0;;
		P2=P2&0x1f;		
	}                             
}

void DelayMs( uint Ms )
{
	uchar i;

	while (Ms--)
  	{
    	for ( i = 0; i < 114; i++ );	            /* ѭ��114�����1MSʱ�� */
  	}
}