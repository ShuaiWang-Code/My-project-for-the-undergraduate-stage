#ifndef __key_H__
#define __key_H__
#define uchar unsigned char
#define uint unsigned int

uchar key_press=0;
uchar key_re=0;
char key_bit = 0;
uchar key_val;
uchar ETRP=3;
uchar RSTP=4;
uchar read_keyboard();
void key_proc(uchar val);
extern uchar dspbuf[8];
bit LOCK=0;
uchar set=0;
bit set_flag=0;

uchar read_keyboard()
{
	uchar key_value,key_temp,col;
	P3=0xf0;P4|=0x14;
	key_temp=(P3&0x30)|((P4&0x10)<<3)|((P4&0x04)<<4);
	if(key_temp!=0xf0) 
		key_press++;	//�а�������
	else 
		key_press=0;	//����
	if(key_press==3)
	{
		key_press=0;
		key_re=1;
		switch(key_temp)
		{
			case 0x70:col=1;break;//��һ��
			case 0xb0:col=2;break;//�ڶ���
			case 0xd0:col=3;break;//��һ��
			case 0xe0:col=4;break;//�ڶ���
		}
		P3=0x0f;P4&=0xeb;
		key_temp=P3&0x0f;
//		if(key_temp!=0x0f)
//		{
			switch(key_temp)
			{
				case 0x0e:key_value=col-1;break;//��һ��
				case 0x0d:key_value=col+3;break;//�ڶ���
				case 0x0b:key_value=col+7;break;//������
				case 0x07:key_value=col+11;break;//������
			}	
//		}

	}

	P3=0x0f;P4&=0xeb;
	key_temp=P3&0x0f;
	if((key_re==1)&&(key_temp==0x0f))    //�������μ�⵽���������£����Ҹð����Ѿ��ͷ�
	{
		key_re=0;
		return key_value;
	}
	else 
		return 0xff;   
}

void key_proc(uchar val)
{
	switch(val)
	{
		case 0:	if((ETRP==1)||(RSTP==1)||(RSTP==4)){key_val=0;dspbuf[key_bit]=0;key_bit+=1;}break;
		case 1:	if((ETRP==1)||(RSTP==1)||(RSTP==4)){key_val=1;dspbuf[key_bit]=1;key_bit+=1;}break;
		case 2:	if((ETRP==1)||(RSTP==1)||(RSTP==4)){key_val=2;dspbuf[key_bit]=2;key_bit+=1;}break;
		case 3:	set=1;	  RSTP=0;break; //RSTP
		case 4:	if((ETRP==1)||(RSTP==1)||(RSTP==4)){key_val=3;dspbuf[key_bit]=3;key_bit+=1;}break;
		case 5:	if((ETRP==1)||(RSTP==1)||(RSTP==4)){key_val=4;dspbuf[key_bit]=4;key_bit+=1;}break;
		case 6: if((ETRP==1)||(RSTP==1)||(RSTP==4)){key_val=5;dspbuf[key_bit]=5;key_bit+=1;}break;
//		case 7:	          RSTP=0;break; //RSTT
		case 8:	if((ETRP==1)||(RSTP==1)||(RSTP==4)){key_val=6;dspbuf[key_bit]=6;key_bit+=1;}break;
		case 9:	if((ETRP==1)||(RSTP==1)||(RSTP==4)){key_val=7;dspbuf[key_bit]=7;key_bit+=1;}break;
		case 10:if((ETRP==1)||(RSTP==1)||(RSTP==4)){key_val=8;dspbuf[key_bit]=8;key_bit+=1;}break;	
		case 11:if((key_bit==8)&&(set==0)){ETRP=2;}
				if((key_bit==8)&&(set==1)&&(set_flag==0)){RSTP=2;}
				if((key_bit==8)&&(set==1)&&(set_flag==1)){RSTP=5;}                 break; //OK
		case 12:if((ETRP==1)||(RSTP==1)||(RSTP==4)){key_val=9;dspbuf[key_bit]=9;key_bit+=1;}break;
		case 13: set=0;ETRP=0;                                            break; //ETRP
		case 14:if((ETRP==1)||(RSTP==1)||(RSTP==4))	{key_bit-=1;dspbuf[key_bit]=10;}       break; //CLR
		case 15:          LOCK=1;								   break; //LOCK


	}
}





#endif