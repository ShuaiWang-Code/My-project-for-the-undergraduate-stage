/*
  ����˵��: IIC������������
  ��������: Keil uVision 4.10 
  Ӳ������: CT107��Ƭ���ۺ�ʵѵƽ̨(12MHz)
  ��    ��: 2011-8-9
*/

#include "iic.h"

//������������
void IIC_Start(void)//OK
{
	SDA = 1;
	SCL = 1;
	somenop;
	SDA = 0;
	somenop;
	SCL = 0;	
}

//����ֹͣ����
void IIC_Stop(void)
{
	SDA = 0;
	SCL = 1;
	somenop;
	SDA = 1;
	somenop;//
}

//Ӧ��λ����
void IIC_Ack(unsigned char ackbit)
{
	SCL=0;//
	if(ackbit) 
	{	
		SDA = 0;
	}
	else 
	{
		SDA = 1;
	}
	somenop;
	SCL = 1;
	somenop;
	SCL = 0;
	SDA = 1; 
	somenop;
}

//�ȴ�Ӧ��
bit IIC_WaitAck(void)
{
//	SDA = 1;
//	somenop;
//	SCL = 1;
//	somenop;
//	if(SDA)    
//	{   
//		SCL = 0;
//		IIC_Stop();
//		return 0;
//	}
//	else  
//	{ 
//		SCL = 0;
//		return 1;
//	}
	
		unsigned char ackbit;//
		SCL = 1;//
    somenop;//
    ackbit = SDA; //
    SCL = 0;//
    somenop;//
		return ackbit;//
}

//ͨ��I2C���߷�������
void IIC_SendByte(unsigned char byt)
{
	unsigned char i;
	EA=0;//
	for(i=0;i<8;i++)
	{   
		SCL=0;//
		somenop;//
		if(byt&0x80) 
		{	
			SDA = 1;
		}
		else 
		{
			SDA = 0;
		}
		somenop;
		SCL = 1;
		byt <<= 1;
		somenop;
//		SCL = 0;
	}
	EA=1;//
  SCL = 0;//
}

//��I2C�����Ͻ�������
unsigned char IIC_RecByte(void)
{
	unsigned char da;
	unsigned char i;
	EA=0;//
	for(i=0;i<8;i++)
	{   
		SCL = 1;
		somenop;
		da <<= 1;
		if(SDA) 
		da |= 0x01;
		SCL = 0;
		somenop;
	}
	EA=1;//
	return da;
}

void rb2_pcf8591()
{
		IIC_Start(); 
		IIC_SendByte(0x90); 
		IIC_WaitAck();
		IIC_SendByte(0x03); 
		IIC_WaitAck();
		IIC_Stop();  
		delay(10);
}

void guang_pcf8591()
{
		IIC_Start(); 
		IIC_SendByte(0x90); 
		IIC_WaitAck();
		IIC_SendByte(0x01); 
		IIC_WaitAck();
		IIC_Stop();  
		delay(10);
}

unsigned char adc_pcf8591()
{
		unsigned char val;
	
		IIC_Start(); 
		IIC_SendByte(0x91); 
		IIC_WaitAck();		
		val=IIC_RecByte(); 
		IIC_Ack(0);	
		IIC_Stop();
	
		return val;
}
void delay(unsigned char z)
{
	unsigned char i;
	
	while(z--)
	{
		for(i=0; i<112; i++);
	}
}
