#include <reg52.H>
#include "iic.h"
#define uchar unsigned char
#define uint  unsigned int

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar dspbuf[8]={10,10,10,10,10,10,10,10};
uchar dspcom=0;
uchar intr=0;
bit flag=0;
uchar guang,rb2;

void display();


void main()
{
		TMOD=0x01;
		TH0=(65536-2000)/256;
		TL0=(65536-2000)%256;
		EA=1;
		ET0=1;
		TR0=1;
		while(1)
		{
				if(flag==1)
				{
						flag=0;
						rb2_pcf8591();
						rb2=adc_pcf8591();
						rb2=adc_pcf8591();
						guang_pcf8591();
            guang=adc_pcf8591();
						guang=adc_pcf8591();
						
						
				}
						dspbuf[0]=rb2/100;
						dspbuf[1]=rb2/10%10;
						dspbuf[2]=rb2%10;
						dspbuf[5]=guang/100;
						dspbuf[6]=guang/10%10;
						dspbuf[7]=guang%10;
		}
}

void isr_timer0() interrupt 1
{
		TH0=(65536-2000)/256;
		TL0=(65536-2000)%256;
		display();
		if(++intr==20)
		{
				intr=0;
				flag=1;
		}
}

void display()
{
		P0=0xff;
		P2=(P2&0x1f)|0xe0;
		P2=(P2&0x1f);
		P0=1<<dspcom;
		P2=(P2&0x1f)|0xc0;
		P2=(P2&0x1f);
		P0=tab[dspbuf[dspcom]];
		P2=(P2&0x1f)|0xe0;
		P2=(P2&0x1f);
		if(++dspcom==8)
				dspcom=0;
}