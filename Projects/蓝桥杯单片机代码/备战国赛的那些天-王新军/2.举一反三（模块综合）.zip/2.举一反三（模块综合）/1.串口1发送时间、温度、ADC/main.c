#include "reg52.h"
#include "iic.h"
#include "onewire.h"
#include "ds1302.h"
#include "stdio.h"//sprintf

#define uchar unsigned char 
#define uint  unsigned int
sfr AUXR=0x8e;
#define FOSC 12000000L
#define BAUD 2400
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf,0xff};
uchar dspbuf[8]={11,11,11,11,11,11,11,11};
uchar dspcom=0;
uint intr=0;
bit flag=0;
int hour,min,sec;
char str[40];
int wendu=0;
int adc;
uchar adc_intr;
bit adc_flag=0;

void display();
void senddata(uchar dat);
void sendstring(char*s);
void main()
{
	uint a=89;
	TMOD=0x21;
	SCON=0x50;
	AUXR=0x40;
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	ET0=1;
	EA=1;
	TR0=1;
	TH1=256-FOSC/BAUD/32;
	TL1=256-FOSC/BAUD/32;
//	ES=1;
	TR1=1;
	ds1302_init(0x23,0x58,0x50);
	P0=0;
	P2=(P2&0x1f)|0xa0;
	P2=(P2&0x1f);
	while(1)
	{
		hour=Ds1302_Single_Byte_Read(ds1302_hr_addr);
		min=Ds1302_Single_Byte_Read(ds1302_min_addr);
		sec=Ds1302_Single_Byte_Read(ds1302_sec_addr);
//		dspbuf[0]=hour/16;
//		dspbuf[1]=hour%16;
//		dspbuf[3]=min/16;
//		dspbuf[4]=min%16;
		dspbuf[6]=sec/16;
		dspbuf[7]=sec%16;
//		dspbuf[2]=dspbuf[5]=10;
		wendu=get_ds18b20();
		if(adc_flag==1)
		{
			adc_flag=0;
			adc=adc_pcf8591(0x03);
			dspbuf[0]=adc/100;
			dspbuf[1]=adc/10%10;
			dspbuf[2]=adc%10;
		}
		if(flag==1)
		{
			flag=0;
 			sprintf(str,"%s%d%d-","time:",hour/16,hour%16);
			sendstring(str);
			sprintf(str,"%d%d-%d%d",min/16,min%16,sec/16,sec%16);
			sendstring(str);
			sprintf(str,"%s%d","   temperature:",wendu);
			sendstring(str);
			sprintf(str,"%s%d","   adc:",adc);
			sendstring(str);
			sendstring("\r\n");
			
		}	
	}
}

void isr_timer0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();
	if(++intr==500)
	{
		intr=0;
		flag=1;
	}
	if(++adc_intr==30)
	{
		adc_intr=0;
		adc_flag=1;
	}
}

void display()
{
	P0=0xff;
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xc0;
	P2=(P2&0x1f);
	P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	if(++dspcom==8)
		dspcom=0;
}

void sendstring(char*s)
{
	while(*s)
	{
		senddata(*s++);
	}
}

void senddata(uchar dat)
{
	SBUF=dat;
	while(!TI);
	TI=0;
}


