#include "stc15f2k60s2.h"
#include "i2c.h"
#define uchar unsigned char
void Timer0Init(void);
void shuma_display();
uchar dspcom=0;
uchar dspbuf[]={0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0,0xc0};
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,
                            0xff,0xbf,0xc6}; //0~9 10�� ����ʾ��-
uchar temp1,temp3;
uchar intr=0;
bit flag=0;
void main()
{
  P2&=0X1F;  
  P2|=0XA0;
  P0=0X00;
  P2&=0X1F;   //�ط�����
  
  Timer0Init();
  while(1)
  {
		if(flag==1)
		{
				flag=0;
				Rb2_init_pcf8591();
				temp3=adc_pcf8591();
				temp3=adc_pcf8591();
				guang_init_pcf8591();
				temp1=adc_pcf8591();
				temp1=adc_pcf8591();
		 }
    dspbuf[0]=tab[temp3/100];
    dspbuf[1]=tab[temp3%100/10];
    dspbuf[2]=tab[temp3%100%10];
    dspbuf[3]=tab[0xff];
    dspbuf[4]=tab[temp1/100];
    dspbuf[5]=tab[temp1%100/10];
    dspbuf[6]=tab[temp1%100%10];
    dspbuf[7]=tab[0xff];
  }
}

void Timer0Init(void)		//15ϵ��16λ�Զ���ֵ����2MS
{
	AUXR |= 0x80;		//?????1T??
	TMOD &= 0xF0;		//???????
	TL0 = 0x9A;		//??????
	TH0 = 0xA9;		//??????
	TF0 = 0;		//??TF0??
	TR0 = 1;		//???0????
  EA=1;
  ET0=1;
}


void shuma_display()
{
  P2&=0X1F;  
  P2|=0Xe0;
  P0=0X00;
  P2&=0X1F;
  
  P2&=0X1F;  
  P2|=0Xc0;
  P0=1<<dspcom;
  P2&=0X1F;
  
  P2&=0X1F;  
  P2|=0Xe0;
  P0=dspbuf[dspcom];
  P2&=0X1F;
  if(++dspcom==8)
    dspcom=0;
}

void timer() interrupt 1
{
  shuma_display();
	if(++intr==20)
	{
			intr=0;
			flag=1;
	}
}