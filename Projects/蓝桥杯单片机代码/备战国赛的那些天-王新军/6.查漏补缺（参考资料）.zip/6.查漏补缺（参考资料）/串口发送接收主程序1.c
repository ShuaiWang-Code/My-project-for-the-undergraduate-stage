#include "reg52.h"
#include "intrins.h"
#define uchar unsigned char 
#define uint  unsigned int 
#define FOSC 11059200L
#define BAUD 115200
sfr AUXR=0x8e;  
bit busy;

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar dspbuf[8]={0,10,10,10,10,10,10,10};
uchar dspcom=0;

void SendData(uchar dat);
void SendString(char *s);
void display();

void main()
{
     SCON=0x50;
     AUXR=0x40; 
     TMOD=0x21;
     TL1=(256-(FOSC/32/BAUD));
     TH1=(256-(FOSC/32/BAUD));
     TR1=1;
     ES=1;
     EA=1;
		 TH0=(65536-2000)/256;
		 TL0=(65536-2000)%256;
		 ET0=1;
		 TR0=1;
		 P2=(P2&0x1f)|0xa0;
		 P0=0;
		 P2=(P2&0x1f);	 
     SendString("Hello");
     while(1);
}
void Uart() interrupt 4 using 1
{
     if(RI)
     {
            RI=0;
            dspbuf[0]=SBUF;
     }
     if(TI)
     {
            TI=0;
            busy=0;
     }
}
void SendData(uchar dat)
{
     while(busy);
     busy=1;
     SBUF=dat;
}
void SendString(char*s)
{
     while(*s)
     {
            SendData(*s++);
     }
}
void isr_timer0() interrupt 1 
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();
}

void display()
{
	P0=0xff;              
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	
  P0=1<<dspcom;
	P2=(P2&0x1f)|0xc0; 
	P2=(P2&0x1f);
	
	P0=tab[dspbuf[dspcom]];            
	P2=(P2&0x1f)|0xe0;
	P2=(P2&0x1f);
	               
	if(++dspcom==8)
		dspcom=0;
}