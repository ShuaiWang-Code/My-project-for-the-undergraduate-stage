#include "reg52.h"
#include "onewire.h"
#include "key.h"

#define uint unsigned int
#define uchar unsigned char

code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbf};
		//		   0	 1	 2	   3	4	5	 6	  7		8	 9	�ر�  -
uchar dspbuf[8]={11,0,11,10,10,10,1,1};//����
uchar wen[5]={10,10,10,10,10};
uchar dspcom=0;
uchar key_flag=0,flag;
uchar t_now,t_max=25,t_min=10;
uchar value;
uint count=0;
bit L1_flag=0;
uint led_time;
bit led_flag=0;


void main(void)
{
	uchar i;
	TMOD |=0x10;
	TH1=(65536-2000)/256;
	TL1=(65536-2000)%256;
	EA=1;
	ET0=1;
	TR0=1;
	P2=(P2&0x1f)|0xa0;//�رշ������ͼ̵���
	P0=0;
	P2=P2&0x1f;
	P2=(P2&0x1f)|0x80;	  	//�ر�led
	P0=0xff;
	P2=P2&0x1f;
	
	while(1)
	{	 
			if(flag)
			{
			  flag=0;
			 P2=(P2&0x1f)|0x80;	 //��LED2
			P0 = 0xfd;	 //
			P2=(P2&0x1f);
			}
			key_flag=0;
			value=read_keyboard();
			key_proc(value);
		
		 
		if(set==0)
		{
			t_now=read_ds18b20_data();
			 dspbuf[0]=dspbuf[2]=11;
	dspbuf[3]=dspbuf[4]=dspbuf[5]=10;
			dspbuf[6]=t_now/10;
			dspbuf[7]=t_now%10;
			if(t_now<t_min)
			{
				dspbuf[1]=0;
				led_time=400;
			}
			else 
			{
				if(t_now>t_max)
				{	
					dspbuf[1]=2;
					led_time=100;
				}
				else 
				{
					dspbuf[1]=1;
					led_time=200;
				}
			}
		}


		if(set==1)
		{
			dspbuf[0]=dspbuf[5]=11;
			dspbuf[1]=dspbuf[2]=dspbuf[3]=10;
			dspbuf[4]=dspbuf[6]=dspbuf[7]=10;
						
			for(i=0;i<4;i++)
			{
				wen[i]=10;
			}
			 set=2;
			 key_bit=0;
		}
		if(set==2) //�����¶�������
		{	
			if(key_bit<0)
				key_bit=0;
			if(key_bit>4)
				key_bit=4;
			dspbuf[1]=wen[0];
			dspbuf[2]=wen[1];
			dspbuf[6]=wen[2];
			dspbuf[7]=wen[3];
			

		}
		
		if(t_max<t_min)	
		{
			flag=1;
		}

	if((led_time==400)||(led_time==200))
	{
		P2=(P2&0x1f)|0xa0;//�رռ̵���
		P0=0x00;
		P2=P2&0x1f;
	}
	if(led_time==100)
	{
		P2=(P2&0x1f)|0xa0;//�򿪼̵���
		P0=0x10;
		P2=P2&0x1f;			
	} 	
	
		
	}

}




void isr_t0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;

	P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f)|0xe0;
	P2=P2&0x1f;
	P0=1<<dspcom;
    P2=(P2&0x1f)|0xc0;
	P2=P2&0x1f;

	if(++dspcom==8)
		dspcom=0;

	if(++count==led_time)
	{
		count=0;
//		led_flag=1;
//	}
//
//
//	if(led_flag==1)
//	{
//		led_flag=0;
		L1_flag=~L1_flag;

		if(L1_flag==1)		//	L1��˸
		{
			P2=(P2&0x1f)|0x80;	  	//��L1
			P0=0xfe;
			P2=(P2&0x1f);	
		}
		if(L1_flag==0)
		{
			P2=(P2&0x1f)|0x80;	 //�ر�L1
			P0 = 0xff;	 //
			P2=(P2&0x1f);
		}	 
	}	




}


