#include <stc15f2k60s2.h>
#include "absacc.h"


#ifndef _led_h
#define _led_h


#define uchar unsigned char 
#define uint  unsigned int


extern uchar flag_t;



void led_init(void)
{
	
	
}








#endif