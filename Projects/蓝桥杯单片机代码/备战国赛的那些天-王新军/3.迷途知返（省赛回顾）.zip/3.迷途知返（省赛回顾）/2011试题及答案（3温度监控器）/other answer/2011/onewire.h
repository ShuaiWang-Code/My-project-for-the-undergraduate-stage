#ifndef _ONEWIRE_H
#define _ONEWIRE_H

#include <stc15f2k60s2.h>
#include "absacc.h"


#define OW_SKIP_ROM 0xcc
#define DS18B20_CONVERT 0x44
#define DS18B20_READ 0xbe

//IC���Ŷ���
sbit DQ = P1^4;

uchar ds18b20_data_8;
uint ds18b20_data_16;




//��������ʱ����
void Delay_OneWire(unsigned int t)
{
  unsigned char i,j;
	for(j=0; j<t; j++)
	{
	_nop_();
	_nop_();
	i = 66;
	while (--i);
	}
	
}

//DS18B20оƬ��ʼ��
bit Init_DS18B20(void)
{
	bit initflag = 0;
	DQ = 1;
	Delay_OneWire(12);
	DQ = 0;
	Delay_OneWire(80); 
	DQ = 1;
	Delay_OneWire(10); 
	initflag = DQ;    
	Delay_OneWire(5);
  
	return initflag;
}

//ͨ����������DS18B20дһ���ֽ�
void Write_DS18B20(unsigned char dat)
{
	unsigned char i;
	//EA = 0;
	for(i=0;i<8;i++)
	{
		DQ = 0;
		DQ = dat&0x01;
		Delay_OneWire(5);
		DQ = 1;
		dat >>= 1;
	}
	//EA = 1;
	Delay_OneWire(5);
}

//��DS18B20��ȡһ���ֽ�
unsigned char Read_DS18B20(void)
{
	unsigned char i;
	unsigned char dat;
  //EA = 0;
	for(i=0;i<8;i++)
	{
		DQ = 0;
		dat >>= 1;
		DQ = 1;
		if(DQ)
		{
			dat |= 0x80;
		}	    
		Delay_OneWire(5);
	}
	//EA = 1;
	return dat;
}


void read_ds18b20_data(void)
{
	uchar high,low;
	//uchar temp;
	
	Init_DS18B20();
	Write_DS18B20(OW_SKIP_ROM);
	Write_DS18B20(DS18B20_CONVERT);
	
	Init_DS18B20();
	Write_DS18B20(OW_SKIP_ROM);
	Write_DS18B20(DS18B20_READ);
	
	
	//TR0 = 0;
	low = Read_DS18B20();
	high= Read_DS18B20();
	//TR0 = 1;
	
	ds18b20_data_8 = ((low>>4) | (high<<4));

}


#endif