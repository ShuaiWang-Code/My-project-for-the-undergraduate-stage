#include <stc15f2k60s2.h>
#include "absacc.h"

#ifndef _key_h
#define _key_h


#define uchar unsigned char 
#define uint  unsigned int
	

extern uchar t_max,t_min,t;


extern uchar iic_read_byte(uchar iic_addr);
extern void iic_write_byte(uchar iic_addr,uchar iic_data);


void key_init(void)
{
	P3 |= 0x0f;
}


void key(void)
{
	uchar key_bit = 0;

	P3 |= 0x0f;
	
	if(P30 == 0)
	{
		delay_ms(10);
		while((P30 == 0));
		t_min--;
		key_bit = 1;	//t_min--
	}
	
	if(P31 == 0)	
	{
		delay_ms(10);
		while((P31 == 0));
		t_min++;
		key_bit = 1;	//t_min++
	}
	
	if(P32 == 0)	
	{
		delay_ms(10);
		while((P32 == 0));
		t_max--;
		key_bit = 2;	//t_max--
	}
	
	if(P33 == 0)
	{
		delay_ms(10);
		while((P33 == 0));
		t_max++;
		key_bit = 2;	//t_max++
	}
	/********���ּ�**********/
	if((t_max >= 100)|(t_max <= 0))
	{
		t_max = 0;
	}
	if((t_min >= 100)|(t_min <= 0))
	{
		t_min = 0;
	}
	/*********д��eeprom*********/
	if(key_bit > 0)
	{
		if(key_bit == 2)
		{
		
		iic_write_byte(0x00,t_max);
		delay_ms(10);
		}
		if(key_bit == 1)
		{
		iic_write_byte(0x01,t_min);
		delay_ms(10);
		}
	}
}


void jdq_case(void)
{
	uchar temp = 0x00;
	
	if(t < t_min)
	{
		temp |= (0x01<<4);
	}
	else
	{
		temp &=~(0x01<<4);
	}
	
	XBYTE[0XA000] = temp;
}

void pwm_case(void)
{
	if(t > t_max)
	{
		ET0 = 1;
	}
	if(t <= t_max)
	{
		ET0 = 0;
		P34 = 1;
	}
	
}






#endif