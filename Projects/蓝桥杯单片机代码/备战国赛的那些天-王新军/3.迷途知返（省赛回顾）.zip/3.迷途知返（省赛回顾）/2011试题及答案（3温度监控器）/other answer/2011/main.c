/********************************
//----------JM---------------
//���ݣ�2011�����

//�� B ��Ʒ

//����bug��,�ɼ�qq��874206295����
//���ߣ��˴��尮��С��
//��ֲ��ͯЬ�����������ߣ���������

**********************************/




/*********************************

//ע�⣺����Ĭ��11.0592mhz
//����оƬ��stc15f2k60s2
//------��ʹ��MMģʽ-----
//--------��IOģʽ-------

//----------JM----------------
*********************************/




#include <stc15f2k60s2.h>
#include "absacc.h"

#include "smg.h"
#include "delay.h"
#include "onewire.h"

#include "key.h"
#include "iic.h"

#define uchar  unsigned char 
#define uint   unsigned int
	



uchar t_max = 35,t_min = 30,t = 0;//�¶�ֵ


/****key****/
bit flag_key = 0;									//�ж϶�ȡ������־λ

bit flag_eeprom = 0;

/****18b20***/
bit flag_ds18b20 = 0;



void main_init(void)
{
	XBYTE[0X8000] = 0XFF;	//close LED
	
	XBYTE[0XE000] = 0XFF;	//close SMG
	
	XBYTE[0XA000] = 0X00;	//close BEEP
}



void timer0_init(void)	// 100us
{
	TMOD |= 0X01;
	
	TL0 = 0xA4;		//
	TH0 = 0xFF;		//
	
	TR0 = 1;
	ET0 = 1;
	EA  = 1;
	
}
void timer1_init(void)	//2ms
{
	TMOD |= 0X10;
	
	TH1 = 0xF8;
	TL1 = 0xCD;
	
	TR1 = 1;
	ET1 = 1;
	//EA  = 1;
	
}

void timer0_isr(void)	interrupt 1
{
	static uchar temp = 0;
	
	TR0 = 0;
	
	TL0 = 0xA4;		//
	TH0 = 0xFF;		//
	
	if(temp <= 3)
		P34 = 1;
	if(temp > 3)
		P34 = 0;
	
	if(temp > 10)
		temp = 0;
	temp++;
	
	TR0 = 1;
}

void timer1_isr(void)	interrupt 3
{
	static uchar flag_ds18b20_temp = 0;
	static uchar flag_key_temp = 0;
	static uchar flag_eeprom_temp = 0;

	TR1 = 0;
	
	TH1 = 0xF8;
	TL1 = 0xCD;
	
	if(++flag_ds18b20_temp == 100)
	{
		flag_ds18b20 = 1;
		
		flag_ds18b20_temp = 0;
	}
	
	if(++flag_key_temp == 10)
	{
		flag_key = 1;
		
		flag_key_temp = 0;
	}
	/**/
	if(++flag_eeprom_temp == 200)
	{
		flag_eeprom = 1;
		
		flag_eeprom_temp = 0;
	}
	
	
	
	smg_display(t_max,t_min,t);
	
	
	TR1 = 1;
}


void main(void)
{
	
	main_init();
	
	key_init();
	
	smg_init();
	
	Init_DS18B20();
	
	iic_init();
	
	timer1_init();
	timer0_init();
	
	
	while(1)
	{
		/*************/
		if(flag_ds18b20)				//200ms��ȡ�¶�
		{
			read_ds18b20_data();
			t = ds18b20_data_8;
			
			flag_ds18b20 = 0;
		}

		/*************/
		if(flag_key)			//40ms��ȡ����
		{
			key();
			flag_key = 0;
		}

		/*************/
		if(flag_eeprom)
		{
			t_max = iic_read_byte(0x00);
			delay_ms(10);//
			t_min = iic_read_byte(0x01);
			delay_ms(10);
			
			flag_eeprom = 0;
		}
		/*************/
		
		pwm_case();
		
		jdq_case();
		
		/*************/
	}
	
}
	













