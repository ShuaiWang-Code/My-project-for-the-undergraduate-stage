#ifndef _IIC_H
#define _IIC_H

#include <stc15f2k60s2.h>
#include "absacc.h"
#include "INTRINS.h"
#include "delay.h"

#define SlaveAddrW 0xA0
#define SlaveAddrR 0xA1

//??????
sbit SDA = P2^1;  /* ??? */
sbit SCL = P2^0;  /* ??? */



void IIC_Start(void); 
void IIC_Stop(void);  

void IIC_Ack(unsigned char ackbit); 
void IIC_SendByte(unsigned char byt); 
bit IIC_WaitAck(void);  
unsigned char IIC_RecByte(void); 
void iic_write_byte(uchar iic_addr,uchar iic_data);
uchar iic_read_byte(uchar iic_addr);






//*****��ʼ��
void iic_init(void)
{
	t_max = iic_read_byte(0x00);
	delay_ms(10);//
	t_min = iic_read_byte(0x01);
	delay_ms(10);
	
}


void iic_delay(uchar n)
{
	do
	{
	_nop_();
	_nop_();
	_nop_();
	_nop_();

	_nop_();
	_nop_();
	}
	while(n--);
}



//??????
void IIC_Start(void)
{
	SDA = 1;
	SCL = 1;
	iic_delay(5);
	SDA = 0;
	iic_delay(5);
	SCL = 0;	
}

//??????
void IIC_Stop(void)
{
	SDA = 0;
	SCL = 1;
	iic_delay(5);
	SDA = 1;
	iic_delay(5);
}

//?????
void IIC_Ack(uchar ackbit)
{
	SCL = 0;
	SDA = ackbit;
	iic_delay(5);
	SCL = 1;
	iic_delay(5);
	SCL = 0;
	SDA = 1; 
	iic_delay(5);
}

//????
bit IIC_WaitAck(void)
{
	bit ack;
	//SCL = 0;///////////
	SDA = 1;
	iic_delay(5);
	SCL = 1;
	iic_delay(5);
	ack = SDA;
	SCL = 0;
	return ack;

}

//??I2C??????
void IIC_SendByte(unsigned char byt)
{
	unsigned char i;
	EA = 0;
	for(i=0;i<8;i++)
	{   
		if(byt&0x80) 
		{	
			SDA = 1;
		}
		else 
		{
			SDA = 0;
		}
		iic_delay(5);
		SCL = 1;
		byt <<= 1;
		iic_delay(5);
		SCL = 0;
	}
	EA = 1;
}

//?I2C???????
unsigned char IIC_RecByte(void)
{
	unsigned char da;
	unsigned char i;
	EA = 0;
	
	for(i=0;i<8;i++)
	{   
		SCL = 1;
		iic_delay(5);
		da <<= 1;
		if(SDA) 
		da |= 0x01;
		SCL = 0;
		iic_delay(5);
	}
	EA = 1;
	return da;
}


//*******************************************************************
void iic_write_byte(uchar iic_addr,uchar iic_data)
{
	IIC_Start();
	
	IIC_SendByte(0xa0);
	
	IIC_WaitAck();
	
	IIC_SendByte(iic_addr);
	
	IIC_WaitAck();

	IIC_SendByte(iic_data);
	
	IIC_WaitAck();////////////
	
	IIC_Stop();
}

uchar iic_read_byte(uchar iic_addr)
{
	uchar temp;

	IIC_Start();
	
	IIC_SendByte(0xa0);
	
	IIC_WaitAck();
	
	IIC_SendByte(iic_addr);

	IIC_WaitAck();////////////
	
	IIC_Start();

	IIC_SendByte(0xa1);

	IIC_WaitAck();

	temp = IIC_RecByte();
	
	IIC_Ack(0);//////////////IIC_WaitAck();

	IIC_Stop();
	
	return temp;
}

#endif