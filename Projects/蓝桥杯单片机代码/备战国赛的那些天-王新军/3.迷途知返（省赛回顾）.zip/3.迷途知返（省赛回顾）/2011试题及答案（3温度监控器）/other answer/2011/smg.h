#include <stc15f2k60s2.h>
#include "absacc.h"

#ifndef _smg_h
#define _smg_h


#define uchar unsigned char 
#define uint  unsigned int

//code uchar smg_data[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,  0x00,0x40,0x80};
code uchar smg_data[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90  ,0xff,0xbf,0x7f};
code uchar smg_clos = 10;	//�ر�
code uchar smg_f = 11;		//����
code uchar smg_d = 12;		//С����


/*************

//smg��ʼ��

*************/
void smg_init(void)
{
	XBYTE[0XC000] = 0XFF;
	
	XBYTE[0XE000] = 0XFF;
}


/*************

//��λ�������ʾ

*************/
void smg_n(uchar n,uchar sum)
{
	XBYTE[0XE000] = 0XFF;
	
	XBYTE[0XC000] =(0X1<<(n-1));
	
	XBYTE[0XE000] =smg_data[sum];
}
/***********

//test
//���Գ���

*************/
void smg_display(uchar sum1,uint sum2,uchar sum3)
{
	static uchar i = 0;
	
	uchar temp[8];
	
	temp[0] = sum1/10;
	temp[1] = sum1%10;
	temp[2] = sum2/10;
	temp[3] = sum2%10;
	
	temp[4] = smg_clos;
	temp[5] = smg_clos;
	temp[6] = sum3/10;
	temp[7] = sum3%10;
	
	smg_n(i,temp[i-1]);
	
	if(i >= 8)
		i = 0;
	i++;

}




#endif