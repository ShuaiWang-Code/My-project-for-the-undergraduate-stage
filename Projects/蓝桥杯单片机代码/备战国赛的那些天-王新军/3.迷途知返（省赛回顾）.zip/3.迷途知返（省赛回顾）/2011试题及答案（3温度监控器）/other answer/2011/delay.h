//#include <stc15f2k60s2.h>
//#include "absacc.h"

#include <intrins.h>

#ifndef _DELAY_H
#define _DELAY_H


#define uchar unsigned char 
#define uint  unsigned int




/*
void delay_us(uint n)
{
	uint i;
	
	for(i=0; i<n; i++)
	{
		_nop_();
		_nop_();
		_nop_();
		_nop_();
	}
	
}
*/
void delay_1ms(void)
{
	unsigned char i, j;

	_nop_();
	_nop_();
	_nop_();
	i = 11;
	j = 190;
	do
	{
		while (--j);
	} while (--i);
}

void delay_ms(uint n)
{
	uint i;
	
	for(i=0; i<n; i++)
	{
		delay_1ms();
	}
	
}












#endif