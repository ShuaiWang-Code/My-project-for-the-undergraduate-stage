#include "reg52.h"
#include "iic.h"
#include "onewire.h"
#include "intrins.h"

#define uchar  unsigned char 
#define uint   unsigned int 
//��ν���ж� ��ʱȥ�ɱ����
                           //  0    1    2    3    4    5    6    7    8    9	A	  B	   C	D	 E	  F	 ����ʾ
code uchar tab[] = { 0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0x88,0x83,0xc6,0xa1,0x86,0x8e,0xff};
uchar dspbuf[8] = {0,0,0,0,16,16,0,0};  //��ʾ������
uchar dspcom = 0;
char wenshang=25; //�¶�����
char wenxia=18;	  //�¶�����
char now=0;	  //��ǰ�¶�
uchar count=1;
sbit s4=P3^3; //������
sbit s5=P3^2; //������
sbit s6=P3^1; //������
sbit s7=P3^0; //������
sbit p34=P3^4;//


void display(void);
void jianpan(void);
void relay(void);
void chuli(void);
void initial_timer(void);
void pwm(void);
void delay_ms(uint n);

//������
void main(void)
{ 	
	initial_timer();
 	wenshang = read_eeprom(0x00);
	//delay_ms(10);
	wenxia = read_eeprom(0x01);
	//delay_ms(10);
 
    while(1)
    {
	        jianpan();
		chuli();
		relay(); //�̵���
		pwm();
		
			     
    }
}

void initial_timer(void)
{
    TMOD = 0x11;  //���ö�ʱ������ģʽ
    TH1 = (65536-2000)/256;
    TL1 = (65536-2000)%256; 
    TH0 = (65536-100)/256;
    TL0 = (65536-100)%256;  
    EA=1;
    ET1 = 1;  //�򿪶�ʱ���ж�
    ET0 = 1;  //�򿪶�ʱ���ж�
    TR1 = 1;  //������ʱ��
}

//��ʱ���жϷ�����
void isr_timer_1(void)  interrupt 3  //Ĭ���ж����ȼ� 3
{	
    TH1 = (65536-2000)/256;
    TL1 = (65536-2000)%256;  //��ʱ������ 		 
	display();  //2msִ��һ��	
}

void isr_timer_0(void)  interrupt 1  //Ĭ���ж����ȼ� 1
{
    TH0 = (65536-100)/256;
    TL0 = (65536-100)%256;
	TR0=0;
	if(count<4)
		p34=1;
	else 
		p34=0;
	count++;
	if(count>10)
		count=0;
	TR0=1;
}

//��ʾ����
void display(void)
{   
	P2=(P2&0x1F)|0xE0;
	P0=0xff;		  //����
	P2=P2&0x1F; 
	
	P2=(P2&0x1F)|0xC0;
	P0=1<<dspcom;		  //λ��
	P2=P2&0x1F; 
   
	P2=(P2&0x1F)|0xE0;
	P0=tab[dspbuf[dspcom]];		  //����
	P2=P2&0x1F;
   
    if(++dspcom == 8)
	{
        dspcom = 0;
    }   
}



void jianpan(void)
{
		if(s4==0)
		{
			delay_ms(10);
			if(s4==0)
			{			
				wenshang++;				
				while(!s4);
				if(wenshang>99)
					wenshang=0;
				if(wenshang<0)
					wenshang=99;
				write_eeprom(0x00,wenshang);
				delay_ms(10);
			}
		}

		if(s5==0)
		{
			delay_ms(10);
			if(s5==0)
			{			
				wenxia++;
				while(!s5);
				if(wenxia>99)
					wenxia=0;
				if(wenxia<0)
					wenxia=99;
				write_eeprom(0x01,wenxia);
				delay_ms(10);			

			}
		}

		if(s6==0)
		{
			delay_ms(10);
			if(s6==0)
			{			
				wenshang--;
				while(!s6);
				if(wenshang>99)
					wenshang=0;
				if(wenshang<0)
					wenshang=99;
				write_eeprom(0x00,wenshang);
				delay_ms(10);
			}
		}

		if(s7==0)
		{
			delay_ms(10);
			if(s7==0)
			{			
				wenxia--;
				while(!s7);
				if(wenxia>99)
					wenxia=0;
				if(wenxia<0)
					wenxia=99;
				write_eeprom(0x01,wenxia);
				delay_ms(10);
			}
		}
}


void relay(void)
{
	if(wenxia>now)
	{
		P2=(P2&0x1F)|0xA0;
		P0=0x10;//�򿪼̵���		  
		P2=P2&0x1F; 		
	}
	else
	{
		P2=(P2&0x1F)|0xA0;
		P0=0x00;//�رռ̵���		  
		P2=P2&0x1F; 		
	}
}

void chuli(void)
{
	    now=read_ds18b20_data();	//������ʾ����
	    dspbuf[0] = wenshang/10;       
	    dspbuf[1] = wenshang%10;       
	    dspbuf[2] = wenxia/10;
	    dspbuf[3] = wenxia%10;
	    dspbuf[6] = now/10;
	    dspbuf[7] = now%10;
}

void pwm(void)
{
	if(now>wenshang)
		TR0=1;
	else
		{
			TR0=0;
			p34=1;
		}
}


void delay_ms(uint n)
{
	uint x,y;
	for(x=0;x<n;x++)
		for(y=0;y<120;y++);

}  