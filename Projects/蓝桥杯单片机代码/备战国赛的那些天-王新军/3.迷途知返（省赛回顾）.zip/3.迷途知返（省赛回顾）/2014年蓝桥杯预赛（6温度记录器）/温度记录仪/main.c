#include "reg52.h"
#include "onewire.h"
#include "ds1302.h"
#define uchar unsigned char
#define uint unsigned int
sbit s4=P3^3;
sbit s5=P3^2;
sbit s6=P3^1;
sbit s7=P3^0;

//�������
//				   0    1     2   3     4	 5   6    7     8   9	����ʾ  -
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbf};
uchar dspbuf[8]={10,10,10,10,10,11,0,0};
uchar dspcom=0;
bit ds18b20_flag=0;
bit led_flag=0;	//����led��˸
uchar wendu[10]={12,23,34,45,56,67,78,89,90,01};
uchar jiange=0;
uchar hour,min,sec;
uint ds18b20_count=0;//�����¶ȼ�ʱ
uchar led_count=0;//����led��ʱ
uint tishi_count=0;//������ʾ����ʱ
bit tishi_flag=0;//������ʾ����˸
uchar wen_count=0;//�����¶�
uchar xianshi=0;//��ʾ������л�    0��ʾʱ����    1��ʾʱ��,�����¶Ȳɼ�   2��ʾ�¶�
uchar jiange_select=0;
uchar wen_k=0;//�����¶���ʾ
bit s6_an=0;
bit L1_flag=0;
uchar led_count0=0;
//��������
void display();
void delay_ms(uint z);
void system_init();

void main(void)
{
	uchar i;
	TMOD|=0x01;
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	EA=1;
	ET0=1;
	TR0=1;
	Init_DS18B20();
	system_init();
	ds1302_init();
	while(1)
	{
		if(s4==0)
		{
			delay_ms(50);
			if(s4==0)
			{
				while(!s4);
				jiange_select++;
				if(jiange_select>3)
					jiange_select=0;					
			}
		}

		if(s5==0)
		{
			delay_ms(50);
			if(s5==0)
			{				
				while(!s5);
				xianshi=1;
				
			}
		}
		

		if(s6==0)
		{
			delay_ms(50);
			if(s6==0)
			{				
				while(!s6);
				P2=(P2&0x1f)|0x80;//�ر�L1
				P0=0xff;
				P2=(P2&0x1f);
				s6_an=1;
				if(++wen_k==10)
					wen_k=0;
					
//				
			}
	    }
		
		
		if(s7==0)
		{
			delay_ms(50);
			if(s7==0)
			{				
				while(!s7);
				xianshi=0;
				jiange_select=0;
				wen_count=0;
				s6_an=0;	
			}
		}

		 if(xianshi==0)    //��ʾʱ����
		 {		 	
			switch(jiange_select)
			{
				case 0:
					for(i=0;i<5;i++)
						dspbuf[i]=10;
					dspbuf[5]=11;
					dspbuf[6]=0;
					dspbuf[7]=1;
					jiange=1;
					break;
				case 1:dspbuf[7]=5;jiange=5;break;
				case 2:dspbuf[6]=3;dspbuf[7]=0;jiange=30;break;
				case 3:dspbuf[6]=6;jiange=60;break;
				default :break;
			}		
		 }

		 if(xianshi==1)		  //��ʾʱ�䣬�������¶Ȳɼ�
		 {
			hour=Ds1302_Single_Byte_Read(ds1302_hr_addr);
			min=Ds1302_Single_Byte_Read(ds1302_min_addr);
			sec=Ds1302_Single_Byte_Read(ds1302_sec_addr);
			dspbuf[0]=hour/16;
			dspbuf[1]=hour%16;
			dspbuf[3]=min/16;
			dspbuf[4]=min%16;
			dspbuf[6]=sec/16;
			dspbuf[7]=sec%16;
//			min=read_ds18b20_data(); //�����¶�	������ʱ��
//			dspbuf[6]=min/10;
//			dspbuf[7]=min%10;
			if(tishi_flag==1)
		 		dspbuf[2]=dspbuf[5]=11;
		    else
		 		dspbuf[2]=dspbuf[5]=10; 

			//�ɼ��¶�
			if(wen_count<10)
			{
				if(ds18b20_flag==1)
				{
					ds18b20_flag=0;
					wendu[wen_count]=read_ds18b20_data();//�ɼ��¶�
					wen_count++;	
				}
//
			}
			if(wen_count==10) //�¶Ȳɼ���ɣ�������ǰ���棬�����¶���ʾ����
			{
				xianshi=2;
				wen_count=0;	
			}		 	
		 }

		 if(xianshi==2)
		 {
			P2=(P2&0x1f)|0x80;	 //L1����
			P0=0xff;
			P2=(P2&0x1f);
			dspbuf[0]=dspbuf[5]=11;
			dspbuf[1]=0;
			dspbuf[3]=dspbuf[4]=10;
			xianshi=3;
			wen_k=0;		
		 }

		 if(xianshi==3)
		 {
		 	dspbuf[2]=wen_k;
			dspbuf[6]=wendu[wen_k]/10;
			dspbuf[7]=wendu[wen_k]%10;
//			if((wen_k==0)&&(s6_an==0))    //�ɼ��¶���ɲ���s6��û���£�L1��˸
//			{
//				led_flag=~led_flag;
//				if(led_flag==1)
//				{
//					P2=(P2&0x1f)|0x80;	 //L1����
//					P0=0xfe;
//					P2=(P2&0x1f);
////					delay_ms(1000);		
//				}
//				if(led_flag==0)
//				{
//					P2=(P2&0x1f)|0x80;	 //L1�ر�
//					P0=0xff;
//					P2=(P2&0x1f);
////					delay_ms(1000);							
//				}			
//			}
		 }	
	 }	 
}



void isr_t0() interrupt 1
{
	TH0=(65536-2000)/256;
	TL0=(65536-2000)%256;
	display();


	 if(xianshi==1)
	 {
		 if(++ds18b20_count==(jiange*500))
		 {
		 	ds18b20_count=0;
			ds18b20_flag=1;
		 }
		 
		 if(++tishi_count==250)
		 {
		 	tishi_count=0;
			tishi_flag=~tishi_flag;
		 }
		 
		 	
	 }

	 if(xianshi==3)			   //����L1��˸
	 {
	 	if(++led_count==50)
		{
			led_count=0;
			L1_flag=1;
		}
		if(L1_flag==1)
		{
			L1_flag=0;

		 	if((wen_k==0)&&(s6_an==0))    //�ɼ��¶���ɲ���s6��û���£�L1��˸
			{
				led_flag=~led_flag;
				if(led_flag==1)
				{
					P2=(P2&0x1f)|0x80;	 //L1����
					P0=0xfe;
					P2=(P2&0x1f);		
				}
				if(led_flag==0)
				{
					P2=(P2&0x1f)|0x80;	 //L1�ر�
					P0=0xff;
					P2=(P2&0x1f);						
				}			
			}
		}
	 }
	 


	
}

void display()
{

	P2=(P2&0x1f)|0xe0;
	P0=0xff;
	P2=(P2&0x1f);

	P2=(P2&0x1f)|0xe0;
	P0=tab[dspbuf[dspcom]];
	P2=(P2&0x1f);
	P2=(P2&0x1f)|0xc0;
	P0=1<<dspcom;
	P2=(P2&0x1f);
	if(++dspcom==8)
		dspcom=0;	
}

void delay_ms(uint z)
{
	uchar i,j;
	for(i=0;i<z;i++)
		for(j=0;j<114;j++);
}

void system_init()
{
	P2=(P2&0x1f)|0x80; //��led
	P0=0xff;
	P2=(P2&0x1f);
	P2=(P2&0x1f)|0xa0; //�ط��������̵���
	P0=0;
	P2=(P2&0x1f);		
}










