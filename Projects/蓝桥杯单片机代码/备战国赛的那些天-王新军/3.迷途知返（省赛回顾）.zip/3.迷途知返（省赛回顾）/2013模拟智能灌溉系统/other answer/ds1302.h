

#ifndef __ds1302_H__
#define __ds1302_H__


#include <stc15f2k60s2.h>
#include "absacc.h"

#include "INTRINS.H"

#define uint  unsigned int
#define uchar unsigned char

sbit SCK=P1^7;		
sbit SD=P2^3;		
sbit RST=P1^3;
/********************************************************************/ 
/*???*/
#define RST_CLR	RST=0	/*????*/
#define RST_SET	RST=1	/*????*/
/*????*/
#define SDA_CLR	SD=0	/*????*/
#define SDA_SET	SD=1	/*????*/
#define SDA_R	SD	/*????*/	
/*????*/
#define SCK_CLR	SCK=0	/*????*/
#define SCK_SET	SCK=1	/*????*/

/**************************************************************

******/ 
#define ds1302_sec_addr			0x80		//??
#define ds1302_min_addr			0x82		//??
#define ds1302_hr_addr			0x84		//??
#define ds1302_date_addr		0x86		//??
#define ds1302_month_addr		0x88		//??
#define ds1302_day_addr			0x8A		//??
#define ds1302_year_addr		0x8C		//??
#define ds1302_control_addr		0x8E		//??
#define ds1302_charger_addr		0x90 		//??		 
#define ds1302_clkburst_addr	0xBE		//??????


/**************************************************************

******/ 



void Write_Ds1302_Byte(unsigned char dat); 

unsigned char Read_Ds1302_Byte(void); 

void Ds1302_Single_Byte_Write(uchar addr,uchar dat);

unsigned char Ds1302_Single_Byte_Read(unsigned char addr);
	
/*****************************************/


/////////////////////////////

//�����ʼ��

////////////////////////////
void ds1302_init(void)
{
	Ds1302_Single_Byte_Write(ds1302_control_addr,0x00);
	
	Ds1302_Single_Byte_Write(ds1302_hr_addr,16);
	Ds1302_Single_Byte_Write(ds1302_min_addr,40);
	Ds1302_Single_Byte_Write(ds1302_sec_addr,50);
	
	Ds1302_Single_Byte_Write(ds1302_control_addr,0x80);
}

/********************************************************************/ 

void Write_Ds1302_Byte(unsigned char dat) 
{
	unsigned char i;
	//EA = 0;
	SCK = 0;
	for (i=0;i<8;i++) 
	{ 
		if (dat & 0x01) 	// ???if((addr & 0x01) ==1) 
		{
			SDA_SET;		//#define SDA_SET SDA=1 /*????*/
		}
		else 
		{
			SDA_CLR;		//#define SDA_CLR SDA=0 /*????*/
		}		 
		SCK_SET;
		SCK_CLR;		
		dat = dat >> 1; 
	} 
	//EA = 1;
}

/********************************************************************/ 

unsigned char Read_Ds1302_Byte(void) 
{
	unsigned char i, dat=0;	
	//EA = 0;
	for (i=0;i<8;i++)
	{	
		dat = dat >> 1;
		if (SDA_R) 	  //???if(SDA_R==1)    #define SDA_R SDA /*????*/	
		{
			dat |= 0x80;
		}
		else 
		{
			dat &= 0x7F;
		}
		SCK_SET;
		SCK_CLR;
	}
	//EA = 1;
	return dat;
}


/********************************************/
void Ds1302_Single_Byte_Write(unsigned char addr, unsigned char dat)
{ 

	RST_CLR;			/*RST???,??DS1302????*/
	SCK_CLR;			/*SCK???,??DS1302????*/

	RST_SET;			/*??DS1302??,RST=1???? */
	addr = addr & 0xFE;	 
	Write_Ds1302_Byte(addr); /*??????:addr,??????,?????????*/	
	
	dat = (dat/10)*16 + (dat%10);
	
	Write_Ds1302_Byte(dat);	 /*????:dat*/
	RST_CLR;				 /*??DS1302??*/
}

/********************************************/
unsigned char Ds1302_Single_Byte_Read(unsigned char addr) 
{ 
	unsigned char temp;
	RST_CLR;			/*RST???,??DS1302????*/
	SCK_CLR;			/*SCK???,??DS1302????*/

	RST_SET;	/*??DS1302??,RST=1???? */	
	addr = addr | 0x01;	 
	Write_Ds1302_Byte(addr); /*??????:addr,??????,?????????*/
	
	temp=Read_Ds1302_Byte(); /*?DS1302??????????*/		
	RST_CLR;	/*??DS1302??*/
	SDA_SET;
	SDA_CLR;
	
	temp = (temp/16)*10 + (temp%16);
	
	return temp;
}








#endif