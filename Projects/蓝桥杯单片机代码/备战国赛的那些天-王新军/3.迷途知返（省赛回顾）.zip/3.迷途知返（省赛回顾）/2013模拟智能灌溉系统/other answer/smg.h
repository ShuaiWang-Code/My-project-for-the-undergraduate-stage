

#ifndef __smg_H__
#define __smg_H__


#include <stc15f2k60s2.h>
#include "absacc.h"

#include "INTRINS.H"

#define uint  unsigned int
#define uchar unsigned char



code uchar smg_data[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90 ,0xff,0xbf,0x7f};
code uchar smg_clos = 10;
code uchar smg_f = 11;
code uchar smg_d = 12;


void smg_n(uchar n,uchar sum)
{
	XBYTE[0XE000] = 0XFF;
	
	XBYTE[0XC000] = (0X01<<(n-1));
	
	XBYTE[0XE000] = sum;
}


void smg_display_1(uchar sum1,uchar sum2,uchar sum3)
{
	static uchar i = 0;
	
	uchar temp[8] = {0};
	
	temp[0] = sum1/10;
	temp[1] = sum1%10;
	
	temp[2] = smg_f;
	temp[3] = sum2/10;
	
	temp[4] = sum2%10;
	temp[5] = smg_clos;
	
	temp[6] = sum3/10;
	temp[7] = sum3%10;
	
	smg_n(i,smg_data[temp[i-1]]);
	
	if(i > 8)
		i = 0;
	i++;
	
}

void smg_display_2(uchar sum)
{
	static uchar i = 0;
	
	uchar temp[8] = {0};
	
	temp[0] = smg_f;
	temp[1] = smg_f;
	
	temp[2] = smg_clos;
	temp[3] = smg_clos;
	
	temp[4] = smg_clos;
	temp[5] = smg_clos;
	
	temp[6] = sum/10;
	temp[7] = sum%10;
	
	smg_n(i,smg_data[temp[i-1]]);
	
	if(i > 8)
		i = 0;
	i++;
	
}















#endif