

#ifndef __key_H__
#define __key_H__


#include <stc15f2k60s2.h>
#include "absacc.h"
#include "delay.h"
#include "INTRINS.H"

#define uint  unsigned int
#define uchar unsigned char



extern bit flag_smg;
extern uchar flag_rb2,rb2;

bit flag_set = 0;
bit flag_beep = 0;
bit flag_water = 0;
bit flag_set_rb2 = 0;




void key_init(void)
{
	P3 |= 0x0f;
}

void key(void)
{
	uchar key_sum = 0;
	P3 |= 0x0f;
	if(P30 == 0)
	{
		flag_set = ~flag_set;
		key_sum = 0;
		delay_ms(10);
		while(P30 == 0);
		
	}
	if(P31 == 0)
	{
		flag_set_rb2 =~ flag_set_rb2;
		key_sum = 1;
		delay_ms(10);
		while(P31 == 0);
	}
	if(P32 == 0)
	{
		key_sum = 2;
		delay_ms(10);
		while(P32 == 0);
	}
	if(P33 == 0)
	{
		key_sum = 3;
		delay_ms(10);
		while(P33 == 0);
	}
	
	//*****************�Զ�״̬******************
	if(flag_set == 0)
	{
		
		if(flag_set_rb2 == 0)
		{
			flag_smg = 0;
		}
		if(flag_set_rb2 == 1)
		{
			flag_smg = 1;
			
			if(key_sum == 2)
			{
				flag_rb2++;
				delay_ms(10);
				iic_write_byte(0x00,flag_rb2);
				delay_ms(10);
			}	
			if(key_sum == 3)
			{
				flag_rb2--;
				iic_write_byte(0x00,flag_rb2);
			}
			
		}
	}
	//*****************�ֶ�״̬******************
	if(flag_set == 1)
	{
		if(key_sum == 1)
		{
			flag_beep =~flag_beep;
		}
		if(key_sum == 2)
		{
			flag_water = 1;//��
		}
		if(key_sum == 3)
		{
			flag_water = 0;//��
		}
	}
	//************���ּ�************
	if((flag_set == 1)&&(flag_smg == 1))
	{
		flag_set = 0;
	}
}



void other_case(void)
{
	uchar temp = 0x00;
	uchar led = 0xff;
	//***************
	if((rb2 < flag_rb2)&&(flag_beep == 1))
	{
		temp |= (0x01<<6);
	}
	if((rb2 >= flag_rb2)|(flag_beep == 0))
	{
		temp &=~(0x01<<6);
	}
	//***************
	if((rb2 < flag_rb2)&&(flag_water == 1))
	{
		temp |= (0x01<<4);
	}
	if((rb2 >= flag_rb2)|(flag_water == 0))
	{
		temp &=~(0x01<<4);
	}
	
	//***************
	if(flag_set == 0)
	{
		led |= (0x01<<0);
		led &=~(0x01<<1);
	}
	if(flag_set == 1)
	{
		led &=~(0x01<<0);
		led |= (0x01<<1);
	}
	
	XBYTE[0XA000] = temp;
	XBYTE[0X8000] = led;
	
}









#endif