/********************************
//----------JM---------------
//���ݣ�2013�����

//�� B ��Ʒ

//����bug��,��qq��874206295����
//���ߣ��˴��尮��С��
//��ֲ��ͯЬ�����������ߣ���������

**********************************/






/*********************************

//ע�⣺����Ĭ��11.0592mhz
//����оƬ��stc15f2k60s2
//------��ʹ��MMģʽ-----

//----------JM----------------
*********************************/








#include <stc15f2k60s2.h>
#include "absacc.h"
#include "INTRINS.H"


#include "smg.h"
#include "ds1302.h"
#include "iic.h"
#include "key.h"
#include "delay.h"

#define uint  unsigned int
#define uchar unsigned char




//********ʱ��*********
uchar hour,min,sec;

//******����ʪ��*******
uchar flag_rb2 = 50,rb2 = 0;



//*****ִ�б�־λ******
bit flag_eeprom = 0;
bit flag_key = 0;
bit flag_ds18b20 = 0;
bit flag_smg = 0;
bit flag_ds1302 = 0;
bit flag_adc = 0;





void start_init(void)
{
	
	XBYTE[0XE000] = 0XFF;	//SMG_DATA
	
	XBYTE[0XC000] = 0XFF;	//SMG_BIT
	
	XBYTE[0X8000] = 0XFF;	//LED
	
	XBYTE[0XA000] = 0X00;	//BEEP
	
	
	flag_eeprom = 1;
	flag_key = 1;
	flag_ds18b20 = 1;
	flag_smg = 0;
	flag_ds1302 = 1;
	flag_adc = 1;
}


void timer0_init(void)
{
	
	TMOD |= 0X01;
	
	TH0 = 0XF8;
	TL0 = 0XCD;//
	
	TR0 = 1;
	ET0 = 1;
	EA  = 1;
	
}



void timer0_isr(void)  interrupt 1
{
	
	static uchar flag_key_temp = 0;
	static uchar flag_ds18b20_temp = 0;
	static uchar flag_eeprom_temp = 0;
	static uint flag_ds1302_temp = 0;
	static uchar flag_other_temp = 0;
	
	TR0 = 0;
	
	TH0 = 0XF8;
	TL0 = 0XCD;//
	
	if(++flag_key_temp == 20)				//���� 40ms
	{
		flag_key = 1;
		
		flag_key_temp = 0;
	}
	
	if(++flag_ds18b20_temp == 250)	//�¶� 500ms
	{
		flag_ds18b20 = 1;
		
		flag_ds18b20_temp = 0;
	}
	
	if(++flag_eeprom_temp == 250)		//eeprom 400ms
	{
		flag_eeprom = 1;
		
		flag_eeprom_temp = 0;
	}
	
	if(++flag_ds1302_temp == 2000)		//ds1302 800ms
	{
		flag_ds1302 = 1;
		
		flag_ds1302_temp = 0;
	}
	
	if(++flag_other_temp == 200)		//adc+beep+jdq 400ms
	{
		flag_adc = 1;
		
		other_case();
		flag_other_temp = 0;
	}
	
	if(flag_smg == 0)
		smg_display_1(hour,min,rb2);
	if(flag_smg == 1)
		smg_display_2(flag_rb2);
	
	TR0 = 1;
}





void main(void)
{
	
	start_init();
	
	adc_init(0x03);//adͨ��3
	
	ds1302_init();
	
	key_init();
	
	
	timer0_init();
	
	
	while(1)
	{
		
		if(flag_eeprom)
		{
			delay_ms(10);
			flag_rb2 = iic_read_byte(0x00);
			delay_ms(10);
			flag_eeprom = 0;
		}
		if(flag_ds1302)
		{
			hour = Ds1302_Single_Byte_Read(ds1302_hr_addr+1);
			min = Ds1302_Single_Byte_Read(ds1302_min_addr+1);
			
			flag_ds1302 = 0;
		}
		
		if(flag_adc)
		{
			rb2 = adc_read_byte(0x03);
			flag_adc = 0;
		}
		
		if(flag_key)
		{
			key();
			flag_key = 0;
		}
		
		
	}
	
}





