#include "reg52.h"
#include "iic.h"
#include "ds1302.h"
#define uchar unsigned char
#define uint  unsigned int
#define BUZZ_ON   0x40
#define BUZZ_OFF  0x00
#define RELAY_ON  0x10
#define RELAY_OFF 0x00
#define L1_ON     0xfe
#define L1_OFF    0xff
#define L2_ON     0xfd
#define L2_OFF    0xff

sbit s4=P3^3;
sbit s5=P3^2;
sbit s6=P3^1;
sbit s7=P3^0;
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xbf,0xff};
uchar dspbuf[8]={1,2,3,4,5,6,7,8};
uchar dspcom=0;
uchar mode=0;//0�Զ���1�ֶ�
uchar yuzhi=50;//ʪ����ֵ
bit adc_flag=0;
uchar adc_intr=0;
uchar adc_value=0;
uchar hour,min;
uchar set_yuzhi=0;
uchar buzz_flag=0;//�������÷����������ѹ��ܣ�0�򿪣�1�ر�

bit L1_flag=0;
bit L2_flag=0;
bit b_r1=0;
bit	b_r2=0;
bit b_r3=0;
bit	b_r4=0;
uchar BUZZ=BUZZ_ON,RELAY=RELAY_OFF;

void display();
void delay(uchar z);
void read_key();
void smg_jiemian();

void main()
{
		TMOD=0x01;
		TH0=(65536-2000)/256;
		TL0=(65536-2000)%256;
		EA=1;
		ET0=1;
		TR0=1;
		ds1302_init(0x08,0x30,0x00);
		P0=0;
		P2=(P2&0x1f)|0xa0;
		P2=(P2&0x1f);
		yuzhi=read_eeprom(0);
		delay(10);
		while(1)
		{				
				if(adc_flag==1)
				{
						adc_flag=0;
						adc_value=adc_pcf8591(3);
						adc_value=adc_value*99/255;
				}
				
				read_key();	
				
				smg_jiemian();
				
				if(mode==0)//�Զ�
				{
						if(L1_flag==0)
						{
								P0=L1_ON&L2_OFF;
								P2=(P2&0x1f)|0x80;
								P2=(P2&0x1f);
								L1_flag=1;
								L2_flag=0;
						}
						
						if(adc_value<yuzhi)
						{
								if(b_r1==0)
								{
										P0=RELAY_ON|BUZZ_OFF;
										P2=(P2&0x1f)|0xa0;
										P2=(P2&0x1f);
										b_r1=1;
										b_r2=0;
								}							
						}
						if(adc_value>=yuzhi)
						{
								if(b_r2==0)
								{
										P0=RELAY_OFF|BUZZ_OFF;
										P2=(P2&0x1f)|0xa0;
										P2=(P2&0x1f);
										b_r1=0;
										b_r2=1;
								}
						}
						
				}
				
				if(mode==1)//�ֶ�
				{
						if(L2_flag==0)
						{
								P0=L1_OFF&L2_ON;
								P2=(P2&0x1f)|0x80;
								P2=(P2&0x1f);
								L1_flag=0;
								L2_flag=1;
						}
						if(adc_value<yuzhi)
						{
								if(b_r3==0)
								{
										P0=RELAY|BUZZ;
										P2=(P2&0x1f)|0xa0;
										P2=(P2&0x1f);
										b_r3=1;
										b_r4=0;
								}
						}
						if(adc_value>=yuzhi)
						{
								if(b_r4==0)
								{
										P0=RELAY|BUZZ_OFF;
										P2=(P2&0x1f)|0xa0;
										P2=(P2&0x1f);
										b_r3=0;
										b_r4=1;
								}
						}
				}
		}
}

void isr_timer0() interrupt 1
{
		TH0=(65536-2000)/256;
		TL0=(65536-2000)%256;
		display();
		
		if(++adc_intr==20)
		{
				adc_flag=1;
				adc_intr=0;
		}
}

void display()
{
		P0=0xff;
		P2=(P2&0x1f)|0xe0;
		P2=(P2&0x1f);
		P0=1<<dspcom;
		P2=(P2&0x1f)|0xc0;
		P2=(P2&0x1f);
		P0=tab[dspbuf[dspcom]];
		P2=(P2&0x1f)|0xe0;
		P2=(P2&0x1f);
		if(++dspcom==8)
				dspcom=0;
}

void delay(uchar z)
{
		uchar x,y;
		for(x=z;x>0;x--)
				for(y=0;y<114;y++);
}

void smg_jiemian()
{
		if(set_yuzhi==0)
		{
				hour=Ds1302_Single_Byte_Read(ds1302_hr_addr);
				min=Ds1302_Single_Byte_Read(ds1302_min_addr);
				dspbuf[0]=hour/16;
				dspbuf[1]=hour%16;
				dspbuf[2]=10;
				dspbuf[3]=min/16;
				dspbuf[4]=min%16;
				dspbuf[5]=11;
				dspbuf[6]=adc_value/10;
				dspbuf[7]=adc_value%10;
		}
		
		
		if(set_yuzhi==1)
		{
				dspbuf[0]=dspbuf[1]=10;
				dspbuf[2]=dspbuf[3]=dspbuf[4]=dspbuf[5]=11;
				dspbuf[6]=yuzhi/10;
				dspbuf[7]=yuzhi%10;
		}
}

void read_key()
{
		if(s7==0)
		{
				delay(10);
				if(s7==0)
				{
						while(!s7);
						mode++;
						if(mode==2)
								mode=0;
						if(mode==0)
						{
								b_r1=0;
								b_r2=0;
						}
				}
		}
		
		if(mode==1)//�ֶ�
		{
				if(s6==0)
				{
						delay(10);
						if(s6==0)
						{
								while(!s6);
								buzz_flag++;
								if(buzz_flag==2)
								{
										buzz_flag=0;
								}
								
								if(buzz_flag==0)
								{
										BUZZ=BUZZ_ON;
										b_r3=0;
										b_r4=0;
								}
								
								if(buzz_flag==1)
								{
										BUZZ=BUZZ_OFF;
										b_r3=0;
										b_r4=0;
								}
						}
				}
				
				if(s5==0)
				{
						delay(10);
						if(s5==0)
						{	
								while(!s5);
								RELAY=RELAY_ON;
								b_r3=0;
								b_r4=0;
						}
				}
				
				if(s4==0)
				{
						delay(10);
						if(s4==0)
						{
								while(!s5);
								RELAY=RELAY_OFF;
								b_r3=0;
								b_r4=0;
						}
				}
		}
		
		if(mode==0)//�Զ�
		{
				if(s6==0)
				{
						delay(10);
						if(s6==0)
						{
								while(!s6);
								set_yuzhi++;
								if(set_yuzhi==2)
								{
										set_yuzhi=0;
										write_eeprom(0,yuzhi);
										delay(10);
								}
						}
				}
				
				if(set_yuzhi==1)
				{
						if(s5==0)
						{
								delay(10);
								if(s5==0)
								{
										while(!s5);
										yuzhi++;
								}
						}
						
						if(s4==0)
						{
								delay(10);
								if(s4==0)
								{
										while(!s4);
										yuzhi--;
								}
						}
				}
				
		}
}