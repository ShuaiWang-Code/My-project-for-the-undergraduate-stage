#include <reg51.h>
#include <absacc.h>
#include <ds1302.h>
uchar code tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbf};
uchar duabuf[8]={10,10,10,10,10,10,10,10};
uchar th,tl,dspcom=0;
void display();
void init_t0(uint ms);
int main()
{
	extern uchar time[7];
  EA=1;
	init_t0(1);
	int1302();
	while(1)
	{
	  read1302();
		duabuf[0]=time[2]/16;
		duabuf[1]=time[2]%16;
		duabuf[2]=11;
		duabuf[3]=time[1]/16;
		duabuf[4]=time[1]%16;
		duabuf[5]=11;
		duabuf[6]=time[0]/16;
		duabuf[7]=time[0]%16;
	}
}
void init_t0(uint ms)
{
  ulong tme;
	tme=65536-ms*1000;
	th=tme>>8;
	tl=tme;
	TH0=th;
	TL0=tl;
	TMOD&=0xf0;
	TMOD|=0x01;
	TR0=1;
	ET0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
	display();
}
void display()
{
XBYTE[0XE000]=0xff;
XBYTE[0XC000]=0X01<<dspcom;
XBYTE[0XE000]=tab[duabuf[dspcom]];
if(++dspcom==8)dspcom=0;
}