#include <reg51.h>
#include <absacc.h>
#define uchar unsigned char
#define uint unsigned int
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar duabuf[8]={10,10,10,10,10,10,10,10};
uchar th,tl,dspcom=0;
uint cnt;
bit flag=0;
uchar keyvaule;
void display();
void  init_t0(uint ms);
void keyscan();
void main()
{
  EA=1;
	init_t0(1);
	while(1)
	{
	
	}
}
void init_t0(uint ms)
{
unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=65536-tme;
	th=(uchar)(tme>>8);
	tl=(uchar)tme;
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
	cnt++;
	if(cnt>=1000)
	{
	cnt=0;
	flag=1;
	}
	display();
}
void display()
{
  XBYTE[0XE000]=0XFF;
	XBYTE[0XC000]=0x01<<dspcom;
	XBYTE[0XE000]=tab[duabuf[dspcom]];
	if(++dspcom==8)dspcom=0;
}
void keyscan()
{
	uchar temp;
  P3=0xfe;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp&=0xf0;
	while(temp!=0xf0)
	{
		temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		switch (temp)
		{
			case 0xee:keyvaule=1;break;
			case 0xde:keyvaule=2;break;
	    case 0xbe:keyvaule=3;break;
	    case 0x7e:keyvaule=4;break;			
		}
		while(temp!=0xf0)
	{
		temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	  temp&=0xf0;
	}
	}
	
  P3=0xfd;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp&=0xf0;
	while(temp!=0xf0)
	{
		temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		switch (temp)
		{
			case 0xed:keyvaule=5;break;
			case 0xdd:keyvaule=6;break;
	    case 0xbd:keyvaule=7;break;
	    case 0x7d:keyvaule=8;break;			
		}
		while(temp!=0xf0)
	{
		temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	  temp&=0xf0;
	}
	}
	
  P3=0xfb;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp&=0xf0;
	while(temp!=0xf0)
	{
		temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		switch (temp)
		{
			case 0xeb:keyvaule=9;break;
			case 0xdb:keyvaule=10;break;
	    case 0xbb:keyvaule=11;break;
	    case 0x7b:keyvaule=12;break;			
		}
		while(temp!=0xf0)
	{
		temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	  temp&=0xf0;
	}
	}
	
  P3=0xf7;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp&=0xf0;
	while(temp!=0xf0)
	{
		temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		switch (temp)
		{
			case 0xe7:keyvaule=13;break;
			case 0xd7:keyvaule=14;break;
	    case 0xb7:keyvaule=15;break;
	    case 0x77:keyvaule=16;break;			
		}
		while(temp!=0xf0)
	{
		temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	  temp&=0xf0;
	}
	}
}