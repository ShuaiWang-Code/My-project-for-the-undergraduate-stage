#include <reg51.h>
#include "absacc.h"
#include "iic.h"
#define uchar unsigned char
#define uint unsigned int
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar duabuf[8]={10,10,10,10,10,10,10,10};
uchar duabuf1[8]={10,10,10,10,10,10,10,10};
uchar temp[8]={10,10,10,10,10,10,10,10};
uchar temp1[8]={10,10,10,10,10,10,10,10};
uchar th,tl,dspcom=0,dspcom1=0;
bit flag=0;
bit zongflag=0;
bit manflag=0;
bit lightf=0;
uint nt1=0;
uint nt=0;
uint cnt;
uint cnt1=0;
uint sheng=0;
uint danjia=5;
uint zongjia=0;
void display();
void display1();
void init_t0(uint ms);
void chuli();
void show();
void show1();
void jidian(bit flag);
void deng();
extern void keyscan();
extern void delay(uint ms);
extern bit flag6,flag7;
void main()
{
	EA=1;
	init_t0(1);
while(1)
{
  keyscan();
	chuli();
	deng();
	if(zongflag==1)
	{
	show();
	jidian(1);
	}
	else
	{
	show1();
	jidian(0);

	}
}
}
void init_t0(uint ms)
{
 unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=(65536-tme);
	th=(uchar)(tme>>8);
	tl=(uchar)tme;
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
	if(zongflag==1)
	{
	cnt++;
	display();
	}
	else 
	{
	display1();
	cnt=0;
	}
	if(cnt>=100)
	{
	cnt=0;
	flag=1;
	}
	cnt1++;
	if(cnt1>=100)
	{
	cnt1=0;
		lightf=1;
	}
}
void display()
{
	XBYTE[0xE000] = 0xff;  	
	XBYTE[0xC000] = (1<<dspcom);
  XBYTE[0xE000] = temp[dspcom];
if(++dspcom==8)dspcom=0;
}
void display1()
{
	XBYTE[0xE000] = 0xff;  
	XBYTE[0xC000] = (1<<dspcom1);
  XBYTE[0xE000] = temp1[dspcom1];	
if(++dspcom1==8)dspcom1=0;
}
void chuli()
{
if(flag6)
{
flag6=0;
nt1++;
if(nt1>5){zongjia=0;sheng=0;}
nt=0;
zongflag=0;
}
if(flag7)
{
nt1=0;
if(nt==0)sheng=0;
nt++;
flag7=0;
zongflag=1;
}
if(flag)
{
flag=0;
sheng++;
}
if(sheng>=9999)
{
manflag=1;
}
if(manflag)
{
  manflag=0;
	zongflag=0;
  jidian(0);
	nt=0;
	nt1=1;
}
}
void show()
{
duabuf[0]=10;
duabuf[1]=0;
duabuf[2]=5;
duabuf[3]=0;
duabuf[7]=sheng%10;
duabuf[6]=sheng/10%10;
duabuf[5]=sheng/100%10;
duabuf[4]=sheng/1000%10;	
temp[0]=tab[duabuf[0]];
temp[1]=(tab[duabuf[1]]&0x7f);
temp[2]=tab[duabuf[2]];
temp[3]=tab[duabuf[3]];
temp[4]=tab[duabuf[4]];
temp[5]=(tab[duabuf[5]]&0x7f);
temp[6]=tab[duabuf[6]];
temp[7]=tab[duabuf[7]];
}
void show1()
{
zongjia=(sheng*danjia)/10;
duabuf1[0]=10;
duabuf1[1]=0;
duabuf1[2]=5;
duabuf1[3]=0;
duabuf1[7]=zongjia%10;
duabuf1[6]=zongjia/10%10;
duabuf1[5]=zongjia/100%10;
duabuf1[4]=zongjia/1000%10;	
temp1[0]=tab[duabuf1[0]];
temp1[1]=(tab[duabuf1[1]]&0x7f);
temp1[2]=tab[duabuf1[2]];
temp1[3]=tab[duabuf1[3]];
temp1[4]=tab[duabuf1[4]];
temp1[5]=(tab[duabuf1[5]]&0x7f);
temp1[6]=tab[duabuf1[6]];
temp1[7]=tab[duabuf1[7]];
}
void jidian(bit flag)
{
if(flag)
{
XBYTE[0xA000]	=0x10;
}
else
{
XBYTE[0xA000]=0x00;
}
}
void deng()
{
  uint light;
	float lt;
	if(lightf)
	{
   lightf=0;
   light=readad(1);
	}
  lt=light*5.0/255;
	if(lt<=1.25)
	{
	XBYTE[0x8000]=0xfe;
	}
	else
	{
	XBYTE[0x8000]=0xff;
	}
}