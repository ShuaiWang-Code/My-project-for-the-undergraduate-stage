#include <reg51.h>
#define uchar unsigned char
#define uint unsigned int

void delay();

void main()
{
while(1)
{
	P2=(P2&0x1f)|0xa0;
  P0=(P0&0x00)|0x20;
	delay();
  P0=(P0&0x00)|0x00;
	delay();
}
}
void delay()
{
	uint i;
 for(i=0;i<=500;i++);
}