#include <reg51.h>
#include <absacc.h>
#include "iic.h"
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar duabuf[8]={10,10,10,10,10,10,10,10};
uchar tp[8];
uchar th,tl,dspcom;
void showre();
void init_t0(uint ms);
void display();
void display1();
void mode(bit jiflag,bit beflag);
bit dianflag=0;
void show();
uint cnt=0;
bit flag=0;
bit fengmin=0;
void main()
{
EA=1;
init_t0(1);
	dianflag=0;
	while(1)
	{
	
		if(flag)
		{showre();
		fengmin=~fengmin;
			flag=0;
		}
	mode(fengmin,fengmin);	
	}
}
void showre()
{
  uchar temp;
	temp=readad(0x03);
	duabuf[0]=temp/100%10;
	duabuf[1]=temp/10%10;
	duabuf[2]=temp%10;
}
void init_t0(uint ms)
{
ulong tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=(65535-tme);
	th=(uchar)(tme>>8);
	tl=(uchar)(tme);
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	TR0=1;
	ET0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
	if(++cnt>=1000)
	{
	cnt=0;
	flag=1;
	}
	if(!dianflag)
	display();
	else
	display1();
}
void display()
{
XBYTE[0xe000]=0xff;
XBYTE[0xc000]=0x01<<dspcom;
XBYTE[0xe000]=tab[duabuf[dspcom]];
if(++dspcom==8)dspcom=0;
}
void display1()
{
XBYTE[0xe000]=0xff;
XBYTE[0xc000]=0x01<<dspcom;
XBYTE[0xe000]=tp[dspcom];
if(++dspcom==8)dspcom=0;
}
void show()
{
  tp[0]=(tab[duabuf[0]])&0x7f;
  tp[1]=(tab[duabuf[1]])&0x7f;
  tp[2]=(tab[duabuf[2]])&0x7f;	
  tp[3]=(tab[duabuf[3]])&0x7f;
  tp[4]=(tab[duabuf[4]])&0x7f;
	tp[5]=(tab[duabuf[5]])&0x7f;
	tp[6]=(tab[duabuf[6]])&0x7f;
	tp[7]=(tab[duabuf[7]])&0x7f;
}
void mode(bit jiflag,bit beflag)
{
uchar temp;
if(jiflag==1)
{
temp|=(0x01<<4);
}
else
{
temp&=(~(0x01<<4));
}
if(beflag==1)
{
temp|=(0x01<<6);
}
else
{
temp&=(~(0x01<<6));
}
XBYTE[0xa000]=temp;
}
