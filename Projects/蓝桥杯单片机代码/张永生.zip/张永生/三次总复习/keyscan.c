#include <reg51.h>
char keyvalue=(-1);
void keyscan()
{
uchar temp;
P3=0xfe;P4=0x14;
temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
temp&=0xf0;
if(temp!=0xf0)
{
temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	switch (temp)
	{
		case 0xee:keyvalue=0;break;
		case 0xde:keyvalue=1;break;
		case 0xbe:keyvalue=2;break;
		case 0x7e:keyvalue=3;break;
	}
	while(temp!=0xf0)
	{
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
  temp&=0xf0;
	}
}

P3=0xfd;P4=0x14;
temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
temp&=0xf0;
if(temp!=0xf0)
{
temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	switch (temp)
	{
		case 0xed:keyvalue=4;break;
		case 0xdd:keyvalue=5;break;
		case 0xbd:keyvalue=6;break;
		case 0x7d:keyvalue=7;break;
	}
	while(temp!=0xf0)
	{
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
  temp&=0xf0;
	}
}

P3=0xfb;P4=0x14;
temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
temp&=0xf0;
if(temp!=0xf0)
{
temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	switch (temp)
	{
		case 0xeb:keyvalue=8;break;
		case 0xdb:keyvalue=9;break;
		case 0xbb:keyvalue=10;break;
		case 0x7b:keyvalue=11;break;
	}
	while(temp!=0xf0)
	{
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
  temp&=0xf0;
	}
}

P3=0xf7;P4=0x14;
temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
temp&=0xf0;
if(temp!=0xf0)
{
temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	switch (temp)
	{
		case 0xe7:keyvalue=12;break;
		case 0xd7:keyvalue=13;break;
		case 0xb7:keyvalue=14;break;
		case 0x77:keyvalue=15;break;
	}
	while(temp!=0xf0)
	{
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
  temp&=0xf0;
	}
}
}