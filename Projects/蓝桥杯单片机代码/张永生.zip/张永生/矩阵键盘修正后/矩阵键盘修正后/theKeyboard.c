#include <reg52.h>  //����51��Ƭ�����⹦�ܼĴ���
//#include"STC15F2K60S2.h" 
//��Ϊ���ű���CT107Dƽ̨���������ߣ����еĽӿ��Ѿ������ʹ�ã�
//��52.h��ͷ�ļ��о�����̺�LED�ӿ����ظ��������Ե���Դ���������޷�Ӧ
//����Ӧ�ý���ƽ̨оƬ��ͷ�ļ���������
#include "absacc.h"
#define uchar unsigned char 
#define uint unsigned int 
bit key_re;
unsigned char key_press;
unsigned char key_value;

bit key_flag;
unsigned char intr;

unsigned char read_keyboard(void);

code unsigned char tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar duabuf[8]={10,10,10,10,10,0,0,0};
uchar dspcom;
void display();
void delay(uint z)
{
uint x,y;
for(x=z;x>0;x--)
   for(y=110;y>0;y--);
}
void main(void)
{ 
    unsigned char key_temp = 0xff;
    
    TMOD |= 0x01;  
    TH0 = (65536-2000)/256;
    TL0 = (65536-2000)%256;  
    EA = 1;
    ET0 = 1;  
    TR0 = 1;  
    
    while(1)
    {
        if(key_flag)
        {
            key_flag = 0;
            key_temp = read_keyboard();   
					duabuf[7]=key_value%10;
	        duabuf[6]=key_value/10%10;
        } 
        
              
          
    }
}

//��ʱ���жϷ�����
void isr_timer_0(void)  interrupt 1  //Ĭ���ж����ȼ� 1
{
    TH0 = (65536-2000)/256;
    TL0 = (65536-2000)%256;  //��ʱ������ 
    display(); 
	if(++intr == 10)  //2msִ��һ��
	{
        intr = 0;
		key_flag = 1;  //20ms����ɨ���־λ��1
    }
}

//��ȡ������̼�ֵ
unsigned char read_keyboard(void)
{
    unsigned char key_temp;
	  P3=0xfe;P4|=0x14;
	  key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
    while(key_temp != 0xf0) 
		{
		delay(5);		
	  key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
    while(key_temp!=0xf0)	
		{
		key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
			switch(key_temp)
			{
				case 0xee:key_value=4;break;
				case 0xde:key_value=3;break;
				case 0xbe:key_value=2;break;
				case 0x7e:key_value=1;break;
			}
			while(key_temp!=0xf0)
			{
		key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
			}
		}			
		}
       
	  P3=0xfd;P4|=0x14;
	  key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
    while(key_temp != 0xf0) 
		{
		delay(5);		
	  key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
    while(key_temp!=0xf0)	
		{
		key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
			switch(key_temp)
			{
				case 0xed:key_value=8;break;
				case 0xdd:key_value=7;break;
				case 0xbd:key_value=6;break;
				case 0x7d:key_value=5;break;
			}
			while(key_temp!=0xf0)
			{
		key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
			}
		}			
		}	
    
		
		P3=0xfb;P4|=0x14;
	  key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
    while(key_temp != 0xf0) 
		{
		delay(5);		
	  key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
    while(key_temp!=0xf0)	
		{
		key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
			switch(key_temp)
			{
				case 0xeb:key_value=12;break;
				case 0xdb:key_value=11;break;
				case 0xbb:key_value=10;break;
				case 0x7b:key_value=9;break;
			}
			while(key_temp!=0xf0)
			{
		key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
			}
		}			
		}
		
		P3=0xf7;P4|=0x14;
	  key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
    while(key_temp != 0xf0) 
		{
		delay(5);		
	  key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
    while(key_temp!=0xf0)	
		{
		key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
			switch(key_temp)
			{
				case 0xe7:key_value=16;break;
				case 0xd7:key_value=15;break;
				case 0xb7:key_value=14;break;
				case 0x77:key_value=13;break;
			}
			while(key_temp!=0xf0)
			{
		key_temp=((P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4));
    key_temp=key_temp&0xf0;
			}
		}			
		}
		return key_value;
}




void display()
{
  P2=(P2&0x1f)|0xc0;
	P0=1<<dspcom;
	P2=(P2&0x1f)|0xe0;
	P0=tab[duabuf[dspcom]];
	if(++dspcom==8)dspcom=0;
}