            #include <reg52.h>
             #include "onewire.h"
             #define uchar unsigned char
            #define uint unsigned int
             uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbe};
             uchar duabuf[8]={10,10,10,10,10,10,10,10};
             uchar duabuf1[8]={10,10,10,10,10,10,10,10};
             uint TMAX=30;
             uint TMIN=20;
            uchar th,tl,dspcom;
            uint cnt=0;
            uint wenpinglv=0;
            uint ledji1=0;
            uint ledji2=0;
            uint ledji3=0;
            
            bit wenflag=0;
            bit ledflag1=0;
            bit ledflag2=0;
            bit ledflag3=0;
            bit LEDFLAG1=0;
            bit LEDFLAG2=0;
            bit LEDFLAG3=0;
            uint jidflag1=0;
            uint jidflag2=0;
            uint jidflag3=0;
            void initt0(uint ms)
            {
          unsigned long tme;
          tme=12000000/12;
          tme=(tme*ms)/1000;
      tme=(65536-tme);
       th=(uchar)(tme>>8);
        tl=(uchar)(tme);
      TMOD&=0xf0;
       TMOD|=0x01;
     TH0=th;
     TL0=tl;
       ET0=1;
      TR0=1;
    }
         
          void display()
          {
       P2=(P2&0x1f)|0xc0;
       P0=0x01<<dspcom;
       P2=(P2&0x1f)|0xe0;
      P0=tab[duabuf[dspcom]];
      if(++dspcom==8)dspcom=0;
     }
        void display1()
        {
       P2=(P2&0x1f)|0xc0;
      P0=0x01<<dspcom;
     P2=(P2&0x1f)|0xe0;

      P0=tab[duabuf1[dspcom]];
       if(++dspcom==8)dspcom=0;
     }
        
          void chuli(uint wen)
          {
      uint wen1;
       wen1=wen*0.0625;
       if(wen1<=TMAX&&wen1>=TMIN)
      {
        duabuf[1]=1;
      }
       else if(wen1<TMIN)
         {
           duabuf[1]=0;
         }
          else if(wen1>TMAX)
         {
           duabuf[1]=2;
         }
         else
         {
         duabuf[1]=10;
         }
         duabuf[7]=wen1%10;
        duabuf[6]=wen/10%10;
         duabuf[0]=11;
         duabuf[2]=11;
         
         if(duabuf[1]==0)
         { 
          jidflag1++;
          jidflag2=0;
          jidflag3=0;
        if(jidflag1<=1)
       {
         P2=(P2&0x1f)|0xa0;
        P0=(P0&0x00)|0x00;
         }
          else if(jidflag1>1)
          {
           
            if(jidflag1>100)
            {jidflag1=5;}
          ledflag1=1;
        if(LEDFLAG1==1)
          {
          LEDFLAG1=0;
             P2=(P2&0x1f)|0x80;
          P0=(~P0)&0x01;
           }
         }
      }
        
      if(duabuf[1]==1)
       { 
        jidflag1=0;
        jidflag2++;
         jidflag3=0;
        if(jidflag2<=1)
         {
        P2=(P2&0x1f)|0xa0;

        P0=(P0&0x00)|0x00;
        }
         else if(jidflag2>1)
        {
            
           if(jidflag2>100)
           {jidflag2=5;}
           ledflag2=1;
           if(LEDFLAG2==1)
          {
           LEDFLAG2=0;
            P2=(P2&0x1f)|0x80;
           P0=(~P0)&0x01;
          }
        }
        } 
         
        if(duabuf[1]==2)
       { 
          jidflag1=0;
         jidflag2=0;
          jidflag3++;
         if(jidflag3<=1)
         {
        P2=(P2&0x1f)|0xa0;
         P0=(P0&0x00)|0x01;
         }
        else if(jidflag3>1)
       {
            
           if(jidflag3>100)
            {jidflag3=5;}
          ledflag3=1;
           if(LEDFLAG3==1)
           {
            LEDFLAG3=0;
           P2=(P2&0x1f)|0x80;
            P0=(~P0)&0x01;
           }
         }
       }
       
         if(duabuf[1]==10)
       { 
         jidflag1=0;
         jidflag2=0;
         jidflag3=0;
          P2=(P2&0x1f)|0x80;
         P0=(~P0)&0x02; 
         }
       }
          void wenstart()
         {
        uint re;
         if(wenflag)
         {
          wenflag=0;
        re=read_temp();
        }
         chuli(re);
      }
         void int0() interrupt 1

        {
        extern bit setmood;
        TH0=th;
        TL0=tl;
       cnt++;
        wenpinglv++;
        if(wenpinglv>=100)
         {
           wenpinglv=0;
          wenflag=1;
       }
      if(ledflag1==1)
       {
         ledji1++;
          if(ledji1>=400)
          {
          ledji1=0;
         LEDFLAG1=1;
          }
        }
          if(ledflag2==1)
        {
          ledji2++;
          if(ledji2>=200)
           {
          ledji2=0;
           LEDFLAG2=1;
        }
        }
          if(ledflag3==1)
         {
         ledji3++;
          if(ledji3>=100)
           {
          ledji3=0;
          LEDFLAG3=1;
          }
        }
       if(setmood==0)
       display();
        else
        display1();
       }