#include <reg52.h>
#include "onewire.h"
extern void display();
extern void initt0(uint ms);
#define LED   0x80
#define DELAY 0xa0
sbit led1=P0^0;
sbit led2=P0^1;
sbit delay=P0^4;
void main()
{
	EA=1;
	initt0(1);
while(1)
{

}
}
