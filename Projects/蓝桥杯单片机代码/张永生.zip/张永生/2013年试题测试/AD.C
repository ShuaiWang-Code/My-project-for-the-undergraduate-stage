#include <reg52.h>
#include "iic.h"
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar duabuf[8]={10,10,10,10,10,0,0,0};
uchar th,tl,dspcom;
uint cnt;
bit flag=0;
void init_t0(uint ms);
void display();
void chuli(uchar ad,uchar kaiji);
void main()
{
	uchar temp,kaiji,i;
	EA=1;
	init_t0(1);
	kaiji=readeep(0xa0,0xee);
	somenop
	i=kaiji+1;
	writeeep(0xa0,0xee,i);
	
 while(1)
 {
	if(flag)
	{flag=0;
   temp=readad(3);
	}
	temp=(uchar)temp*0x39;
	chuli(temp,i);
 }
}
void chuli(uchar ad,uchar kaiji)
{
duabuf[5]=ad/100%10;
duabuf[6]=ad/10%10;
duabuf[7]=ad%10;	
duabuf[1]=kaiji/100%10;
duabuf[2]=kaiji/10%10;
duabuf[3]=kaiji%10;
}
void init_t0(uint ms)
{
  unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=(65536-tme);
	tme=tme+12;
	th=(uchar)(tme>>8);
	tl=(uchar)(tme);
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
  cnt++;
	if(cnt>=100)
	{
	  cnt=0;
		flag=1;
	}
	display();
}
void display()
{
  P2=(P2&0x1f)|0xc0;
	P0=0x01<<dspcom;
	P2=(P2&0x1f)|0xe0;
	P0=tab[duabuf[dspcom]];
	if(++dspcom==8)dspcom=0;	
}
	