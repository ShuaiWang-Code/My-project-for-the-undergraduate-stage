#include <reg51.h>
#include "absacc.h"
#define uchar unsigned char 
#define   uint unsigned int
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar duabuf[8]={10,10,10,10,10,10,10,10};
uchar th,tl,th1,tl1,dspcom=0;
uint cnt,cnt1=0;
bit flag=0;
sbit dianji=P3^4;
extern void showre();
extern void chulikey();
extern uchar readep(uchar addr);
extern void delay(int ms);
extern void xinhao();
void display();
void init_t0(uint ms);
void init_t1(uint us);
void main()
{extern uint max,min;
  EA=1;
	init_t0(2);
  init_t1(100);
	max=readep(0x00);
	delay(20);
	min=readep(0x01);
	delay(20);
	while(1)
	{
	showre();
	chulikey();
	xinhao();
	}
}
void init_t0(uint ms)
{
  unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=(65535-tme);
	th=(uchar)(tme>>8);
	tl=(uchar)tme;
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void init_t1(uint us)
{
  unsigned long tme;
	tme=12000000/12;
	tme=(tme*us)/1000000;
	tme=(65535-tme);
	th1=(uchar)(tme>>8);
	tl1=(uchar)tme;
	TMOD&=0x0f;
	TMOD|=0x10;
	TH1=th1;
	TL1=tl1;
	ET1=1;
	TR1=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
	cnt++;
	display();
	if(cnt>=50)
	{
	  cnt=0;
		flag=1;
	}
}
void int1() interrupt 3
{
	TH1=th1;
	TL1=tl1;
	cnt1++;
	if(cnt1<=3)
		dianji=1; //�������ô�򵥣� �ǲ����漰�Ĳ��ǵ������������?
	else
		dianji=0;
	if(cnt1>=10)
	         cnt1=0;
}
void display()
{ XBYTE[0XE000]=0XFF;
	XBYTE[0XC000]=0x01<<dspcom;
	XBYTE[0XE000]=tab[duabuf[dspcom]];
	if(++dspcom==8)dspcom=0;
}