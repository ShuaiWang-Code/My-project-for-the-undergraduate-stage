#include <reg51.h>
#include <absacc.h>
#define uchar unsigned char
#define uint unsigned int
sbit she=P1^0;
sbit shou=P1^1;
	code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
	uchar duabuf[8]={10,10,10,10,10,0,0,0};
	uchar th,tl,dspcom=0;
	bit flag=0;
	uint cnt=0;
	void display();
	void init_t0(uint ms);
	bit sheng=0;
	unsigned long jishi=0;
	uint dis;
  void main()
{ 
	EA=1;
	init_t0(5);
  while(1)
{
	sheng=1;
  she=1;
	while(!(jishi>=4));
	jishi=0;
	sheng=0;
	she=0;
	while(shou==0);
	sheng=1;
  while(shou==1);
	dis=(jishi*17/20);
	duabuf[7]=dis%10;
	duabuf[6]=dis/10%10;
	duabuf[5]=dis/100%10;
	jishi=0;	
}
}
void init_t0(uint ms)
{
  unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000000;
	tme=(65536-5);
	th=(uchar)(tme>>8);
	tl=(uchar)tme;
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
	cnt++;
	if(cnt>=100)
	{
	  cnt=0;
	  display();	
	}
	if(sheng==1)
	{
	jishi++;
	}
	
}
void display()
{
XBYTE[0XE000]=0XFF;
XBYTE[0XC000]=0x01<<dspcom;
XBYTE[0XE000]=tab[duabuf[dspcom]];
if(++dspcom==8)dspcom=0;
}
