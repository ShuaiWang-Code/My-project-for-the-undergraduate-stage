#include <reg52.h>
#define uchar unsigned char
#define uint unsigned int
uchar keyvalue;
bit setmood=0;
bit clear=0;
extern void	wenstart();
void keyscan()
{
  uchar temp;
	P3=0xfe;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xee: keyvalue=19;break;
				case 0xde: keyvalue=3;break;
				case 0xbe: keyvalue=2;break;
				case 0x7e: keyvalue=1;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xfd;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xed: keyvalue=18;break;
				case 0xdd: keyvalue=5;break;
				case 0xbd: keyvalue=4;break;
				case 0x7d: keyvalue=3;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xfb;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xeb: keyvalue=17;break;
				case 0xdb: keyvalue=8;break;
				case 0xbb: keyvalue=7;break;
				case 0x7b: keyvalue=6;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xf7;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xe7: keyvalue=16;break;
				case 0xd7: keyvalue=15;break;
				case 0xb7: keyvalue=14;break;
				case 0x77: keyvalue=9;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
}
void setmn()
{
  keyscan();
	if(keyvalue==14)
	{
	  setmood=~setmood;
		keyvalue=0;
	}
	if(setmood==0)
	{
	wenstart();
	}
	else
	{
	 set();
	}	
}
void set()
{
extern	uint TMAX=30;
extern  uint TMIN=20;
keyscan();
	if(keyvalue==15)
	{clear=1;}
}
void chulis(uint temp)
{

}