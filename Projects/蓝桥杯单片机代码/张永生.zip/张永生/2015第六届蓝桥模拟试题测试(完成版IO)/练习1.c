#include <reg52.h>
#include "onewire.h"
extern void display();
extern void initt0(uint ms);
#define LED   0x80
#define DELAY 0xa0
sbit led1=P0^0;
sbit led2=P0^1;
sbit delay=P0^4;
void keyscan();
char keyvalue=-1;
uint tempkey=0;
bit setmood=0;
bit clear=0;
extern void	wenstart();
void set();
void setmn();
extern uchar duabuf1[8];
      extern     uint TMAX;
      extern     uint TMIN;
void main()
{
EA=1;
initt0(1);
while(1)
{
setmn();
}
}



void keyscan()
{
  uchar temp;
	P3=0xfe;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xee: keyvalue=19;break;
				case 0xde: keyvalue=2;break;
				case 0xbe: keyvalue=1;break;
				case 0x7e: keyvalue=0;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xfd;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xed: keyvalue=18;break;
				case 0xdd: keyvalue=5;break;
				case 0xbd: keyvalue=4;break;
				case 0x7d: keyvalue=3;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xfb;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xeb: keyvalue=17;break;
				case 0xdb: keyvalue=8;break;
				case 0xbb: keyvalue=7;break;
				case 0x7b: keyvalue=6;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xf7;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xe7: keyvalue=16;break;
				case 0xd7: keyvalue=15;break;
				case 0xb7: keyvalue=14;break;
				case 0x77: keyvalue=9;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
}
void setmn()
{
  keyscan();
	if(keyvalue==14)
	{
	  setmood=~setmood;
		TMAX=(uint)(duabuf1[1]*10)+duabuf1[2];
		TMIN=(uint)(duabuf1[6]*10)+duabuf1[7];
		tempkey=0;
		duabuf1[1]=10;
		duabuf1[2]=10;
		duabuf1[6]=10;
		duabuf1[7]=10;
		keyvalue=-1;
	}
	if(setmood==0)
	{
	wenstart();
	}
	else
	{
	 set();
	}	
}
void set()
{  
  keyscan();
	duabuf1[0]=11;
	duabuf1[5]=11;
	duabuf1[3]=10;
	duabuf1[4]=10;
	if(keyvalue==15)
	{clear=1; keyvalue=-1;  }
	if(keyvalue!=-1 && clear==0)
	{
	  tempkey++;
		if(tempkey==1)duabuf1[1]=keyvalue;
		if(tempkey==2)duabuf1[2]=keyvalue;
		if(tempkey==3)duabuf1[6]=keyvalue;
		if(tempkey==4)duabuf1[7]=keyvalue;			
	  if(tempkey>4)tempkey=4;
		keyvalue=-1;
	}
	if(clear==1)
	{
	  clear=0;
	  duabuf1[7]=10;
		duabuf1[6]=10;
		duabuf1[2]=10;
		duabuf1[1]=10;
		tempkey=0;
	}

}
