#include <reg52.h>
#define uchar unsigned char
#define uint unsigned int	
code run[]={0x01,0x03,0x02,0x06,0x04,0x0c,0x08,0x09};
void init_t0(int ms);
uchar th,tl;
uint cnt=0;
bit flag=0;
void main()
{uint i;
	EA=1;
	init_t0(1);
while(1)
{
if(flag)
{
  flag=0;
  i++;
	P2=(P2&0x1f)|0xa0;
	P0=(~(P0&run[i]))&0x0f;
	if(i==7)
		i=0;
}
}
}
void init_t0(int ms)
{
  unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=65536-tme+12;
	th=(uchar)(tme>>8);
	tl=(uchar)tme;
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
	cnt++;
	if(cnt>=2)
	{cnt=0;
		flag=1;
	}
	
}
	
