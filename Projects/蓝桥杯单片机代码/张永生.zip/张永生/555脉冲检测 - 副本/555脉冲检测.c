#include <reg51.h>
#define uchar unsigned char
#define uint unsigned int
sbit maichong=P3^4;
	code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
	uchar duabuf[8]={10,10,10,10,10,0,0,0};

uchar th,tl,dspcom=0;
	void init_t0(uint ms);
	void display ();
unsigned long cnt=0;
uint saomiao=0;
void main()
{int i=0;
	EA=1;
	init_t0(5);
  while(maichong);
	TR0=1;
	while(!maichong);
	TR0=0;
	duabuf[7]=cnt%10;
	duabuf[6]=cnt/10%10;
	duabuf[5]=cnt/100%10;
	duabuf[4]=cnt/1000%10;
	duabuf[3]=cnt/10000%10;
	duabuf[2]=cnt/100000%10;
	duabuf[1]=cnt/1000000%10;
	duabuf[0]=cnt/10000000%10;
	while(1)
{
 for(i=0;i<=300;i++);
	display();
	
}
}
void init_t0(uint ms)
{
unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000000;
	tme=(65536-tme);
	th=(uchar)(tme>>8);
	tl=(uchar)tme;
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
	cnt++;
	}
void display()
{
P2=(P2&0x1f)|0xc0;
P0=0x01<<dspcom;
P2=(P2&0x1f)|0xe0;
P0=tab[duabuf[dspcom]];
if(++dspcom==8)dspcom=0;
}