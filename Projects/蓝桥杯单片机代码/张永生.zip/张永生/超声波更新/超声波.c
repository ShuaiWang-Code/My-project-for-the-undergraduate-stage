#include <reg51.h>
#include <absacc.h>
#define uchar unsigned char
#define uint unsigned int
sbit she=P1^0;
sbit shou=P1^1;
	code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
	uchar duabuf[8]={10,10,10,10,10,0,0,0};
	uchar th,tl,th1,tl1,dspcom=0;
  unsigned long cnt=0,cnt1,dis,cnt2=0;
	uint sao;
	void display();
	void init_t0(uint ms,uint ms1);
	bit flag=0;
	void main()
	{
			EA=1;
	init_t0(5,2);
	while(1)
	{
		if(flag)
		{
			flag=0;
	  she=1;TR0=1;
		while(cnt<=4);
		she=0;
		TR0=0;cnt=0;
		while(shou==0);
		TR0=1;
		while(shou==1);
		dis=cnt;
		cnt=0;
		}
		cnt1=dis*17/20;
		duabuf[7]=cnt1%10;
		duabuf[6]=cnt1/10%10;
		duabuf[5]=cnt1/100%10;
	}
	}
	void init_t0(uint ms,uint ms1)
{
  unsigned long tme,tme1;
	tme=12000000/12;
	tme=(tme*ms)/1000000;
	tme=(65536-tme);
	th=(uchar)(tme>>8);
	tl=(uchar)tme;
		tme1=12000000/12;
	tme1=(tme1*ms1)/1000;
	tme1=(65536-tme1);
	th1=(uchar)(tme1>>8);
	tl1=(uchar)tme1;

	TMOD=0x11;
	TH0=th;
	TL0=tl;
	TH1=th1;
	TL1=tl1;
	ET0=1;
	ET1=1;
	TR1=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
	cnt++;
  sao++;	
	if(sao>=200)
	{
	  sao=0;
		display();
	}
}
void int1() interrupt 3
{
	TH1=th1;
	TL1=tl1;
	cnt2++;	
	if(cnt2>=50)
	{
	  cnt=0;
		flag=1;
	}
}
void display()
{
XBYTE[0XE000]=0XFF;
XBYTE[0XC000]=0x01<<dspcom;
XBYTE[0XE000]=tab[duabuf[dspcom]];
if(++dspcom==8)dspcom=0;
}
