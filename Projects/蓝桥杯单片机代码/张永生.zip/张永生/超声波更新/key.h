#ifndef _KEY_H_
#define _KEY_H_
#include <reg51.h>
uchar keyvalue;
void keyscan()
{
uchar temp;
P3=0xfe;P4=0x14;
temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
temp&=0xf0;
while(temp!=0xf0)
{
temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	switch (temp)
	{
		case 0xee:keyvalue=1;break;
		case 0xde:keyvalue=2;break;
		case 0xbe:keyvalue=3;break;
		case 0x7e:keyvalue=4;break;
		default:break;
	}
	while(temp!=0xf0)
	{
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		temp&=0xf0;
	}
}
}
#endif