#ifndef _SHOW_H_
#define _SHOW_H_
#include <reg51.h>
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff,0xbf};
uchar duabuf[8]={10,10,10,10,10,10,10,10};
uchar duabuf1[8]={10,10,10,10,10,10,10,10};
uchar duabuf2[8]={10,10,10,10,10,10,10,10};
void show(uint set)
{
duabuf[5]=11;
duabuf[6]=set/10%10;
duabuf[7]=set%10;
}
void show1()
{
extern uchar dtime[3][2];
duabuf1[0]=dtime[2][1];
duabuf1[1]=dtime[2][0];
duabuf1[3]=dtime[1][1];
duabuf1[4]=dtime[1][0];
duabuf1[6]=dtime[0][1];
duabuf1[7]=dtime[0][0];
}
void show2(uint list,uint heat)
{
duabuf2[0]=11;
duabuf2[1]=list/10%10;	
duabuf2[2]=list%10;
duabuf2[5]=11;
duabuf2[6]=heat/10%10;
duabuf2[7]=heat%10;
}
#endif