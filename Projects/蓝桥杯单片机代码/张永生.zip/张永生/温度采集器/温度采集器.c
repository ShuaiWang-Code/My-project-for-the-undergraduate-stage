#include <reg51.h>
#include <absacc.h>
#include <keyscan.h>
uchar dspcom,dspcom1,dspcom2,th,tl;
uint cnt=0;
void init_t0(uint ms);
void display();
void display1();
void display2();
void main()
{
  EA=1;
	init_t0(1);
	init_1302();
	while(1)
	{
	setview();
	}
}
void init_t0(uint ms)
{
unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=(65536-tme);
	th=(uchar)(tme>>8);
	tl=(uchar)(tme);
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;

	if(smgflag==0)
	{
	display();
	}
	if(smgflag==1)
	{
	display1();
	}
	if(smgflag==2)
	{
	display2();
	}
	if(ledflag==1)
	{
	cnt++;
	if(cnt>=100)
	{
		cnt=0;
    led=~led;		
	}
	}
	if(led)
	{
	 XBYTE[0X8000]=0xfe;
	}
	else
	{
	XBYTE[0X8000]=0xff;
	}
}
void display()
{
 XBYTE[0XE000]=0xff;
 XBYTE[0XC000]=0X01<<dspcom;
 XBYTE[0XE000]=tab[duabuf[dspcom]];
	if(++dspcom==8)dspcom=0;
}
void display1()
{
 XBYTE[0XE000]=0xff;
 XBYTE[0XC000]=0X01<<dspcom1;
 XBYTE[0XE000]=tab[duabuf1[dspcom1]];
	if(++dspcom1==8)dspcom1=0;
}
void display2()
{
 XBYTE[0XE000]=0xff;
 XBYTE[0XC000]=0X01<<dspcom2;
 XBYTE[0XE000]=tab[duabuf2[dspcom2]];
	if(++dspcom2==8)dspcom2=0;
}