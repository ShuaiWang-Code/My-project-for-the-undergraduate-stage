#include <reg51.h>
#define uchar unsigned char
#define uint unsigned int 
	code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
	uchar duabuf[8]={10,10,10,10,10,0,0,0};
	uchar th,tl,dspcom=0;
	uint cnt;
	bit flag=0;
	void display();
	void init_t0(uint ms);
	void keyscan();
	uchar keyvalue;
void main()
{
	EA=1;
	init_t0(1);
while(1)
{

}
}
void init_t0(uint ms)
{
  unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=(65536-tme);
	th=(uchar)(tme>>8);
	tl=(uchar)tme;
	TMOD&=0xf0;
	TMOD|=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void int0() interrupt 1
{
	TH0=th;
	TL0=tl;
	cnt++;
	if(cnt>=100)
	{
	 cnt=0;
		flag=1;
	}
	display();
}
void display()
{
  P2=(P2&0x1f)|0xc0;
	P0=0x01<<dspcom;
	P2=(P2&0x1f)|0xe0;
	P0=tab[duabuf[dspcom]];
	if(++dspcom==8)dspcom=0;
}
void keyscan()
{
  uchar temp;
	P3=0xfe;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xee: keyvalue=1;break;
				case 0xde: keyvalue=2;break;
				case 0xbe: keyvalue=3;break;
				case 0x7e: keyvalue=4;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xfd;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xed: keyvalue=5;break;
				case 0xdd: keyvalue=6;break;
				case 0xbd: keyvalue=7;break;
				case 0x7d: keyvalue=8;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xfb;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xeb: keyvalue=9;break;
				case 0xdb: keyvalue=10;break;
				case 0xbb: keyvalue=11;break;
				case 0x7b: keyvalue=12;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
	
	P3=0xf7;P4=0x14;
	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	temp=temp&0xf0;
	while(temp!=0xf0)
	{
	  	temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
		  switch(temp)
			{
				case 0xe7: keyvalue=13;break;
				case 0xd7: keyvalue=14;break;
				case 0xb7: keyvalue=15;break;
				case 0x77: keyvalue=16;break;
			}
			while(temp!=0xf0)
			{
				temp=(P3&0x3f)|((P4&0x10)<<3)|((P4&0x04)<<4);
	      temp=temp&0xf0;
			}
	}
}
