#include <reg52.h>
#include "onewire.h"
#define uchar unsigned char
#define uint unsigned int
void init_t0(uint ms);
void display();
void chuli(uint re);
code uchar tab[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90,0xff};
uchar duabuf[8]={10,10,10,10,10,0,0,0};
uchar th,tl,dspcom;
uint cnt,temp;
bit tflag=0;
void main()
{
	Init_DS18B20();
	EA=1;
	init_t0(1);
while(1)
{
	if(tflag)
	{
	tflag=0;
	temp=read_temp();
	}
	chuli(temp);
}
}
void init_t0(uint ms)
{
  unsigned long tme;
	tme=12000000/12;
	tme=(tme*ms)/1000;
	tme=(65536-tme);
	tme=tme+12;
	th=(uchar)(tme>>8);
	tl=(uchar)tme;
	TMOD=0x01;
	TH0=th;
	TL0=tl;
	ET0=1;
	TR0=1;
}
void int0() interrupt 1
{
  TH0=th;
	TL0=tl;
	cnt++;
	if(cnt>=1000)
	{
	tflag=1;
		cnt=0;
	}
	display();
}
void chuli(uint re)
{
uint cc;
cc=(uint)re*0.0625;
duabuf[5]=cc/100%10;
duabuf[6]=cc/10%10;
duabuf[7]=cc%10;
}
void display()
{


	P2 = ((P2&0x1f)|0xC0); 
	P0 = (1<<dspcom);
	P2 &= 0x1f;
	
  P2 = ((P2&0x1f)|0xE0); 
	P0 = tab[duabuf[dspcom]];
	P2 &= 0x1f;  
    
	if(++dspcom == 8)
			{
        dspcom = 0;
      }
}